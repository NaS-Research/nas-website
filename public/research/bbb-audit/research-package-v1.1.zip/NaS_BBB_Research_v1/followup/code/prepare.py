"""Private follow-up preparation; no model fitting or test performance selection."""
from pathlib import Path
import argparse,json,hashlib,re
import numpy as np,pandas as pd
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import rdFingerprintGenerator
from rdkit.Chem.MolStandardize import rdMolStandardize as MS
from sklearn.model_selection import GroupShuffleSplit
class Union:
 def __init__(self,n):self.p=list(range(n))
 def find(self,x):
  while self.p[x]!=x:self.p[x]=self.p[self.p[x]];x=self.p[x]
  return x
 def join(self,x,y):
  x,y=self.find(x),self.find(y)
  if x!=y:self.p[max(x,y)]=min(x,y)
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);args=p.parse_args();R=args.root;O=R.parent/'study_v1';D=R/'results';D.mkdir(exist_ok=True)
 for e in json.loads((R/'source_manifest.json').read_text()):assert hashlib.sha256((R/e['file']).read_bytes()).hexdigest()==e['sha256']
 A=pd.read_csv(O/'results/cohort_audit.csv',keep_default_na=False);sim=np.load(O/'results/similarity.npy');ids=A[A.status.eq('eligible')].drop_duplicates('base_group').rid.to_numpy();members=[];designs=[]
 def add(name,seed,tr,va,pv,te):
  parts={'train':np.asarray(tr,dtype=int),'valid':np.asarray(va,dtype=int),'policy':np.asarray(pv,dtype=int),'test':np.asarray(te,dtype=int)}
  for part,ii in parts.items():
   for i in ii:members.append(dict(design=name,seed=seed,partition=part,rid=int(i)))
  for j,x in enumerate(parts):
   for y in list(parts)[j+1:]:assert not(set(A.iloc[parts[x]].base_group)&set(A.iloc[parts[y]].base_group))
  rec={'design':name,'seed':seed}
  for part,ii in parts.items():rec[part+'_n']=len(ii);rec[part+'_positive']=int(A.iloc[ii].label.sum())
  if len(te):rec['max_test_train_similarity']=float(sim[np.ix_(te,tr)].max());rec['median_nearest_train_similarity']=float(np.median(sim[np.ix_(te,tr)].max(axis=1)))
  designs.append(rec)
 feasibility=[]
 for seed in range(21,26):
  rng=np.random.default_rng(seed);te=np.concatenate([rng.choice(ids[A.iloc[ids].label.to_numpy()==y],50,replace=False) for y in [0,1]])
  pool=np.array([i for i in ids if i not in set(te)]);mx=sim[np.ix_(pool,te)].max(axis=1);strict=pool[mx<.4];ys=A.iloc[strict].label.to_numpy();counts=[int((ys==y).sum()) for y in [0,1]]
  k=min([150]+[n-40 for n in counts]);feasibility.append(dict(seed=seed,strict_counts=counts,k=k,feasible=k>=30))
  if k<30:continue
  reserves=[rng.choice(strict[ys==y],40,replace=False) for y in [0,1]];va=np.concatenate([a[:20] for a in reserves]);pv=np.concatenate([a[20:] for a in reserves]);held=set(np.concatenate([va,pv]));pool=np.array([i for i in pool if i not in held]);mx=sim[np.ix_(pool,te)].max(axis=1)
  for name,limit in [('matched_strict',.4),('matched_moderate',.6),('matched_broad',.9)]:
   available=pool[mx<limit];tr=np.concatenate([rng.choice(available[A.iloc[available].label.to_numpy()==y],k,replace=False) for y in [0,1]]);assert sim[np.ix_(tr,te)].max()<limit;add(name,seed,tr,va,pv,te)
  clean=A[A.status.eq('eligible')].rid.to_numpy()
 # External training splits are feasible independently of matched-design feasibility.
 clean=A[A.status.eq('eligible')].rid.to_numpy();g=A.base_group.to_numpy()
 for seed in range(21,26):
  x,y=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed).split(clean,groups=g[clean]));dev,pv=clean[x],clean[y]
  x,y=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed+100).split(dev,groups=g[dev]));add('external',seed,dev[x],dev[y],pv,[])
 pd.DataFrame(members).to_csv(D/'memberships.csv',index=False);pd.DataFrame(designs).to_csv(D/'designs.csv',index=False);(D/'matched_feasibility.json').write_text(json.dumps(feasibility,indent=2))
 RDLogger.DisableLog('rdApp.*');gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False)
 sourcekeys={k:set(A[k])- {''} for k in ['canonical','neutral','tautomer','stereofree_tautomer']};originalfps=[gen.GetFingerprint(Chem.MolFromSmiles(r.neutral or r.canonical)) for r in A.itertuples()]
 tong=pd.read_csv(R/'raw/tong__dataset__Sdata-process-flow-step5-testdata.csv');bext=pd.read_csv(R/'raw/B3DB__B3DB_classification_external.tsv',sep='\t');b=pd.read_csv(R/'raw/B3DB__B3DB_classification.tsv',sep='\t');refs=pd.read_csv(R/'raw/data_curation__raw_data__raw_data_summary.tsv',sep='\t')
 years={int(x[0]):int(re.search(r'\((19\d{2}|20\d{2})\)',str(x[2])).group(1)) for x in refs.itertuples(index=False,name=None) if re.search(r'\((19\d{2}|20\d{2})\)',str(x[2]))}
 b['numeric_logBB']=pd.to_numeric(b.logBB,errors='coerce')
 def sourceeligible(s):
  rr=[int(x) for x in re.findall(r'R(\d+)',str(s))];return bool(rr) and all(x not in [1,30] and years.get(x,0)>2012 for x in rr)
 bq=b[b.numeric_logBB.notna() & b.reference.map(sourceeligible)].copy();bq['followup_label']=(bq.numeric_logBB>=-1).astype(int)
 records=[]
 for dataset,df,scol,lcol in [('tong_s',tong,'SMILES','BBB'),('b3db_recent',bext,'SMILES','BBB+/BBB-'),('b3db_quantitative',bq,'SMILES','followup_label')]:
  for i,r in df.iterrows():
   label=r[lcol];label=int(label) if str(label) not in ['BBB+','BBB-'] else int(label=='BBB+')
   row=dict(dataset=dataset,source_row=int(i),source_smiles=str(r[scol]),label=label,source_reference=str(r.get('reference','see Tong2022 mixed-source methods; row-specific assay mapping unavailable')),status='eligible',canonical='',neutral='',tautomer='',stereofree_tautomer='',max_original_similarity=None,error='')
   try:
    m=Chem.MolFromSmiles(row['source_smiles']);assert m is not None,'parse failed';row['canonical']=Chem.MolToSmiles(m);c=MS.Cleanup(Chem.Mol(m));organic=[f for f in Chem.GetMolFrags(c,asMols=True,sanitizeFrags=True) if any(x.GetAtomicNum()==6 for x in f.GetAtoms())]
    if len(organic)!=1:row['status']='ambiguous_organic_components'
    else:
     n=MS.Uncharger().uncharge(organic[0]);t=MS.TautomerEnumerator().Canonicalize(Chem.Mol(n));row.update(neutral=Chem.MolToSmiles(n),tautomer=Chem.MolToSmiles(t),stereofree_tautomer=Chem.MolToSmiles(t,isomericSmiles=False));fp=gen.GetFingerprint(n);row['max_original_similarity']=float(max(DataStructs.BulkTanimotoSimilarity(fp,originalfps)))
     if any(row[k] in sourcekeys[k] for k in sourcekeys):row['status']='original_identity_overlap'
     elif row['max_original_similarity']>=.9:row['status']='original_near_overlap'
   except Exception as e:row['status']='standardization_failure';row['error']=str(e)
   records.append(row)
 E=pd.DataFrame(records);E['eid']=['e'+str(i) for i in range(len(E))]
 for dataset,ix in E.groupby('dataset').groups.items():
  ok=E.loc[ix];ok=ok[ok.status.eq('eligible')]
  for key in ['neutral','tautomer']:
   conflict=ok.groupby(key).label.nunique();bad=set(conflict[conflict>1].index);E.loc[E.index.isin(ix)&E[key].isin(bad)&E.status.eq('eligible'),'status']='external_label_conflict'
  ok=E.loc[ix];ok=ok[ok.status.eq('eligible')];duplicate=ok.duplicated('neutral');E.loc[ok.index[duplicate],'status']='external_duplicate_member'
 E['external_group']='';eligible=E[E.status.eq('eligible')];fps=[gen.GetFingerprint(Chem.MolFromSmiles(s)) for s in eligible.neutral];u=Union(len(fps));keys={}
 for j,r in enumerate(eligible.itertuples()):
  key=r.stereofree_tautomer
  if key in keys:u.join(j,keys[key])
  else:keys[key]=j
  for k,v in enumerate(DataStructs.BulkTanimotoSimilarity(fps[j],fps[:j])):
   if v>=.9:u.join(j,k)
 for j,idx in enumerate(eligible.index):E.loc[idx,'external_group']='ext'+str(u.find(j))
 E.to_csv(D/'external_audit.csv',index=False);summary=[]
 for dataset,df in E.groupby('dataset'):
  z=df[df.status.eq('eligible')];summary.append(dict(dataset=dataset,source_rows=len(df),status_counts=df.status.value_counts().to_dict(),retained=len(z),positive=int(z.label.sum()),negative=int((z.label==0).sum()),strict_retained=int((z.max_original_similarity<.4).sum()),comparative_discrimination_adequate=bool(z.label.value_counts().min()>=20 and z.label.nunique()==2)))
 (D/'external_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'matched_feasibility':feasibility,'external':summary},indent=2),flush=True)
if __name__=='__main__':main()
