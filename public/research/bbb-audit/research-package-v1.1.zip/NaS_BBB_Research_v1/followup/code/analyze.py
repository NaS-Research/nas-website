"""Locked comparisons and validation-frozen selective prediction; private record outputs."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np,pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score,balanced_accuracy_score,recall_score,matthews_corrcoef,brier_score_loss,log_loss
NBOOT=1000
METRICS=['AUROC','AUPRC','balanced_accuracy','sensitivity','specificity','MCC','Brier','log_loss','ECE','error']
def metrics(y,p,w=None):
 y=np.asarray(y,dtype=float);p=np.clip(np.asarray(p,dtype=float),1e-7,1-1e-7);w=np.ones(len(y)) if w is None else np.asarray(w,dtype=float);total=w.sum()
 if total<=0:return {m:np.nan for m in METRICS}
 pos=np.sum(w*y);neg=total-pos;pred=p>=.5;tp=np.sum(w*y*pred);tn=np.sum(w*(1-y)*(~pred));fp=neg-tn;fn=pos-tp;sens=tp/pos if pos else np.nan;spec=tn/neg if neg else np.nan
 ix=np.argsort(p,kind='stable');pp=p[ix];wy=(w*y)[ix];wn=(w*(1-y))[ix];ends=np.r_[np.flatnonzero(np.diff(pp)),len(pp)-1];csn=np.cumsum(wn);csp=np.cumsum(wy);gp=np.diff(np.r_[0,csp[ends]]);gn=np.diff(np.r_[0,csn[ends]]);auc=np.sum(gp*(csn[ends]-.5*gn))/(pos*neg) if pos and neg else np.nan
 ix=np.argsort(-p,kind='stable');pp=p[ix];cumw=np.cumsum(w[ix]);cumy=np.cumsum((w*y)[ix]);ends=np.r_[np.flatnonzero(np.diff(pp)),len(pp)-1];prec=np.divide(cumy[ends],cumw[ends],out=np.zeros(len(ends)),where=cumw[ends]>0);ap=np.sum(np.diff(np.r_[0,cumy[ends]])*prec)/pos if pos else np.nan
 den=(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn);mcc=(tp*tn-fp*fn)/np.sqrt(den) if den else 0.;bins=np.minimum((p*10).astype(int),9);ece=0
 for b in range(10):
  z=bins==b
  if w[z].sum():ece+=abs(np.sum(w[z]*(y[z]-p[z])))/total
 return dict(AUROC=float(auc),AUPRC=float(ap),balanced_accuracy=float((sens+spec)/2),sensitivity=float(sens),specificity=float(spec),MCC=float(mcc),Brier=float(np.sum(w*(p-y)**2)/total),log_loss=float(-np.sum(w*(y*np.log(p)+(1-y)*np.log(1-p)))/total),ECE=float(ece),error=float((fp+fn)/total))
def boot_metrics(y,p,weights):
 p=np.clip(np.asarray(p),1e-7,1-1e-7);y=np.asarray(y);ix=np.argsort(p,kind='stable');starts=np.r_[0,np.flatnonzero(np.diff(p[ix]))+1];gp=np.add.reduceat(weights[:,ix]*y[ix],starts,axis=1);gn=np.add.reduceat(weights[:,ix]*(1-y[ix]),starts,axis=1);den=gp.sum(axis=1)*gn.sum(axis=1)
 with np.errstate(divide='ignore',invalid='ignore'):
  auc=np.sum(gp*(np.cumsum(gn,axis=1)-.5*gn),axis=1)/den;brier=(weights@((p-y)**2))/weights.sum(axis=1)
 return np.column_stack([auc,brier])
def percentile_map(reference,values):return np.searchsorted(np.sort(reference),values,side='right')/len(reference)
def random_score(seed,cohort,ids):return np.array([int(hashlib.sha256(f'{seed}|{cohort}|{s}'.encode()).hexdigest()[:13],16)/16**13 for s in ids])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--output',type=Path);args=ap.parse_args();R=args.root;D=R/'results';out=args.output or D/'analysis';out.mkdir(parents=True,exist_ok=True);E=pd.read_csv(D/'external_audit.csv');extsim=E.set_index('eid').max_original_similarity.to_dict();frames=[]
 for f in sorted((D/'runs').glob('*.json')):
  rec=json.loads(f.read_text());x=pd.read_csv(f.with_suffix('.csv'),float_precision='round_trip');x['design']=rec['design'];x['seed']=rec['seed'];x['model']=rec['model'];frames.append(x)
 F=pd.concat(frames,ignore_index=True);assert len(frames)==100,'All100 registered fits must finish before analysis'
 ensembles=[]
 for (design,seed,cohort),x in F.groupby(['design','seed','cohort']):
  assert set(x.model)=={'rule','descriptor_lr','morgan_lr','rf','mpnn'};z=x[x.model.eq('rule')].copy().set_index('id');stack=np.stack([x[x.model.eq(m)].set_index('id').loc[z.index].calibrated.to_numpy() for m in ['rule','descriptor_lr','morgan_lr','rf','mpnn']]);z['calibrated']=stack.mean(axis=0);z['model']='ensemble';z['uncalibrated']=np.nan;ensembles.append(z.reset_index())
 F=pd.concat([F]+ensembles,ignore_index=True)
 for seed in range(21,26):
  xx=F[(F.seed==seed)&F.design.str.startswith('matched')&F.model.eq('rule')&F.cohort.eq('test')].pivot(index='id',columns='design',values='calibrated');assert xx.shape==(100,3);assert (xx.iloc[:,0].to_numpy()[:,None]==xx.to_numpy()).all()
 # Extra strict subsets retain externally nonoverlapping molecules distant from the entire original pool.
 extras=[]
 for cohort in ['tong_s','b3db_recent','b3db_quantitative']:
  z=F[F.cohort.eq(cohort)&F.id.map(extsim).lt(.4)].copy();z['cohort']=cohort+'_strict';extras.append(z)
 F=pd.concat([F]+extras,ignore_index=True);F.to_csv(out/'predictions_with_ensemble.csv',index=False)
 summary=[];independent_checks=0
 for keys,x in F[~F.cohort.eq('policy')].groupby(['design','seed','cohort','model']):
  y=x.label.to_numpy();p=np.clip(x.calibrated.to_numpy(),1e-7,1-1e-7);v=metrics(y,p);pred=p>=.5
  independent={'Brier':brier_score_loss(y,p),'log_loss':log_loss(y,p,labels=[0,1]),'MCC':matthews_corrcoef(y,pred),'error':np.mean(pred!=y)}
  if len(set(y))==2:independent.update(AUROC=roc_auc_score(y,p),AUPRC=average_precision_score(y,p),balanced_accuracy=balanced_accuracy_score(y,pred),sensitivity=recall_score(y,pred),specificity=recall_score(y,pred,pos_label=0))
  for m,q in independent.items():assert abs(v[m]-q)<1e-12,(keys,m,v[m],q);independent_checks+=1
  summary.append(dict(zip(['design','seed','cohort','model'],keys),n=len(x),positive=int(y.sum()),**v))
 S=pd.DataFrame(summary);S.to_csv(out/'metrics_by_seed.csv',index=False);S.groupby(['design','cohort','model'])[METRICS].agg(['mean','std','min','max']).to_csv(out/'metric_summary.csv')
 # Fixed external test predictions averaged over seeds are a separate estimator.
 av=[]
 for (cohort,model),x in F[(F.design=='external')&~F.cohort.eq('policy')].groupby(['cohort','model']):
  z=x.groupby('id').agg(label=('label','first'),p=('calibrated','mean'));av.append(dict(cohort=cohort,model=model,n=len(z),**metrics(z.label,z.p)))
 pd.DataFrame(av).to_csv(out/'external_seed_averaged.csv',index=False)
 print('Independent metric checks complete:',independent_checks,flush=True)
 comparisons=[];bootcache={}
 for (design,cohort),pop in F[~F.cohort.eq('policy')].groupby(['design','cohort']):
  groups=sorted(pop.group.unique());lookup={g:i for i,g in enumerate(groups)};rng=np.random.default_rng(20260928);counts=rng.multinomial(len(groups),np.ones(len(groups))/len(groups),size=NBOOT);bootcache[(design,cohort)]=(lookup,counts)
  for left,right in [('mpnn','rule'),('mpnn','descriptor_lr'),('descriptor_lr','rule')]:
   draws=[];points=[]
   for seed in range(21,26):
    x=pop[(pop.seed==seed)&pop.model.eq(left)].set_index('id');z=pop[(pop.seed==seed)&pop.model.eq(right)].set_index('id').loc[x.index];y=x.label.to_numpy();p=x.calibrated.to_numpy();q=z.calibrated.to_numpy();assert np.array_equal(y,z.label)
    ix=np.array([lookup[g] for g in x.group]);points.append([metrics(y,p)[m]-metrics(y,q)[m] for m in ['AUROC','Brier']]);d=[]
    draws.append(boot_metrics(y,p,counts[:,ix])-boot_metrics(y,q,counts[:,ix]))
   draws=np.nanmean(np.array(draws),axis=0);points=np.mean(points,axis=0)
   for j,m in enumerate(['AUROC','Brier']):
    v=draws[:,j];valid=v[np.isfinite(v)];qq=np.quantile(valid,[.025,.975,.05/6,1-.05/6]) if len(valid) else [np.nan]*4;comparisons.append(dict(design=design,cohort=cohort,left=left,right=right,metric=m,mean_difference=points[j],lower=qq[0],upper=qq[1],bonferroni_lower=qq[2],bonferroni_upper=qq[3],valid_replicates=len(valid)))
  print('Paired comparisons:',design,cohort,flush=True)
 pd.DataFrame(comparisons).to_csv(out/'paired_comparisons.csv',index=False)
 condition_rows=[]
 lookup,counts=bootcache[('matched_strict','test')]
 for model in ['rule','descriptor_lr','morgan_lr','rf','mpnn','ensemble']:
  draws=[];points=[]
  for seed in range(21,26):
   x=F[(F.design=='matched_broad')&(F.seed==seed)&(F.cohort=='test')&(F.model==model)].set_index('id');z=F[(F.design=='matched_strict')&(F.seed==seed)&(F.cohort=='test')&(F.model==model)].set_index('id').loc[x.index];y=x.label.to_numpy();p=x.calibrated.to_numpy();q=z.calibrated.to_numpy();ix=np.array([lookup[g] for g in x.group]);assert np.array_equal(y,z.label)
   draws.append(boot_metrics(y,p,counts[:,ix])-boot_metrics(y,q,counts[:,ix]));points.append([metrics(y,p)[m]-metrics(y,q)[m] for m in ['AUROC','Brier']])
  draws=np.mean(draws,axis=0);points=np.mean(points,axis=0)
  for j,m in enumerate(['AUROC','Brier']):
   valid=draws[:,j][np.isfinite(draws[:,j])];lo,hi=np.quantile(valid,[.025,.975]);condition_rows.append(dict(model=model,metric=m,contrast='broad minus strict',mean_difference=points[j],lower=lo,upper=hi,valid_replicates=len(valid),exploratory=True))
 pd.DataFrame(condition_rows).to_csv(out/'condition_comparisons.csv',index=False)

 selections=[];thresholds=[];recordmasks={}
 for (design,seed),population in F.groupby(['design','seed']):
  policy=population[population.cohort.eq('policy')];disagreement={}
  for cohort,x in population.groupby('cohort'):
   pivot=x[~x.model.eq('ensemble')].pivot(index='id',columns='model',values='calibrated');disagreement[cohort]=pivot.std(axis=1,ddof=0)
  for model in ['rule','descriptor_lr','morgan_lr','rf','mpnn','ensemble']:
   pv=policy[policy.model.eq(model)].copy();pconf=np.maximum(pv.calibrated,1-pv.calibrated).to_numpy();psim=pv.similarity.to_numpy();pdis=-disagreement['policy'].loc[pv.id].to_numpy();prand=random_score(seed,'policy',pv.id)
   pref={'confidence':pconf,'similarity':psim,'agreement':pdis};pref['hybrid']=(percentile_map(pconf,pconf)+percentile_map(psim,psim)+percentile_map(pdis,pdis))/3;pref['random']=prand
   cuts={(score,c):float(np.quantile(values,1-c,method='higher')) for score,values in pref.items() for c in [.5,.75,.9]}
   for (score,c),cut in cuts.items():thresholds.append(dict(design=design,seed=seed,model=model,score=score,nominal_coverage=c,threshold=cut,learned_from='policy validation only'))
   for cohort,x in population[(~population.cohort.eq('policy'))&population.model.eq(model)].groupby('cohort'):
    y=x.label.to_numpy();p=x.calibrated.to_numpy();conf=np.maximum(p,1-p);dis=-disagreement[cohort].loc[x.id].to_numpy();ss={'confidence':conf,'similarity':x.similarity.to_numpy(),'agreement':dis};ss['hybrid']=(percentile_map(pconf,conf)+percentile_map(psim,ss['similarity'])+percentile_map(pdis,dis))/3;ss['random']=random_score(seed,cohort,x.id)
    for (score,c),cut in cuts.items():
     mask=ss[score]>=cut;v=metrics(y[mask],p[mask]);cov0=float(mask[y==0].mean()) if (y==0).any() else np.nan;cov1=float(mask[y==1].mean()) if (y==1).any() else np.nan
     rec=dict(design=design,seed=seed,cohort=cohort,model=model,score=score,nominal_coverage=c,threshold=cut,n=len(y),accepted=int(mask.sum()),accepted_positive=int(y[mask].sum()),accepted_negative=int((y[mask]==0).sum()),coverage=float(mask.mean()),negative_coverage=cov0,positive_coverage=cov1,rejected_error=metrics(y[~mask],p[~mask])['error'],full_error=metrics(y,p)['error'],**v);selections.append(rec);recordmasks[(design,cohort,model,score,c,seed)]=(x.group.to_numpy(),y,p,mask)
 P=pd.DataFrame(selections);P.to_csv(out/'selective_metrics_by_seed.csv',index=False);pd.DataFrame(thresholds).to_csv(out/'policy_thresholds.csv',index=False)
 risks=[]
 for key,rr in P.groupby(['design','cohort','model','score','nominal_coverage']):
  design,cohort,model,score,c=key;lookup,counts=bootcache[(design,cohort)];draws=[];point=[]
  for seed in range(21,26):
   gg,y,p,mask=recordmasks[key+(seed,)];ix=np.array([lookup[g] for g in gg]);err=(p>=.5)!=y;n=len(lookup)
   alln=np.bincount(ix,minlength=n);allerr=np.bincount(ix,weights=err,minlength=n);seln=np.bincount(ix,weights=mask,minlength=n);selerr=np.bincount(ix,weights=mask*err,minlength=n);den=counts@seln
   with np.errstate(divide='ignore',invalid='ignore'):draws.append((counts@allerr)/(counts@alln)-(counts@selerr)/den)
   point.append(float(err.mean()-err[mask].mean()) if mask.any() else np.nan)
  draws=np.mean(draws,axis=0);valid=draws[np.isfinite(draws)];lo,hi=np.quantile(valid,[.025,.975]) if len(valid) else [np.nan,np.nan];delta=float(np.mean(point));support=bool((rr.accepted_positive>=20).all() and (rr.accepted_negative>=20).all());coverage=bool(rr.coverage.mean()>=.5 and (rr.negative_coverage>=.3).all() and (rr.positive_coverage>=.3).all());useful=bool(support and coverage and delta>=.05 and lo>0 and len(valid)>=950 and score!='random')
  risks.append(dict(zip(['design','cohort','model','score','nominal_coverage'],key),mean_error_reduction=delta,lower=lo,upper=hi,valid_replicates=len(valid),mean_coverage=float(rr.coverage.mean()),minimum_class_coverage=float(rr[['negative_coverage','positive_coverage']].min().min()),minimum_accepted_class_count=int(rr[['accepted_negative','accepted_positive']].min().min()),support_sufficient=support,coverage_sufficient=coverage,research_usefulness_criterion=useful,exploratory=True))
 pd.DataFrame(risks).to_csv(out/'selective_risk_comparisons.csv',index=False)
 (out/'verification.json').write_text(json.dumps({'registered_fits':len(frames),'independent_metric_checks':independent_checks,'fixed_rule_identical_across_matched_conditions':True,'bootstrap_replicates':NBOOT,'policy_thresholds_learned_from':'separate policy validation only','external_outcomes_used_for_selection':False,'intervals':'conditional on fitted models and frozen policies; exploratory selection comparisons'},indent=2));print('All follow-up statistics and selective analyses complete.',flush=True)
if __name__=='__main__':main()
