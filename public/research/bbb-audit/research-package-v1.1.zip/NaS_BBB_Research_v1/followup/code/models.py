"""Fit the frozen follow-up; external outcomes never enter fitting or calibration."""
from pathlib import Path
import argparse,json,hashlib,time,joblib
import numpy as np,pandas as pd
from scipy.special import expit,logit
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import Descriptors,rdFingerprintGenerator
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import torch
import base_models as B

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);args=ap.parse_args();R=args.root;D=R/'results';O=R.parent/'study_v1';dest=D/'runs';dest.mkdir(exist_ok=True)
 A=pd.read_csv(O/'results/cohort_audit.csv',keep_default_na=False);E=pd.read_csv(D/'external_audit.csv',keep_default_na=False);E=E[E.status.eq('eligible')].reset_index(drop=True);E['idx']=np.arange(len(E))+len(A);sp=pd.read_csv(D/'memberships.csv');RDLogger.DisableLog('rdApp.*');torch.set_num_threads(2)
 mols=[Chem.MolFromSmiles(r.neutral or r.canonical) for r in A.itertuples()]+[Chem.MolFromSmiles(s) for s in E.neutral];gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False);fps=[gen.GetFingerprint(m) for m in mols]
 funcs=[Descriptors.MolWt,Descriptors.MolLogP,Descriptors.TPSA,Descriptors.NumHDonors,Descriptors.NumHAcceptors,Descriptors.NumRotatableBonds,Descriptors.RingCount,Descriptors.FractionCSP3];desc=np.array([[f(m) for f in funcs] for m in mols]);fp=np.array([gen.GetFingerprintAsNumPy(m) for m in mols]);graphs=[B.graph(m) for m in mols];y=np.concatenate([A.label.to_numpy(),E.label.to_numpy()]);assert np.isfinite(desc).all()
 hashes={f:hashlib.sha256((D/f).read_bytes()).hexdigest() for f in ['memberships.csv','external_audit.csv']};code={f:hashlib.sha256((R/'code'/f).read_bytes()).hexdigest() for f in ['models.py','base_models.py']};freeze=json.loads((R/'protocol/FREEZE.json').read_text());assert hashlib.sha256((R/'protocol/PROTOCOL_v1.md').read_bytes()).hexdigest()==freeze['sha256']
 for (design,seed),rows in sp.groupby(['design','seed'],sort=False):
  parts={p:x.rid.to_numpy() for p,x in rows.groupby('partition')};tr=parts['train'];va=parts['valid'];pv=parts['policy'];assert all(len(set(y[ii]))==2 for ii in [tr,va,pv])
  targets={'policy':pv}
  if design=='external':
   for cohort,z in E.groupby('dataset'):targets[cohort]=z.idx.to_numpy()
  else:targets['test']=parts['test']
  distances={p:np.array([max(DataStructs.BulkTanimotoSimilarity(fps[i],[fps[j] for j in tr])) for i in ids]) for p,ids in targets.items()}
  for name in ['rule','descriptor_lr','morgan_lr','rf','mpnn']:
   prefix=dest/f'{design}__{seed}__{name}';receipt=prefix.with_suffix('.json')
   if receipt.exists():
    old=json.loads(receipt.read_text());assert old['input_hashes']==hashes and old['code_hashes']==code;assert prefix.with_suffix('.csv').exists();continue
   start=time.monotonic();extra={};model=None
   if name=='rule':predict=lambda ids:expit((90-desc[ids,2])/20)
   elif name=='mpnn':
    model,extra=B.fit_graph(graphs,y,tr,va,int(seed));torch.save(model.state_dict(),prefix.with_suffix('.pt'));predict=lambda ids:B.predict_graph(model,graphs,ids)
   else:
    X=desc if name=='descriptor_lr' else fp
    if name=='rf':model=RandomForestClassifier(n_estimators=300,min_samples_leaf=2,max_features='sqrt',random_state=int(seed),n_jobs=2)
    else:
     model=LogisticRegression(C=1,max_iter=2000,solver='liblinear',random_state=int(seed))
     if name=='descriptor_lr':model=make_pipeline(StandardScaler(),model)
    model.fit(X[tr],y[tr]);joblib.dump(model,prefix.with_suffix('.joblib'));predict=lambda ids:model.predict_proba(X[ids])[:,1]
   valid_p=predict(va);ab=B.calibrate(y[va],valid_p);pd.DataFrame({'rid':va,'label':y[va],'uncalibrated':valid_p}).to_csv(prefix.with_suffix('.validation.csv'),index=False);out=[]
   for cohort,ids in targets.items():
    raw=predict(ids);prob=expit(ab[0]*logit(np.clip(raw,1e-7,1-1e-7))+ab[1]);isext=ids>=len(A)
    groups=[str(E.iloc[i-len(A)].external_group) if i>=len(A) else 'orig'+str(A.iloc[i].base_group) for i in ids];eid=[str(E.iloc[i-len(A)].eid) if i>=len(A) else 'r'+str(i) for i in ids]
    out.append(pd.DataFrame({'cohort':cohort,'id':eid,'idx':ids,'label':y[ids],'uncalibrated':raw,'calibrated':prob,'group':groups,'similarity':distances[cohort]}))
   pd.concat(out,ignore_index=True).to_csv(prefix.with_suffix('.csv'),index=False)
   rec=dict(design=design,seed=int(seed),model=name,seconds=time.monotonic()-start,code_hashes=code,input_hashes=hashes,protocol_sha256=freeze['sha256'],calibration=list(map(float,ab)),training=extra,train_n=len(tr),valid_n=len(va),policy_n=len(pv),outputs={k:len(v) for k,v in targets.items()})
   receipt.write_text(json.dumps(rec,indent=2));print(f'{design} seed={seed} {name}: {rec["seconds"]:.2f}s',flush=True)
 print('All registered feasible model fits complete.',flush=True)
if __name__=='__main__':main()
