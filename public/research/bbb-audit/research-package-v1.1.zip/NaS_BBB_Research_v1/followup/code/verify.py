"""Independent invariant checks and representative deterministic refits."""
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np,pandas as pd
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import Descriptors,rdFingerprintGenerator
from rdkit.Chem.MolStandardize import rdMolStandardize as MS
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score,brier_score_loss
from scipy.special import expit,logit
import torch
import base_models as B
import analyze as Z

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);R=ap.parse_args().root;D=R/'results';V=R/'verification';V.mkdir(exist_ok=True);O=R.parent/'study_v1';A=pd.read_csv(O/'results/cohort_audit.csv',keep_default_na=False);E=pd.read_csv(D/'external_audit.csv',keep_default_na=False);sp=pd.read_csv(D/'memberships.csv');sim=np.load(O/'results/similarity.npy');checks={};RDLogger.DisableLog('rdApp.*')
 freeze=json.loads((R/'protocol/FREEZE.json').read_text());assert hashlib.sha256((R/'protocol/PROTOCOL_v1.md').read_bytes()).hexdigest()==freeze['sha256'];checks['frozen_protocol_unchanged']=True
 for r in json.loads((R/'source_manifest.json').read_text()):assert hashlib.sha256((R/r['file']).read_bytes()).hexdigest()==r['sha256']
 checks['source_hashes_verified']=True
 for (design,seed),ss in sp.groupby(['design','seed']):
  parts={p:x.rid.to_numpy() for p,x in ss.groupby('partition')}
  for p,ids in parts.items():assert len(set(ids))==len(ids);assert A.iloc[ids].status.eq('eligible').all()
  pp=list(parts)
  for i,p in enumerate(pp):
   for q in pp[i+1:]:assert not(set(A.iloc[parts[p]].base_group)&set(A.iloc[parts[q]].base_group))
  if design.startswith('matched'):
   assert len(parts['train'])==300 and A.iloc[parts['train']].label.sum()==150
   assert len(parts['test'])==100 and A.iloc[parts['test']].label.sum()==50
   limit={'matched_strict':.4,'matched_moderate':.6,'matched_broad':.9}[design];assert sim[np.ix_(parts['test'],parts['train'])].max()<limit
 for seed in range(21,26):
  for part in ['test','valid','policy']:
   sets=[set(sp[(sp.seed==seed)&sp.design.eq(d)&sp.partition.eq(part)].rid) for d in ['matched_strict','matched_moderate','matched_broad']];assert sets[0]==sets[1]==sets[2]
 checks['all_split_group_count_label_threshold_invariants']=True
 keys=['canonical','neutral','tautomer','stereofree_tautomer'];sourcekeys={k:set(A[k])- {''} for k in keys};overlaps=[]
 for r in E.itertuples():
  flags={k:bool(getattr(r,k)) and getattr(r,k) in sourcekeys[k] for k in keys};overlaps.append(dict(eid=r.eid,dataset=r.dataset,status=r.status,**flags))
  if r.status=='eligible':assert not any(flags.values());assert float(r.max_original_similarity)<.9
 pd.DataFrame(overlaps).to_csv(V/'overlap_keys.csv',index=False);checks['external_representation_and_near_identity_exclusions']=True
 retained=E[E.status.eq('eligible')].reset_index(drop=True);retained['idx']=np.arange(len(retained))+len(A)
 mols=[Chem.MolFromSmiles(r.neutral or r.canonical) for r in A.itertuples()]+[Chem.MolFromSmiles(s) for s in retained.neutral];gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False);fps=[gen.GetFingerprint(m) for m in mols]
 unstable=[]
 for i,r in retained.iterrows():
  n=MS.Uncharger().uncharge(MS.Cleanup(Chem.Mol(mols[len(A)+i])))
  if Chem.MolToSmiles(n)!=r.neutral:unstable.append(r.eid)
  assert abs(max(DataStructs.BulkTanimotoSimilarity(fps[len(A)+i],fps[:len(A)]))-float(r.max_original_similarity))<1e-12
 checks['retained_external_cleanup_idempotence_failures']=unstable
 assert not unstable,unstable
 funcs=[Descriptors.MolWt,Descriptors.MolLogP,Descriptors.TPSA,Descriptors.NumHDonors,Descriptors.NumHAcceptors,Descriptors.NumRotatableBonds,Descriptors.RingCount,Descriptors.FractionCSP3];desc=np.array([[f(m) for f in funcs] for m in mols]);names=['MW','logP','TPSA','HBD','HBA','rotatable_bonds','rings','fraction_sp3'];shifts=[];distances=[]
 for (design,seed,part),ss in sp.groupby(['design','seed','partition']):
  for j,name in enumerate(names):
   v=desc[ss.rid,j];shifts.append(dict(design=design,seed=int(seed),partition=part,descriptor=name,mean=float(v.mean()),sd=float(v.std()),median=float(np.median(v))))
  if part=='test':
   tr=sp[sp.design.eq(design)&sp.seed.eq(seed)&sp.partition.eq('train')].rid.to_numpy();v=sim[np.ix_(ss.rid,tr)].max(axis=1)
   for rid,value in zip(ss.rid,v):distances.append(dict(design=design,seed=int(seed),rid=int(rid),nearest_training_similarity=float(value)))
 pd.DataFrame(shifts).to_csv(D/'analysis/descriptor_distributions.csv',index=False);pd.DataFrame(distances).to_csv(D/'analysis/test_similarity_distributions.csv',index=False)
 receipts=list((D/'runs').glob('*.json'));assert len(receipts)==100
 for f in receipts:
  r=json.loads(f.read_text());assert r['protocol_sha256']==freeze['sha256']
  for name,h in r['input_hashes'].items():assert hashlib.sha256((D/name).read_bytes()).hexdigest()==h
  for name,h in r['code_hashes'].items():assert hashlib.sha256((R/'code'/name).read_bytes()).hexdigest()==h
  p=pd.read_csv(f.with_suffix('.csv'));assert p.calibrated.between(0,1).all()
 checks['all_100_fit_receipts_verified']=True
 # Independent weighted sklearn checks of the vectorized paired-bootstrap metric kernel.
 p=pd.read_csv(D/'runs/external__21__mpnn.csv');p=p[p.cohort.eq('tong_s')];rng=np.random.default_rng(889);weights=rng.integers(0,4,size=(20,len(p)));v=Z.boot_metrics(p.label.to_numpy(),p.calibrated.to_numpy(),weights)
 for i,w in enumerate(weights):assert abs(v[i,0]-roc_auc_score(p.label,p.calibrated,sample_weight=w))<1e-12;assert abs(v[i,1]-brier_score_loss(p.label,np.clip(p.calibrated,1e-7,1-1e-7),sample_weight=w))<1e-12
 checks['weighted_metric_kernel_independent_checks']=40
 # Refit one registered external classical and graph model from the frozen rows.
 ss=sp[sp.design.eq('external')&sp.seed.eq(21)];tr=ss[ss.partition.eq('train')].rid.to_numpy();va=ss[ss.partition.eq('valid')].rid.to_numpy();y=np.r_[A.label.to_numpy(),retained.label.to_numpy()];graphs=[B.graph(m) for m in mols];torch.set_num_threads(2);replays=[]
 for name in ['descriptor_lr','mpnn']:
  original=pd.read_csv(D/f'runs/external__21__{name}.csv',float_precision='round_trip');rec=json.loads((D/f'runs/external__21__{name}.json').read_text());ids=original.idx.to_numpy()
  if name=='descriptor_lr':
   model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,solver='liblinear',random_state=21));model.fit(desc[tr],y[tr]);vp=model.predict_proba(desc[va])[:,1];raw=model.predict_proba(desc[ids])[:,1];history=True
  else:
   model,extra=B.fit_graph(graphs,y,tr,va,21);vp=B.predict_graph(model,graphs,va)
   # Preserve cohort batch boundaries, which can affect low-order floating point sums.
   raw=np.concatenate([B.predict_graph(model,graphs,x.idx.to_numpy()) for _,x in original.groupby('cohort',sort=False)]);history=extra==rec['training'];assert history
  ab=B.calibrate(y[va],vp);pc=expit(ab[0]*logit(np.clip(raw,1e-7,1-1e-7))+ab[1]);rawdiff=float(np.max(np.abs(raw-original.uncalibrated.to_numpy())));caldiff=float(np.max(np.abs(pc-original.calibrated.to_numpy())));assert caldiff<1e-12,(name,caldiff)
  if name=='mpnn':assert np.array_equal(raw,original.uncalibrated.to_numpy(dtype=np.float32)), 'Graph raw float32 values must reproduce exactly after CSV roundtrip'
  else:assert rawdiff<1e-12,(name,rawdiff)
  replays.append(dict(model=name,design='external',seed=21,records=len(ids),maximum_raw_difference=rawdiff,maximum_calibrated_difference=caldiff,raw_values_identical_in_native_dtype=True,graph_history_identical=history if name=='mpnn' else None));print('Refit verified',replays[-1],flush=True)
 checks['representative_refits']=replays;checks['verified_input_hashes']={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [O/'results/cohort_audit.csv',O/'results/similarity.npy']};(V/'checks.json').write_text(json.dumps(checks,indent=2));print('All checks passed.',flush=True)
if __name__=='__main__':main()
