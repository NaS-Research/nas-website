"""Post hoc reporting diagnostics; does not change the frozen analyses or policies."""
from pathlib import Path
import argparse
import pandas as pd

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);root=ap.parse_args().root;D=root/'results/analysis';S=pd.read_csv(D/'metrics_by_seed.csv');Q=pd.read_csv(D/'selective_metrics_by_seed.csv')
 mix=Q.merge(S[['design','seed','cohort','model','n','positive','sensitivity','specificity']],on=['design','seed','cohort','model'],suffixes=('','_full'));prior=mix.positive/mix.n_full
 mix['standardized_selected_error']=prior*(1-mix.sensitivity)+(1-prior)*(1-mix.specificity);mix['standardized_error_reduction']=mix.full_error-mix.standardized_selected_error
 mix['case_mix_only_error']=(mix.accepted_positive*(1-mix.sensitivity_full)+mix.accepted_negative*(1-mix.specificity_full))/mix.accepted;mix['case_mix_component']=mix.full_error-mix.case_mix_only_error;mix['within_class_component']=mix.case_mix_only_error-mix.error;mix['analysis_status']='post hoc descriptive diagnostic';mix.to_csv(D/'selection_class_mixture_diagnostic.csv',index=False)
 cols=['design','seed','cohort','model','score','nominal_coverage','n','accepted','accepted_positive','accepted_negative','coverage','positive_coverage','negative_coverage','full_error','error','balanced_accuracy','sensitivity','specificity'];base=mix[cols].copy();base['always_positive_full_error']=1-prior;base['always_positive_accepted_error']=mix.accepted_negative/mix.accepted;base['improvement_over_always_positive_accepted']=base.always_positive_accepted_error-base.error;base['analysis_status']='post hoc descriptive baseline; not a frozen hypothesis';base.to_csv(D/'majority_baseline_diagnostic.csv',index=False)
 V=pd.read_csv(D/'selective_risk_comparisons.csv');keys=['design','cohort','model','score','nominal_coverage'];minimum=Q.groupby(keys).coverage.min().rename('minimum_seed_coverage').reset_index();sensitivity=V.merge(minimum,on=keys);sensitivity['passes_every_seed_coverage_sensitivity']=sensitivity.research_usefulness_criterion & sensitivity.minimum_seed_coverage.ge(.5);sensitivity['analysis_status']='post hoc stricter interpretation; original criterion retained';sensitivity.to_csv(D/'criterion_implementation_sensitivity.csv',index=False)
 cautions=S[['design','seed','cohort','n','positive']].drop_duplicates();cautions['negative']=cautions.n-cautions.positive;cautions['meets_external_20_per_class_rule']=(cautions.positive>=20)&(cautions.negative>=20);cautions['interpretation']='Conditional fixed-model evaluation; nested subsets are not independent cohorts';cautions.to_csv(D/'cohort_cautions.csv',index=False)
 print('Post hoc class-mixture, majority-baseline and criterion-sensitivity diagnostics saved.',flush=True)
if __name__=='__main__':main()
