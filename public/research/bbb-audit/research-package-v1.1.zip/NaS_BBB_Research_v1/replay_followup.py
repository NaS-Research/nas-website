"""Rebuild the computational follow-up from original-host inputs into private storage."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,json,os,shutil,subprocess,sys

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--work',type=Path,required=True,help='New empty private directory outside the release package')
 args=parser.parse_args();package=Path(__file__).resolve().parent;work=args.work.resolve()
 if work==package or package in work.parents:raise SystemExit('Private outputs must be outside the public package.')
 if work.exists() and any(work.iterdir()):raise SystemExit('Use a new empty directory; this fresh-replay entry point never replaces existing evidence.')
 expected=(package/'followup/code/requirements.lock').read_text().splitlines()
 for line in expected:
  name,version=line.split('==');actual=importlib.metadata.version(name)
  if actual!=version:raise SystemExit(f'Environment mismatch: {name}: expected {version}, found {actual}')
 if sys.version_info[:2]!=(3,12):raise SystemExit('Use Python 3.12 with the pinned requirements; other versions are unverified.')
 work.mkdir(parents=True,exist_ok=True);original=work/'study_v1';followup=work/'followup_v1';original.mkdir();followup.mkdir()
 for folder in ['code','protocol']:
  shutil.copytree(package/'followup'/folder,followup/folder)
 shutil.copy2(package/'followup/source_manifest.json',followup/'source_manifest.json')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
 def run(script,*args):
  subprocess.run([sys.executable,'-B',str(script),*map(str,args)],cwd=work,env=env,check=True)
 run(package/'audit/fetch_sources.py','--work',original)
 run(package/'audit/prepare.py','--source',original,'--output',original/'results')
 # Pin every external download; partial files never acquire their final names.
 for entry in json.loads((followup/'source_manifest.json').read_text()):
  dest=followup/entry['file'];dest.parent.mkdir(exist_ok=True);part=dest.with_name(dest.name+'.partial')
  subprocess.run(['curl','--fail','--location','--silent','--show-error','--retry','2','--max-time','90',entry['url'],'--output',str(part)],check=True)
  if hashlib.sha256(part.read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('Upstream source changed: '+entry['file'])
  part.rename(dest)
 for name in ['prepare.py','models.py','analyze.py','verify.py']:
  run(followup/'code'/name,'--root',followup)
 run(package/'release_diagnostics.py','--root',followup)
 (work/'REPLAY_COMPLETE.json').write_text(json.dumps({'status':'finished','python':sys.version,'inputs':'downloaded from original hosts and hash verified','registered_followup_runs':100,'scope':'Follow-up full fresh training; original study inputs reconstructed, original 200 fits not rerun by this entry point','independent_scientific_review':False},indent=2))
 print('Fresh computational follow-up replay completed. All molecular outputs remain in private storage.',flush=True)
if __name__=='__main__':main()
