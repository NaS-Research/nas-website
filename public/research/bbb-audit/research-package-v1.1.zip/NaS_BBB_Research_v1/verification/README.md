# Verification evidence

The original audit's published aggregate comparison receipts are in `audit/verification/`. Its full 200-run replay was completed during the original study. The newly performed follow-up replay starts with fresh downloads, freshly reconstructed cohorts and 100 newly fitted model runs; it uses the same verified pinned runtime. It is not independent human review or cross-platform validation.

`fresh_followup_replay.json` provides per-run differences, table comparisons, byte-identical preparation evidence and the explicitly retained selective-log-loss precision exception. Non-forest calibrated predictions reproduced exactly. Forest differences were at numerical precision scale. No retention, classification or research-criterion outcome changed.

`aggregate_comparison.json` is the output of the public comparison script against release tables. The script reports all nonzero numeric changes rather than silently passing every floating-point deviation. Values exceeding 1e-7 must be read with the methods addendum; one three-record random-forest selective log loss differs by 1.47e-7 in two tables containing that same statistic.

The additional diagnostics were uniformly applied after outcomes and are explicitly post hoc. Original frozen protocol/analysis/model files are unchanged. Both PDFs are unchanged copies of already visually checked reports: 18 audit pages and nine follow-up pages. Final author details and any review-driven revision will create new final editions rather than silently alter these preserved reports.
