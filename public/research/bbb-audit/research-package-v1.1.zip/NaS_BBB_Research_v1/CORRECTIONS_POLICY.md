# Versioning and corrections

Never silently replace released scientific files. Each public edition should have its own version, date, archive and checksums. A correction must state which claims or files changed, why, when the issue was discovered relative to outcomes, and whether conclusions changed. Preserve superseded versions and label them clearly.

Numerical bugs, data-provenance errors, changed source availability and interpretive corrections all warrant an entry. New hypotheses and endpoint-resolved experiments receive separate protocols and study versions. Add a public issue/contact channel when the owner approves a repository or archive; none exists yet for this unpublished candidate.
