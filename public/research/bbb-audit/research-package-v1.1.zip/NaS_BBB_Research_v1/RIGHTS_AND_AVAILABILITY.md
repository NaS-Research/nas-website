# Rights and availability

This is a computational-research companion package. The package provides reports, aggregate results, our analysis implementations and original-host retrieval instructions. It does not redistribute molecular datasets, per-compound predictions, checkpoints or the private compound evidence register.

The original publisher supplement metadata declare CC BY-NC 4.0, while downstream TDC/Dataverse statements differ. The B3DB repository supplies a CC0 license statement, but upstream records and provenance still require attention. No sufficiently clear S-data dataset redistribution grant was established from the inspected Tong repository materials. We therefore do not infer that a public repository, a paper's open-access license, or a downstream label resolves every data-use permission.

Source-specific attribution, pinned URLs and hashes appear in `audit/inputs.json`, `audit/REFERENCES.md`, `audit/RIGHTS.md`, and `followup/source_manifest.json`. Private record-level artifacts can be reconstructed from original-host downloads if the user has the necessary rights. This is not a blanket legal clearance or permission to use restricted inputs commercially. Source unavailability/hash drift is an explicit reproduction failure, never a reason to silently substitute data.

The original authors' datasets and software retain their own conditions. No license over third-party material is created by this package. Public availability does not grant a new permissive or commercial license to NaS-authored code, text or figures. All existing rights notices remain applicable.

The combined report is available at https://nasresearch.bio/research/blood-brain-barrier-prediction-audit. This website release has no assigned DOI.
