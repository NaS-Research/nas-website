# Dated release-stage methods addendum

27 September 2026. Written after all original and follow-up outcomes were known. This addendum clarifies reporting and adds descriptive scrutiny checks; it does not replace the frozen protocols, retune models or recalculate the primary analyses under a favorable specification.

## Protocol status and amendments

“Frozen” and “registered” in these materials mean a local dated, hashed protocol. No public preregistration service, third-party timestamp or independently witnessed registration was used. Local hashes establish integrity against the archived version, not independently provable chronology. Prior development-only work was known when the original protocol was written; prior audit outcomes were known when the follow-up protocol was written. The audit's amendments and numerical corrections are distributed verbatim in `audit/protocol/`.

## Follow-up criterion implementation

The follow-up protocol specified >=5 percentage points less error, >=50% achieved coverage, >=30% each-class coverage, at least 20 accepted records per class, and a positive paired 95% lower bound. The implementation operationalized overall coverage as the five-seed mean, while requiring the class coverage and accepted-class counts in every seed. This is how the report's counts of passing settings were computed. It is not a guarantee that every seed retained half the records.

The implementation additionally required >=950 valid bootstrap replicates. That numerical adequacy safeguard was not explicitly written into the frozen protocol and must not be described as a preregistered threshold. All 90 primary S-data settings had 1,000 valid replicates, so this safeguard did not change any primary S-data pass/fail decision. Some sparse subsets had fewer valid replicates.

A release-stage sensitivity requires >=50% achieved coverage in every seed, preserving all other original gates. Its complete table is `followup/aggregates/criterion_implementation_sensitivity.csv`. This stricter interpretation is post hoc and is reported alongside, never substituted for, the original implementation. This sensitivity changes primary S-data passing settings from 22/72 to 21/72; broad/moderate/strict controlled counts change from 7/15/11 to 6/14/9. No distant external setting passes under either interpretation. The headline descriptor-confidence example already meets this stricter coverage requirement.

## Majority-class and class-mixture checks

The primary external cohort is 353/428 positive. Always predicting positive therefore gives 82.48% full-cohort accuracy without a useful discriminator. The relevant comparison after abstention must use the retained class mixture, not this original prevalence. `majority_baseline_diagnostic.csv` reports that comparison for every policy and seed. For the illustrative descriptor-confidence setting, mean always-positive accepted error is about 11.71%, compared with model error 5.55%; neither number resolves the weak negative-class performance.

The report's standardized accepted error uses the original cohort prevalence and the accepted subset's within-class error rates. This is a descriptive reweighting, not a causal estimate of performance on rejected molecules, clinical benefit, or statistical validation of a new policy. The mixture decomposition is convention-dependent; all its definitions and rows are supplied.

## Multiplicity, dependence and fairness of comparison

Policy thresholds came from separate policy-validation records. External scores did not tune those thresholds, but all 72 nonrandom settings per population were inspected. Pointwise policy intervals are exploratory and are not corrected across the full policy grid. The main three-model contrast intervals are adjusted only within each metric/population, not across every metric, cohort and analysis in the release.

Shared molecular-group bootstrap weights account for repeated test-group appearances in the follow-up. They do not resample training, independently replicated assays, or entirely new laboratories. Two secondary external cohorts fall below the frozen minority-class requirement; their discrimination metrics remain diagnostic, not reliable ranking evidence. Distant subsets are nested, not independent datasets.

The graph architecture is a fixed, from-scratch implementation without a hyperparameter search or a pretrained comparison. Common fixed validation records make controlled comparisons consistent but may fit some training distributions better than others. Thus neither model ranking nor changing similarity restrictions identifies a universal model-family effect or a single biological cause.

## Endpoint and representation limits

Binary BBB labels combine different measurements and inferred annotations. They are not interchangeable with unbound brain exposure, therapeutic target engagement or clinical efficacy. Salts, charge, tautomer and stereochemistry conventions are computational representations, not measured physiological states. Stereo-free matches were conservatively excluded/grouped; they do not prove chemically identical compounds. Assay-level independence remains unresolved.

## Review status

Comparisons against independent metric implementations and fresh numerical replays are within-project computational checks. They are not independent scientific peer review. No reviewer's endorsement is claimed.

## Release-stage full replay and numerical exception

After the reports were completed, the release replay freshly downloaded pinned sources, reconstructed original inputs and follow-up memberships, and retrained all 100 follow-up runs. Original and follow-up preparation files matched byte-for-byte. Non-forest calibrated predictions and graph histories reproduced exactly. The maximum forest calibrated difference was 7.48e-8, arising from raw probability differences at <=2.22e-16 and subsequent numerical calibration.

The previously used 1e-7 aggregate precision gate was exceeded by one selective log-loss result: a random-forest similarity policy accepting only three distant S-data records differed by 1.47e-7. The same value appears again in the derived class-mixture table. This failure is disclosed, not hidden by widening every gate. Recalculation from the same retained record IDs and their saved probabilities reproduced both values and bounded the change by the analytic probability-perturbation bound. All retention, classification and research-criterion outcomes were unchanged. The full verification receipt preserves the exception and its interpretation. Do not describe this fresh replay as universally bitwise identical or externally independent.

## Public checksum formatting

The audit protocol text and all amendment texts are unchanged. Its checksum sidecar retains the same digest but uses the protocol filename rather than the private original absolute path. This is a public metadata sanitization, not a change to the frozen scientific protocol.
