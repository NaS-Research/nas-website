# Reproducibility evidence and numerical limits

Original execution completed200 fits. Fresh source downloads reproduced the cohort audit, split membership, split diagnostics, preparation summary and similarity matrix byte-for-byte. A full independent200-fit training replay ran in the isolated pinned environment. The exact replay.sh entry point subsequently completed in a second isolated environment, resuming those already replayed fits and recomputing provenance, preparation, inference and diagnostics.

All four non-forest models reproduced saved probabilities exactly, including all40 graph training histories. Forest raw probabilities differed by at most2.22e-16, consistent with order-dependent parallel summation. Validation calibration amplified the largest calibrated probability difference to2.131e-7. The largest metric difference was7.20e-8; rank and threshold metrics were unchanged. A universal1e-12 comparison initially failed and is not claimed to have passed. The documented RF-only numerical tolerance is1e-6 for calibrated probabilities/coefficients and1e-7 for calibrated Brier,log loss,ECE. All other probability and rank/threshold checks retain1e-12. This is numerical reproduction, not universal bitwise identity.

Fifteen statistical/diagnostic tables reproduced within1e-6, with exact integer/category fields. All three-decimal seed means were identical. Independent weighted formulas passed3600 checks against standard metric calculations, plus180 synthetic tests. CSV predictions require float_precision='round_trip'. Graph outputs originally used float32; final reports use float64 from saved probabilities, with legacy receipts separately verified in their original precision and order.

To compare two private complete executions:

```sh
python verify_replay.py --reference FIRST/results --replay SECOND/results --output model_comparison.json
python verify_tables.py --reference FIRST/results --replay SECOND/results --output table_comparison.json
```

The primary paired intervals condition on five fixed splits. An explicitly exploratory shared-group bootstrap additionally preserves repeated-molecule dependence across those tests. Both are retained; the favorable interval is not selected. No experiment, label or model was chosen to force a positive finding.
