# Rights and use boundary

This study was conducted as noncommercial computational research. Original publisher supplement metadata declare CC BY-NC4.0. The TDC Dataverse parent declares CC0, while the TDC task page has inconsistent license information. An unrestricted downstream redistribution chain is not established.

This candidate contains code, aggregate findings, references and paper/figure artifacts. It excludes downloaded molecular tables and derived record-level molecular outputs. Replay downloads upstream records directly with hash checks; it does not bypass their conditions. Noncommercial restrictions can apply to private use as well as distribution. No commercial-use clearance or independent legal determination is asserted.

Original data sources and authors must be attributed, and transformations are documented in the study. Software dependencies retain their own licenses. No blanket new license is assigned to upstream material by this package, and no claim is made that a code-only package converts restricted data into unrestricted data. The candidate is unpublished; external release remains a separate authorization decision.

Sources:
- Publisher text supplement metadata: https://api.figshare.com/v2/articles/2511184
- Publisher spreadsheet metadata: https://api.figshare.com/v2/articles/2511187
- TDC Dataverse parent: https://doi.org/10.7910/DVN/21LKWG
- TDC task: https://tdcommons.ai/single_pred_tasks/adme/#bbb-blood-brain-barrier-martins-et-al
- CC BY-NC4.0: https://creativecommons.org/licenses/by-nc/4.0/legalcode.en
- CC data-mining FAQ: https://creativecommons.org/faq/#can-i-conduct-textdata-mining-on-a-cc-licensed-database
