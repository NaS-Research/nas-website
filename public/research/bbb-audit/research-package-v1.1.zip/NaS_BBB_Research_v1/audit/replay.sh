#!/bin/sh
set -eu
# Noncommercial research only. Downloads/outputs remain outside distribution.
# Usage: sh replay.sh /absolute/private/work [python3.12-executable]
WORK=${1:?Supply a private output directory outside this code package}
BASE_PYTHON=${2:-python3}
CODE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$WORK"
if [ ! -x "$WORK/environment/bin/python" ]; then
  "$BASE_PYTHON" -m venv "$WORK/environment"
fi
PY="$WORK/environment/bin/python"
"$PY" -m pip install --disable-pip-version-check -r "$CODE/requirements.lock"
"$PY" "$CODE/fetch_sources.py" --work "$WORK"
"$PY" "$CODE/provenance.py" --root "$WORK" --output "$WORK/provenance"
"$PY" "$CODE/prepare.py" --source "$WORK" --output "$WORK/results"
"$PY" "$CODE/models.py" --results "$WORK/results"
"$PY" "$CODE/inference.py" --results "$WORK/results"
"$PY" "$CODE/diagnostics.py" --results "$WORK/results"
"$PY" "$CODE/overlap_sensitivity.py" --results "$WORK/results"
"$PY" -m pip freeze > "$WORK/installed_requirements.lock"
printf '%s\n' 'Completed computational replay. No publication or data redistribution performed.'
