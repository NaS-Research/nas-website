"""Frozen-protocol cohort preparation. Private outputs contain molecular records."""
import argparse, ast, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd
from rdkit import Chem, DataStructs, RDLogger
from rdkit.Chem import rdFingerprintGenerator
from rdkit.Chem.MolStandardize import rdMolStandardize as MS
from rdkit.Chem.Scaffolds import MurckoScaffold
from sklearn.model_selection import GroupShuffleSplit
from tqdm import tqdm

class Union:
    def __init__(self,n): self.p=list(range(n))
    def find(self,a):
        while self.p[a]!=a:
            self.p[a]=self.p[self.p[a]];a=self.p[a]
        return a
    def join(self,a,b):
        a,b=self.find(a),self.find(b)
        if a!=b:self.p[max(a,b)]=min(a,b)
    def keys(self,keys):
        seen={}
        for i,k in enumerate(keys):
            if k in seen:self.join(i,seen[k])
            else:seen[k]=i
    def labels(self):return np.array([self.find(i) for i in range(len(self.p))])

def grouped(ids,groups,seed,fraction):
    a,b=next(GroupShuffleSplit(n_splits=1,test_size=fraction,random_state=seed).split(ids,groups=groups[ids]))
    return ids[a],ids[b]

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);raw=a.source/'raw'
    for e in json.loads((a.source/'source_manifest.json').read_text()):
        if 'sha256' in e:assert hashlib.sha256((a.source/e['file']).read_bytes()).hexdigest()==e['sha256'],e['file']
    RDLogger.DisableLog('rdApp.*')
    df=pd.read_csv(raw/'bbb_martins.tab',sep='\t').drop_duplicates().reset_index(drop=True)
    df['rid']=np.arange(len(df));df['label']=df.Y.astype(int)
    triple=lambda r:(str(r.Drug_ID),r.Drug,int(r.Y))
    lookup={triple(r):int(r.rid) for r in df.itertuples()}
    official={part:np.array([lookup[triple(r)] for r in pd.read_csv(raw/f'official_{part}.csv').itertuples()]) for part in ['train_val','test']}
    assert len(set(official['train_val'])&set(official['test']))==0
    assert set(np.concatenate(list(official.values())))==set(df.rid)
    records=[];gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False)
    for r in df.itertuples():
        m=Chem.MolFromSmiles(r.Drug);assert m is not None
        row=dict(rid=int(r.rid),name=str(r.Drug_ID),source_smiles=r.Drug,label=int(r.Y),canonical=Chem.MolToSmiles(m),original_scaffold=MurckoScaffold.MurckoScaffoldSmiles(mol=m),fragments=len(Chem.GetMolFrags(m)),original_charge=Chem.GetFormalCharge(m),stereocenters=len(Chem.FindMolChiralCenters(m,includeUnassigned=True)),cleanup='',selected_component='',neutral='',tautomer='',stereofree_tautomer='',scaffold='',status='eligible',error='')
        try:
            c=MS.Cleanup(Chem.Mol(m));row['cleanup']=Chem.MolToSmiles(c)
            fragments=Chem.GetMolFrags(c,asMols=True,sanitizeFrags=True)
            organic=[f for f in fragments if any(at.GetAtomicNum()==6 for at in f.GetAtoms())]
            if len(organic)!=1:row['status']='ambiguous_organic_components'
            else:
                f=organic[0];row['selected_component']=Chem.MolToSmiles(f)
                n=MS.Uncharger().uncharge(f);row['neutral']=Chem.MolToSmiles(n)
                t=MS.TautomerEnumerator().Canonicalize(Chem.Mol(n));row['tautomer']=Chem.MolToSmiles(t)
                row['stereofree_tautomer']=Chem.MolToSmiles(t,isomericSmiles=False)
                row['scaffold']=MurckoScaffold.MurckoScaffoldSmiles(mol=n)
        except Exception as e:row['status']='standardization_failure';row['error']=type(e).__name__+': '+str(e)
        # A nonthrowing alternative route is insufficient to resolve a known
        # standardization failure. Preserve the prior route as a stability check.
        try:
            MS.FragmentParent(Chem.Mol(m))
        except Exception as e:
            row['status']='standardization_failure'
            row['error']='FragmentParent stability check: '+type(e).__name__+': '+str(e)
        if str(r.Drug_ID).casefold()=='mesocarb':
            row['status']='standardization_instability'
            row['error']='Known prior FragmentParent failure and changed ring representation under alternate staged route; quarantined regardless of whether this run throws.'
        records.append(row)
    audit=pd.DataFrame(records)
    eligible=audit.status.eq('eligible')
    conflict=np.zeros(len(df),bool)
    for key in ['neutral','tautomer']:
        bad=audit[eligible].groupby(key).label.nunique();bad=set(bad[bad>1].index)
        audit[key+'_conflict']=audit[key].isin(bad);conflict|=audit[key+'_conflict'].values
    audit.loc[eligible&conflict,'status']='conflicting_representation_labels'
    accepted=audit[audit.status.eq('eligible')]
    reps=accepted.drop_duplicates('neutral').rid.to_numpy()
    repmap=accepted.groupby('neutral',sort=False).rid.first().to_dict()
    audit['representative']=audit.neutral.map(repmap).fillna(-1).astype(int)
    audit.loc[audit.status.eq('eligible')&~audit.rid.isin(reps),'status']='duplicate_member'
    # Base groups cover original rows too, with safe fallback for quarantined rows.
    identity=[r.stereofree_tautomer or r.canonical for r in audit.itertuples()]
    smi=[r.neutral or r.canonical for r in audit.itertuples()]
    fps=[gen.GetFingerprint(Chem.MolFromSmiles(s)) for s in smi]
    sim=np.empty((len(df),len(df)),dtype=np.float64)
    for i,fp in enumerate(fps):sim[i]=DataStructs.BulkTanimotoSimilarity(fp,fps)
    base=Union(len(df));base.keys(identity)
    for i in range(len(df)):
        for j in np.flatnonzero(sim[i,:i]>=.9):base.join(i,int(j))
    groups={'base':base.labels()}
    for name,threshold in [('scaffold',None),('cluster',.6),('strict',.4)]:
        u=Union(len(df));u.keys(groups['base'])
        # Only integrity representatives add scaffold/distance edges.
        if threshold is None:
            seen={}
            for i in reps:
                key=audit.iloc[i].scaffold
                if key in seen:u.join(int(i),seen[key])
                else:seen[key]=int(i)
        else:
            for q,i in enumerate(reps):
                for j in reps[:q][sim[i,reps[:q]]>=threshold]:u.join(int(i),int(j))
        groups[name]=u.labels()
    for k,v in groups.items():audit[k+'_group']=v
    audit.to_csv(a.output/'cohort_audit.csv',index=False)
    np.save(a.output/'similarity.npy',sim)
    tree=ast.parse((raw/'tdc_split.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['create_fold','create_scaffold_split']]
    ns={'np':np,'pd':pd,'tqdm':tqdm,'print_sys':lambda x:None};exec(compile(ast.Module(body=nodes,type_ignores=[]),'pinned_tdc_split','exec'),ns)
    splits=[];diagnostics=[]
    def add(design,seed,tr,va,te,group=None,limit=None):
        ids=[np.array(x,dtype=int) for x in [tr,va,te]]
        assert all(len(set(ids[i])&set(ids[j]))==0 for i,j in [(0,1),(0,2),(1,2)])
        if group is not None:
            assert all(not(set(group[ids[i]])&set(group[ids[j]])) for i,j in [(0,1),(0,2),(1,2)])
        if limit:
            assert all(sim[np.ix_(ids[i],ids[j])].max()<limit for i,j in [(0,1),(0,2),(1,2)])
        for part,x in zip(['train','valid','test'],ids):
            for i in x:splits.append(dict(design=design,seed=seed,partition=part,rid=int(i)))
        diag=dict(design=design,seed=seed,feasible=all(df.iloc[x].Y.nunique()==2 for x in ids))
        for part,x in zip(['train','valid','test'],ids):diag.update({part+'_n':len(x),part+'_positive':int(df.iloc[x].Y.sum())})
        diag['max_test_train_similarity']=float(sim[np.ix_(te,tr)].max());diagnostics.append(diag)
    for seed in range(1,6):
        dev=df.iloc[official['train_val']].copy()
        sp=ns['create_scaffold_split'](dev,seed,[.875,.125,0],'Drug')
        add('official_reference',seed,sp['train'].rid,sp['valid'].rid,official['test'])
        for name,fn in [('random_reference','create_fold'),('scaffold_reference','create_scaffold_split')]:
            sp=ns[fn](df,seed,[.7,.1,.2],*(['Drug'] if 'scaffold' in fn else []))
            add(name,seed,*[sp[k].rid.to_numpy() for k in ['train','valid','test']])
        for name,key,limit in [('clean_random','base',None),('clean_scaffold','scaffold',None),('clean_cluster','cluster',.6),('clean_strict','strict',.4)]:
            dv,te=grouped(reps,groups[key],seed,.2);tr,va=grouped(dv,groups[key],seed,.125)
            add(name,seed,tr,va,te,groups[key],limit)
        # Prefer source-order eligible official test representatives within test.
        ok=set(accepted.rid);test_rows=sorted(ok&set(official['test']))
        te=audit.iloc[test_rows].drop_duplicates('neutral').rid.to_numpy()
        excluded=set(groups['base'][te]);dv=np.array([i for i in reps if i in set(official['train_val']) and groups['base'][i] not in excluded])
        tr,va=grouped(dv,groups['scaffold'],seed,.125)
        # Official partition is not guaranteed scaffold-pure after normalization;
        # base groups must be disjoint across all three, scaffold only train/valid.
        add('official_clean',seed,tr,va,te,groups['base'])
        assert not(set(groups['scaffold'][tr])&set(groups['scaffold'][va]))
    pd.DataFrame(splits).to_csv(a.output/'splits.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(a.output/'split_diagnostics.csv',index=False)
    summary={'source_rows':len(df),'status_counts':audit.status.value_counts().to_dict(),'clean_representatives':len(reps),'split_count':len(diagnostics),'all_splits_both_classes':all(d['feasible'] for d in diagnostics),'group_counts':{k:len(set(v[reps])) for k,v in groups.items()}}
    (a.output/'preparation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
