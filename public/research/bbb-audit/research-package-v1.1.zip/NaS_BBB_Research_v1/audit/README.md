# How Reliable Is BBBP?

NaS Research — NAS-BBB-001, version 1.0 candidate, 27 September 2026.
Unpublished computational replication and extension; not peer reviewed.

The paper and FULL_REPORT.md explain the results and limitations. The aggregates directory supplies all nine metrics, uncertainty estimates, calibration and diagnostic summaries. The figures directory includes editable SVG and lossless PNG masters. No molecular datasets, record-level predictions, model checkpoints or compound-level evidence register are distributed.

## Replay

Requirements: Python 3.12, curl, an internet connection for original-host downloads, and local CPU/storage capacity. The tested runtime is Python 3.12.14 on Apple Silicon macOS, with exactly pinned dependencies. Other platforms are not claimed numerically identical. No GPU, paid compute or account credentials are required.

From this directory:

```sh
sh replay.sh /absolute/path/to/private-replay python3.12
```

Choose a work directory outside this package. The script creates an isolated environment, installs the lockfile, downloads source files directly from their hosts, checks every SHA-256, reconstructs provenance/cohorts/splits, executes 200 fits, and generates metrics, bootstrap intervals and diagnostics. Downloaded and generated molecular records remain in that private directory. Upstream hash drift stops execution; do not silently update expected hashes.

Resuming an existing directory verifies input and model-code hashes before skipping completed fits. Delete nothing to force a restart; use a separate empty work directory for an independent run. The provenance stage also repeats the disclosed development-only feasibility pilot; those pilot scores are not the paper's held-out results.

## Reading the results

- Official fixed runs reuse one 406-row test; five seeds are not five independent tests.
- The integrity cohort has 1,935 representatives and uses retrospective label-informed conflict exclusion. No label correction is established.
- Strict distance splits change composition and test size substantially. They are not prospective validation.
- The graph model improves over Morgan LR on strict-distance AUROC, but the simpler PSA rule has a higher mean AUROC there. The forest contrast includes zero under overlap-aware resampling.
- Sampling/group resampling, split/training-seed variation and label sensitivity do not estimate missing experimental uncertainty.

See REPLAY_NOTES.md for measured numerical reproducibility, RIGHTS.md for unresolved data-license differences, and REFERENCES.md for original sources. Nothing in this candidate authorizes commercial data use or establishes clinical validity.

Subgroup results are included with sparse-cell metrics suppressed as described in FULL_REPORT.md. Full record-level tables remain private.
