"""Verify reproducibility of all completed aggregate and private diagnostic tables."""
import argparse,json
from pathlib import Path
import pandas as pd,numpy as np
p=argparse.ArgumentParser();p.add_argument('--reference',type=Path,required=True);p.add_argument('--replay',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();checks=[]
for sub in ['statistics','diagnostics']:
 for f in sorted((a.reference/sub).glob('*.csv')):
  other=a.replay/sub/f.name;assert other.exists(),other
  x=pd.read_csv(f,float_precision='round_trip');y=pd.read_csv(other,float_precision='round_trip');assert x.shape==y.shape and list(x)==list(y),(sub,f.name)
  maximum=0.
  for col in x:
   if pd.api.types.is_numeric_dtype(x[col]):
    tol=0 if pd.api.types.is_integer_dtype(x[col]) or pd.api.types.is_bool_dtype(x[col]) else 1e-6
    assert np.allclose(x[col],y[col],rtol=0,atol=tol,equal_nan=True),(sub,f.name,col)
    difference=np.abs(x[col].to_numpy(dtype=float)-y[col].to_numpy(dtype=float));maximum=max(maximum,float(np.nanmax(difference)) if np.isfinite(difference).any() else 0)
   else:assert x[col].fillna('').equals(y[col].fillna('')),(sub,f.name,col)
  checks.append(dict(table=sub+'/'+f.name,rows=len(x),max_absolute_difference=maximum))
sx=pd.read_csv(a.reference/'statistics/seed_summary.csv',float_precision='round_trip');sy=pd.read_csv(a.replay/'statistics/seed_summary.csv',float_precision='round_trip');assert np.array_equal(sx['mean'].round(3),sy['mean'].round(3))
r=dict(tables=checks,all_three_decimal_seed_means_identical=True,numeric_tolerance=1e-6,integer_and_category_fields_exact=True)
a.output.write_text(json.dumps(r,indent=2));print(f'Verified {len(checks)} tables and all three-decimal seed means.')
