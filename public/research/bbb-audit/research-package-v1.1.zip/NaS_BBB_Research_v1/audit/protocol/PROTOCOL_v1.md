# BBBP integrity and reproducibility study: frozen protocol v1

Frozen 2026-09-27 UTC before main performance experiments. Noncommercial research only. This is a replication and extension, not a claim of priority or biological validation. Preserve this file; amendments must be separately dated and explain timing relative to result access.

## Prior information
The investigation_v2 feasibility study already examined provenance, duplicate/conflict counts, source licensing, five scaffold allocations, connected-component thresholds 0.8/0.6/0.4, and development-only LR/RF performance. A descriptor feasibility fit also ran. No official held-out performance was scored in that investigation. These observations informed feasibility and this protocol; they are not independent confirmatory evidence.

## Questions and estimands
H1: row-level random evaluation gives different performance and similarity distributions from identity-grouped and chemically separated evaluation. H2: integrity rules change evaluation composition and possibly performance. H3: RF and a graph message-passing model may improve over fingerprint logistic regression, but such improvement may not persist under chemical separation. All comparisons are conditional on this benchmark and its undocumented assay mixture. Performance changes across differing cohorts are descriptive, not causal estimates of leakage alone.

Primary comparison is calibrated AUROC difference for RF versus Morgan LR and graph model versus Morgan LR on the strict 0.4 component split. A material gain requires mean AUROC improvement >=0.02, paired 95% interval excluding zero, and mean Brier deterioration <=0.01. These are decision conventions, not clinical thresholds. Other comparisons are exploratory. Report all registered models and seeds, including negative findings. Do not choose splits or models after inspecting test scores.

## Input and provenance
Reuse hash-verified original Martins supplements, MoleculeNet, TDC datafile and official archive. Preserve unmodified source records. Reconstruct the 2053/2050/2039/2030 lineage and report unreconciled historical counts. Keep identifiers private in research tables; public output contains aggregate results and download code only. Upstream noncommercial conditions still apply to replay.

## Representations and integrity cohort
Original-reference models use parsed original TDC structures, retaining all 2030 loader rows and original labels. The official test remains 406 rows.
For integrity-controlled models, RDKit Cleanup is applied with full stage logging. Select a fragment only when exactly one connected component contains carbon; exclude ambiguous multiple-organic-component records. Neutralize with RDKit Uncharger and preserve specified stereochemistry. This is a representation convention, not physiological protonation. Record canonical, component, charged, neutral, tautomer and stereochemistry-free representations. Standardization failures, including mesocarb if it still fails, are quarantined only in the integrity cohort; their original records remain in reference analyses.
Exclude all members of conflicting neutral-parent or tautomer-parent label groups from the integrity cohort, without declaring any label biologically wrong. Collapse remaining identical neutral representations to the first source-order representative, keeping membership tables. Stereo-free tautomer matches are grouped, not treated as interchangeable labels. Group also at Morgan radius 2, 2048-bit Tanimoto >=0.9 via connected components. Fingerprints omit chirality; molecular identity keys retain it. Record this distinction.

## Splits
Seeds 1,2,3,4,5 are fixed. Preserve every membership table and class count.
1. Official reference: exact official test; TDC scaffold training/validation allocation of its development pool with fractions .875/.125 for each seed. These are five fits on one test set, not five independent tests.
2. Original random reference: exact TDC row-level random procedure, fractions .7/.1/.2, each seed.
3. Original repeated scaffold reference: exact TDC scaffold procedure, fractions .7/.1/.2, each seed.
4. Clean grouped random: GroupShuffleSplit test fraction .2 of base groups, then validation fraction .125 of remaining groups, same seed for each step.
5. Clean grouped scaffold: union base groups with identical Murcko scaffold groups, including the empty scaffold as a real common group. Same grouped allocation.
6. Clean similarity: union base groups with fingerprint edges >=.6, same grouped allocation.
7. Clean strict distance: union base groups with fingerprint edges >=.4, same grouped allocation. Transitive groups may be large; report composition shifts and minority-class counts.
8. Official integrity sensitivity: retain eligible official test representatives, choose test membership before dev representatives when a normalized identity straddles partitions, and remove development base groups intersecting test base groups. Allocate remaining development by grouped scaffold .125 validation. Not leaderboard-comparable. Compare reference predictions on the same retained original test rows separately from reference full-test scores.
No class-driven retry of random seeds. If a partition lacks a class, log that registered split as infeasible and report which metrics/models are undefined; do not substitute favorable seeds. Verify group separation and maximum cross-partition similarity where required. Compute test-to-training and test-to-development similarities separately.

## Models and training
No pretraining, no paid compute. Fixed hyperparameters avoid post hoc tuning.
- Physicochemical rule: score -TPSA, with uncalibrated probability sigmoid((90-TPSA)/20). This is an explicitly heuristic polar-surface-area baseline, not a validated permeability formula; 90 and 20 are fixed conventions. Cite primary evidence for polar surface relevance, not for exact coefficients.
- Eight descriptors (MW, logP, TPSA, HBD, HBA, rotatable bonds, ring count, fraction sp3): training-only StandardScaler then LR C=1, liblinear, max_iter=2000.
- Morgan radius2/2048 binary fingerprint LR C=1, liblinear, max_iter=2000.
- Random forest: 300 trees, min_samples_leaf=2, max_features=sqrt, no class weights, fixed seed, bounded local threads.
- Bond-aware graph message-passing network trained from scratch: three 64-dimensional message layers, mean/sum graph readout, 64-dimensional readout hidden layer, Adam lr .001, weight decay .0001, batch64, at most60 epochs, patience10 on validation binary log loss. Save best validation checkpoint. CPU deterministic execution where supported. No architecture search. Report actual parameter count and features in methods/code. If execution cannot finish or fails, retain evidence and a documented omission; do not replace silently.

Sigmoid calibration for every model is fitted to validation predictions only: logistic transform of clipped probabilities with nonnegative slope and intercept, bounded optimization, no test access. Model selection for graph stopping and calibration share validation data; acknowledge this reuse. Primary decisions use calibrated probability >=.5. Also retain uncalibrated probabilities and metrics. Scaling never sees validation/test features during fitting. No test-label-directed model or threshold selection.

## Metrics and uncertainty
Per seed and model: AUROC, average precision (AUPRC convention), balanced accuracy, sensitivity, specificity, MCC, Brier, log loss, 10 equal-width-bin ECE and reliability-bin counts. State positive label=1. Undefined metrics are missing, never silently zero. Report class prevalence and sample sizes.
Report seed means, standard deviations and ranges separately from test-set uncertainty. For official fixed test, bootstrap molecular base groups with replacement, retaining all group rows; use seed-averaged predictions for paired contrasts and intervals. For varying splits, report per-seed group-bootstrap intervals and paired deltas, plus descriptive seed distribution; do not pretend overlapping test sets across seeds are independent observations. Use 1000 bootstrap replicates with fixed random seed 20260927. The primary material-gain rule uses the mean of paired per-seed differences and a paired resampling distribution that resamples test groups within each seed and averages seed differences, explicitly conditional on these five splits and not an independent-population confidence guarantee. Report all two primary contrasts; do not claim familywise significance. Experimental uncertainty is not estimable from absent assay replication metadata.

## Sensitivity and error analysis
Cleaning: report cohort attrition with reasons, raw full official scores, raw common eligible test scores and clean common test scores; changed training and cohort are distinct contributions, not randomized interventions.
Label evidence: maintain a primary-source register. Apply no label changes unless traceable evidence supports the exact record/context; otherwise original labels and conflict exclusion constitute the justified alternatives. Unverified issue383 remains unverified. Any later justified correction is a dated exploratory analysis, never replacement of registered results.
Report nearest-training similarity bins [0,.4),[.4,.6),[.6,.8),[.8,1], scaffold novelty, acyclic status, confidence bins [.5,.6),[.6,.8),[.8,1], descriptor distributions, and errors recurring across seeds. Subgroup metrics require both classes; flag n<30 or either class<10. No mechanistic interpretation from model importance or errors alone. Report applicability-domain restrictions and calibration under shift.

## Verification and deliverables
Require split invariants, source hashes, label preservation, deterministic replay checks, independent metric recomputation from saved predictions, and numerical claim verification. Fresh upstream downloads and a clean pinned environment must replay the pipeline; compare invariant tables and numerical outputs with stated tolerances. Save runtime and failures.
Prepare methods/results report, house-style NaS PDF, exact-data figure masters, audit/evidence tables, code, lockfile, replay, provenance/checksums. Use the shared NaS renderer and inspect every rendered page. Keep generated outputs and study data on the external drive. Public candidate uses an explicit allowlist, excluding molecular records, internal paths, credentials, prompts, publication machinery and workflows; scan archives and metadata. Nothing is published or submitted. Final scientific publication recommendation may be negative or inconclusive.
