"""Obtain inputs directly from their original hosts and fail closed on byte drift."""
import pathlib,subprocess,json,hashlib,zipfile,argparse
p=argparse.ArgumentParser();p.add_argument('--work',type=pathlib.Path,required=True);a=p.parse_args()
base=pathlib.Path(__file__).resolve().parent;entries=json.loads((base/'inputs.json').read_text());(a.work/'raw').mkdir(parents=True,exist_ok=True)
for e in entries:
    dest=a.work/e['file']
    if dest.exists():
        assert hashlib.sha256(dest.read_bytes()).hexdigest()==e['sha256'],e['file']+' existing file hash mismatch'
    elif 'archive_member' in e:
        with zipfile.ZipFile(a.work/'raw/admet_group.zip') as z: dest.write_bytes(z.read(e['archive_member']))
    else:
        subprocess.run(['curl','-fLsS','--retry','2','--max-time','90',e['url'],'-o',str(dest)],check=True)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==e['sha256'],e['file']+' upstream bytes changed; do not silently continue'
    dest.chmod(0o444)
(a.work/'source_manifest.json').write_text(json.dumps(entries,indent=2))
print('Verified all upstream inputs. Keep downloaded data outside the public package.')
