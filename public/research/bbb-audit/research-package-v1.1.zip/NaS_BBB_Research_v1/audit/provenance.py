"""Feasibility audit only. No source labels changed; no held-out model evaluation."""
import argparse, pathlib, csv, io, json, collections, hashlib, time, sys, platform, importlib.metadata, ast
from functools import lru_cache
import numpy as np
import pandas as pd
import xlrd
from rdkit import Chem, DataStructs, RDLogger
from rdkit.Chem import Descriptors, rdFingerprintGenerator
from rdkit.Chem.MolStandardize import rdMolStandardize as MS
from rdkit.Chem.Scaffolds import MurckoScaffold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import roc_auc_score, average_precision_score, balanced_accuracy_score, matthews_corrcoef, brier_score_loss, confusion_matrix
from sklearn.calibration import calibration_curve
from tqdm import tqdm

parser=argparse.ArgumentParser();parser.add_argument('--root',type=pathlib.Path,required=True);parser.add_argument('--output',type=pathlib.Path,required=True)
args=parser.parse_args();raw=args.root/'raw';out=args.output;out.mkdir(parents=True,exist_ok=True)
RDLogger.DisableLog('rdApp.*'); started=time.monotonic()
def save(name,data): (out/name).write_text(json.dumps(data,indent=2,allow_nan=False))
def table(name,rows):
    if not rows: (out/name).write_text('');return
    with (out/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for e in json.loads((args.root/'source_manifest.json').read_text()):
    if 'sha256' in e: assert hashlib.sha256((args.root/e['file']).read_bytes()).hexdigest()==e['sha256'],e['file']

@lru_cache(None)
def characterize(s):
    r={'parse_ok':False,'canonical':'','parent':'','neutral_parent':'','tautomer_parent':'','stereo_free_parent':'','scaffold':'','fragments':0,'charge':None,'stereo_centers':0,'error':''}
    m=Chem.MolFromSmiles(s)
    if m is None: r['error']='RDKit MolFromSmiles failed';return r
    r.update(parse_ok=True,canonical=Chem.MolToSmiles(m,isomericSmiles=True),fragments=len(Chem.GetMolFrags(m)),charge=Chem.GetFormalCharge(m),stereo_centers=len(Chem.FindMolChiralCenters(m,includeUnassigned=True)),scaffold=MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False))
    try:
        p=MS.FragmentParent(Chem.Mol(m));n=MS.Uncharger().uncharge(Chem.Mol(p));t=MS.TautomerEnumerator().Canonicalize(Chem.Mol(n))
        r.update(parent=Chem.MolToSmiles(p,isomericSmiles=True),neutral_parent=Chem.MolToSmiles(n,isomericSmiles=True),tautomer_parent=Chem.MolToSmiles(t,isomericSmiles=True),stereo_free_parent=Chem.MolToSmiles(n,isomericSmiles=False),scaffold=MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False))
    except Exception as e:r['error']=type(e).__name__+': '+str(e)
    return r

datasets={}
def ingest(label,rows,name,smiles,y,idx=None):
    dst=[]
    for i,r in enumerate(rows):
        yy={'p':1,'n':0}.get(r[y],r[y]);s=r[smiles]
        dst.append(dict(dataset=label,row=i,source_id=str(r[idx]) if idx else '',name=str(r[name]),smiles=s,label=int(yy),**characterize(s)))
    datasets[label]=dst
ingest('martins',list(csv.DictReader(io.StringIO((raw/'ci300124c_si_001.txt').read_bytes().decode('latin1')),delimiter='\t')),'name','smiles','p_np','num')
ingest('moleculenet',list(csv.DictReader((raw/'BBBP.csv').open())),'name','smiles','p_np','num')
ingest('tdc_file',list(csv.DictReader((raw/'bbb_martins.tab').open(),delimiter='\t')),'Drug_ID','Drug','Y')
loaded=pd.read_csv(raw/'bbb_martins.tab',sep='\t').drop_duplicates()
ingest('tdc_loader',loaded.to_dict('records'),'Drug_ID','Drug','Y')
for part in ['train_val','test']:
    ingest('official_'+part,list(csv.DictReader((raw/('official_'+part+'.csv')).open())),'Drug_ID','Drug','Y')
print('Parsed all source variants',flush=True)

summaries={};groups_out=[]
for name,rows in datasets.items():
    summary={'rows':len(rows),'positive':sum(r['label'] for r in rows),'negative':sum(1-r['label'] for r in rows),'unparsable':sum(not r['parse_ok'] for r in rows),'standardization_errors':sum(bool(r['error']) and r['parse_ok'] for r in rows),'multifragment':sum(r['fragments']>1 for r in rows),'charged':sum(r['charge'] not in [None,0] for r in rows),'stereocenter_rows':sum(r['stereo_centers']>0 for r in rows)}
    for key in ['smiles','canonical','parent','neutral_parent','tautomer_parent','stereo_free_parent']:
        groups=collections.defaultdict(list)
        for r in rows:
            if r[key]:groups[r[key]].append(r)
        duplicate=[g for g in groups.values() if len(g)>1];conflicts=[g for g in duplicate if len({r['label'] for r in g})>1]
        summary[key]={'unique':len(groups),'duplicate_groups':len(duplicate),'extra_duplicate_rows':sum(len(g)-1 for g in duplicate),'conflicting_groups':len(conflicts),'conflicting_rows':sum(len(g) for g in conflicts)}
        for g in conflicts:groups_out.append(dict(dataset=name,identity_level=key,identity_sha256=hashlib.sha256(g[0][key].encode()).hexdigest(),rows=';'.join(str(r['row']) for r in g),names=';'.join(r['name'] for r in g),labels=';'.join(str(r['label']) for r in g),interpretation='representation-level label conflict; not adjudicated biological error'))
    summaries[name]=summary
table('molecular_audit.csv',[r for rows in datasets.values() for r in rows]);table('label_conflicts.csv',groups_out)

def lineage(left,right):
    index=collections.defaultdict(list)
    for r in datasets[right]:
        if r['canonical']: index[r['canonical']].append(r)
    counts=collections.Counter();details=[]
    for r in datasets[left]:
        hits=index.get(r['canonical'],[]) if r['canonical'] else []
        status='unparsable' if not r['parse_ok'] else ('same_structure_and_label' if any(h['label']==r['label'] for h in hits) else 'same_structure_different_label' if hits else 'no_canonical_match')
        counts[status]+=1;details.append(dict(source=left,source_row=r['row'],source_id=r['source_id'],name=r['name'],target=right,status=status,target_rows=';'.join(str(h['row']) for h in hits)))
    table(left+'_to_'+right+'.csv',details)
    return dict(counts)
lineages={a+'_to_'+b:lineage(a,b) for a,b in [('moleculenet','tdc_file'),('tdc_file','moleculenet'),('official_train_val','tdc_loader'),('official_test','tdc_loader')]}

def cross_stats(train,test):
    result={}
    for key in ['canonical','parent','neutral_parent','tautomer_parent','stereo_free_parent','scaffold']:
        trainset={r[key] for r in train if r['parse_ok'] and (r[key] or key=='scaffold')}
        result[key+'_overlap_test_rows']=sum(r['parse_ok'] and (r[key] or key=='scaffold') and r[key] in trainset for r in test)
    ring_scaffolds={r['scaffold'] for r in train if r['parse_ok'] and r['scaffold']}
    result['nonempty_scaffold_overlap_test_rows']=sum(bool(r['scaffold']) and r['scaffold'] in ring_scaffolds for r in test)
    result['empty_scaffold_train_rows']=sum(r['parse_ok'] and not r['scaffold'] for r in train)
    result['empty_scaffold_test_rows']=sum(r['parse_ok'] and not r['scaffold'] for r in test)
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False)
    fps=[gen.GetFingerprint(Chem.MolFromSmiles(r['neutral_parent'])) for r in train if r['neutral_parent']]
    sims=[];nearest=[]
    for r in test:
        if r['neutral_parent']:
            sim=max(DataStructs.BulkTanimotoSimilarity(gen.GetFingerprint(Chem.MolFromSmiles(r['neutral_parent'])),fps));sims.append(sim)
            nearest.append(dict(test_dataset=r['dataset'],test_row=r['row'],max_train_similarity=sim))
    result.update(n_similarity=len(sims),similarity_mean=float(np.mean(sims)),similarity_median=float(np.median(sims)),similarity_ge_0_8=sum(x>=.8 for x in sims),similarity_ge_0_9=sum(x>=.9 for x in sims),similarity_eq_1=sum(x==1 for x in sims))
    return result,nearest
official,nearest=cross_stats(datasets['official_train_val'],datasets['official_test']);table('official_nearest_similarity.csv',nearest)

# Execute ONLY two inspected top-level functions from the pinned TDC source.
tree=ast.parse((raw/'tdc_split.py').read_text());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['create_fold','create_scaffold_split']]
namespace={'np':np,'pd':pd,'tqdm':tqdm,'print_sys':lambda x:None}
exec(compile(ast.Module(body=selected,type_ignores=[]),'pinned_tdc_split','exec'),namespace)
df=pd.DataFrame(datasets['tdc_loader']);df['Drug']=df.smiles
split_check=[]
for seed in [1,2,3,4,5]:
    sp=namespace['create_scaffold_split'](df,seed,[.7,.1,.2],'Drug')
    split_check.append({'seed':seed,**{k:{'rows':len(v),'positive':int(v.label.sum()),'negative':int((1-v.label).sum())} for k,v in sp.items()}})
rs=namespace['create_fold'](df,42,[.7,.1,.2]);randomstats,_=cross_stats(rs['train'].to_dict('records')+rs['valid'].to_dict('records'),rs['test'].to_dict('records'))

# Compute-only pilot inside official development pool; official test never scored.
dev=[r for r in datasets['official_train_val'] if r['neutral_parent']]
conflict_keys={k for k,g in __import__('itertools').groupby(sorted(dev,key=lambda r:r['neutral_parent']),lambda r:r['neutral_parent']) if len({r['label'] for r in g})>1}
unique={}
for r in dev:
    if r['neutral_parent'] not in conflict_keys:unique.setdefault(r['neutral_parent'],r)
clean=list(unique.values());gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
X=np.array([gen.GetFingerprintAsNumPy(Chem.MolFromSmiles(r['neutral_parent'])) for r in clean]);y=np.array([r['label'] for r in clean]);gs=[MurckoScaffold.MurckoScaffoldSmiles(mol=Chem.MolFromSmiles(r['neutral_parent'])) for r in clean]
tr,va=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42).split(X,y,gs))
pilot=[]
for model in [LogisticRegression(C=1.0,max_iter=2000,solver='liblinear',random_state=42),RandomForestClassifier(n_estimators=100,min_samples_leaf=2,random_state=42,n_jobs=2)]:
    st=time.monotonic();model.fit(X[tr],y[tr]);pr=model.predict_proba(X[va])[:,1];pred=(pr>=.5).astype(int);tn,fp,fn,tp=confusion_matrix(y[va],pred,labels=[0,1]).ravel()
    pilot.append(dict(model=type(model).__name__,seconds=round(time.monotonic()-st,3),AUROC=float(roc_auc_score(y[va],pr)),AUPRC=float(average_precision_score(y[va],pr)),balanced_accuracy=float(balanced_accuracy_score(y[va],pred)),sensitivity=float(tp/(tp+fn)),specificity=float(tn/(tn+fp)),MCC=float(matthews_corrcoef(y[va],pred)),Brier=float(brier_score_loss(y[va],pr)),calibration_bins=[v.tolist() for v in calibration_curve(y[va],pr,n_bins=5,strategy='quantile')]))
pilot_info={'purpose':'compute feasibility only; not study performance evidence','train_rows':len(tr),'validation_rows':len(va),'excluded_conflict_groups':len(conflict_keys),'development_unique_nonconflicting_rows':len(clean),'official_test_scored':False,'threshold':0.5,'hyperparameter_search':False,'results':pilot}
save('pilot_validation.json',pilot_info)
book=xlrd.open_workbook(raw/'ci300124c_si_002.xls');xls=[dict(sheet=s.name,rows=s.nrows,columns=s.ncols,headers=s.row_values(0)) for s in book.sheets()];save('supplement_inventory.json',xls)
result={'datasets':summaries,'lineage':lineages,'official_test_vs_train_val':official,'random_seed42_test_vs_train_val':randomstats,'random_seed42_sizes':{k:len(v) for k,v in rs.items()},'repeated_scaffold_split_check':split_check,'xls_sheets':xls,'source_hash_verification':'passed','elapsed_seconds':round(time.monotonic()-started,2)}
save('investigation_results.json',result)
versions={m:importlib.metadata.version(m) for m in ['rdkit','numpy','pandas','scikit-learn','scipy','xlrd','Pillow','joblib','threadpoolctl','tqdm','cloudpickle','python-dateutil','six']}
save('software_versions.json',dict(python=sys.version,platform=platform.platform(),packages=versions))
(out/'requirements.lock').write_text('\n'.join(k+'=='+v for k,v in versions.items())+'\n')
print(json.dumps({'dataset_sizes':{k:v['rows'] for k,v in summaries.items()},'tdc_loader':summaries['tdc_loader'],'lineage':lineages,'official':official,'random_sizes':result['random_seed42_sizes'],'pilot':pilot_info},indent=2),flush=True)
