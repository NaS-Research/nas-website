"""Compare complete independent executions; runtime timing is not an invariant."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--reference',type=Path,required=True);p.add_argument('--replay',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();checks={}
for name in ['cohort_audit.csv','splits.csv','split_diagnostics.csv','preparation.json','similarity.npy']:
 assert hashlib.sha256((a.reference/name).read_bytes()).digest()==hashlib.sha256((a.replay/name).read_bytes()).digest(),name
 checks[name]='byte-identical'
refs=sorted((a.reference/'runs').glob('*.json'));actual=sorted((a.replay/'runs').glob('*.json'));assert len(refs)==len(actual)==200
maxdiff=0.;comparisons=0
for path in refs:
 other=a.replay/'runs'/path.name;r=json.loads(path.read_text());s=json.loads(other.read_text())
 for field in ['design','seed','model','code_sha256','input_sha256']:assert r[field]==s[field],(path.name,field)
 for suffix in ['.csv','.validation.csv']:
  x=pd.read_csv(path.with_suffix(suffix),float_precision='round_trip');y=pd.read_csv(other.with_suffix(suffix),float_precision='round_trip');assert list(x.columns)==list(y.columns) and x.shape==y.shape
  diff=float(np.max(np.abs(x.to_numpy()-y.to_numpy())));maxdiff=max(maxdiff,diff)
  for col in x:
   tolerance=1e-6 if r['model']=='rf' and col=='calibrated' else 1e-12
   assert np.allclose(x[col],y[col],rtol=0,atol=tolerance),(path.name,suffix,col,diff)
  comparisons+=x.size
 for field in ['calibrated','uncalibrated']:
  for key in r[field]:
   if r[field][key] is None:assert s[field][key] is None
   else:
    tolerance=1e-7 if r['model']=='rf' and field=='calibrated' and key in ['Brier','log_loss','ECE'] else 1e-12
    assert abs(r[field][key]-s[field][key])<=tolerance,(path.name,field,key)
 assert np.allclose([r['calibration_slope'],r['calibration_intercept']],[s['calibration_slope'],s['calibration_intercept']],rtol=0,atol=1e-6 if r['model']=='rf' else 1e-10)
 if r['model']=='mpnn':assert r['training']==s['training'],path.name+' training history'
checks.update(completed_fits=200,prediction_values_compared=comparisons,max_absolute_prediction_difference=maxdiff,prediction_tolerance='1e-12 except RF calibrated probabilities1e-6',metric_tolerance='1e-12 except RF calibrated Brier/log_loss/ECE1e-7',all_metrics_match_within_declared_tolerance=True,all_graph_training_histories_match=True)
a.output.write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
