"""Independent weighted metrics and paired molecular-group bootstrap."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

NAMES=['AUROC','AUPRC','balanced_accuracy','sensitivity','specificity','MCC','Brier','log_loss','ECE']

def weighted_metrics(y,p,w):
    y=np.asarray(y,dtype=float);p=np.clip(np.asarray(p,dtype=float),1e-7,1-1e-7);w=np.atleast_2d(w).astype(float)
    n=w.sum(axis=1);pos=w@y;neg=n-pos;pred=p>=.5
    tp=w@(y*pred);tn=w@((1-y)*(~pred));fp=neg-tn;fn=pos-tp
    with np.errstate(divide='ignore',invalid='ignore'):
        sens=tp/pos;spec=tn/neg;den=np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn));mcc=np.divide(tp*tn-fp*fn,den,out=np.zeros_like(den),where=den!=0)
        # Group all probability ties before rank calculations.
        order=np.argsort(p,kind='stable');ps=p[order];starts=np.r_[0,np.flatnonzero(np.diff(ps))+1]
        wp=np.add.reduceat(w[:,order]*y[order],starts,axis=1);wn=np.add.reduceat(w[:,order]*(1-y[order]),starts,axis=1)
        auc=(wp*(np.cumsum(wn,axis=1)-wn/2)).sum(axis=1)/(pos*neg)
        pp=wp[:,::-1];nn=wn[:,::-1];cp=np.cumsum(pp,axis=1);ct=np.cumsum(pp+nn,axis=1)
        precision=np.divide(cp,ct,out=np.zeros_like(cp),where=ct!=0);ap=(pp*precision).sum(axis=1)/pos
        brier=(w@((p-y)**2))/n;ll=(w@(-y*np.log(p)-(1-y)*np.log1p(-p)))/n
        bins=np.minimum((p*10).astype(int),9);ece=np.zeros(len(w))
        for b in range(10):ece+=np.abs(w@((y-p)*(bins==b)))/n
    return np.column_stack([auc,ap,(sens+spec)/2,sens,spec,mcc,brier,ll,ece])

def weights(groups,seed,reps=1000):
    _,inverse=np.unique(groups,return_inverse=True);ng=int(inverse.max())+1
    rng=np.random.default_rng(seed);counts=rng.multinomial(ng,np.full(ng,1/ng),size=reps)
    return counts[:,inverse]

def stable_seed(design,seed):return 20260927+int(hashlib.sha256(f'{design}:{seed}'.encode()).hexdigest()[:8],16)

def selftest():
    from sklearn.metrics import roc_auc_score,average_precision_score,balanced_accuracy_score,recall_score,matthews_corrcoef,brier_score_loss,log_loss
    rng=np.random.default_rng(456);checks=0
    for _ in range(20):
        y=rng.integers(0,2,35);p=rng.choice([.1,.3,.5,.8,.9],35);w=rng.integers(0,5,35);ids=np.repeat(np.arange(len(y)),w);yy=y[ids];pp=p[ids]
        expected=[roc_auc_score(yy,pp),average_precision_score(yy,pp),balanced_accuracy_score(yy,pp>=.5),recall_score(yy,pp>=.5),recall_score(yy,pp>=.5,pos_label=0),matthews_corrcoef(yy,pp>=.5),brier_score_loss(yy,pp),log_loss(yy,pp)]
        actual=weighted_metrics(y,p,w)[0];assert np.allclose(actual[:8],expected,atol=1e-12),(actual,expected)
        bins=np.minimum((pp*10).astype(int),9);expected_ece=sum(abs(np.sum(yy[bins==b]-pp[bins==b])) for b in range(10))/len(yy)
        assert abs(actual[8]-expected_ece)<1e-12;checks+=9
    return {'weighted_metric_checks':checks,'ties_and_zero_weights':True,'maximum_tolerance':1e-12}

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--results',type=Path,required=True);pa.add_argument('--self-test',action='store_true');args=pa.parse_args();root=args.results;out=root/'statistics';out.mkdir(exist_ok=True)
    validation=selftest();(out/'metric_selftest.json').write_text(json.dumps(validation,indent=2))
    if args.self_test:print(json.dumps(validation));return
    receipts=sorted((root/'runs').glob('*.json'));assert len(receipts)==200,f'Expected 200 completed fits, found {len(receipts)}'
    rows=[];boots={};points={};predictions={};verified=0;binrows=[];precision_changes=[]
    from models import metrics as reference_metrics
    for path in receipts:
        r=json.loads(path.read_text());original=pd.read_csv(path.with_suffix('.csv'),float_precision='round_trip');d=original.sort_values('rid');key=(r['design'],r['seed'],r['model']);predictions[key]=d
        w=weights(d.base_group.to_numpy(),stable_seed(r['design'],r['seed']))
        for form in ['uncalibrated','calibrated']:
            y=d.label.to_numpy();p=d[form].to_numpy();point=weighted_metrics(y,p,np.ones(len(y)))[0]
            reference=reference_metrics(y,p.astype(np.float64))
            legacy=reference_metrics(original.label.to_numpy(),original[form].to_numpy().astype(np.float32)) if key[2]=='mpnn' and form=='uncalibrated' else reference
            for j,name in enumerate(NAMES):
                assert np.isclose(point[j],reference[name],rtol=0,atol=1e-12),(*key,form,name,'independent formula')
                assert np.isclose(legacy[name],r[form][name],rtol=0,atol=1e-12),(*key,form,name,'serialization')
                verified+=1
                if abs(point[j]-r[form][name])>1e-12:precision_changes.append(dict(design=key[0],seed=key[1],model=key[2],form=form,metric=name,original_receipt=r[form][name],reported_float64=point[j],difference=point[j]-r[form][name]))
            b=weighted_metrics(y,p,w);bounds=np.nanquantile(b,[.025,.975],axis=0)
            for j,name in enumerate(NAMES):rows.append(dict(design=key[0],seed=key[1],model=key[2],form=form,metric=name,value=point[j],lower=bounds[0,j],upper=bounds[1,j],valid_bootstraps=int(np.isfinite(b[:,j]).sum()),test_n=len(y),test_groups=d.base_group.nunique()))
            if form=='calibrated':boots[key]=b;points[key]=point
            ids=np.minimum((np.clip(p,0,1)*10).astype(int),9)
            for binid in range(10):
                selected=ids==binid;n=int(selected.sum());binrows.append(dict(design=key[0],seed=key[1],model=key[2],form=form,bin=binid,n=n,mean_probability=float(p[selected].mean()) if n else None,observed_fraction=float(y[selected].mean()) if n else None))
    pd.DataFrame(precision_changes).to_csv(out/'metric_precision_changes.csv',index=False)
    frame=pd.DataFrame(rows);frame.to_csv(out/'metrics_intervals.csv',index=False);pd.DataFrame(binrows).to_csv(out/'reliability_bins.csv',index=False)
    frame.groupby(['design','model','form','metric']).value.agg(['mean','std','min','max','count']).reset_index().to_csv(out/'seed_summary.csv',index=False)
    contrasts=[]
    for design in sorted({k[0] for k in points}):
        for model in ['rule','descriptor_lr','rf','mpnn']:
            delta=[];bd=[]
            for seed in range(1,6):
                key=(design,seed,model);ref=(design,seed,'morgan_lr');assert np.array_equal(predictions[key].rid,predictions[ref].rid)
                delta.append(points[key]-points[ref]);bd.append(boots[key]-boots[ref])
            delta=np.array(delta);average=np.mean(delta,axis=0);bound=np.nanquantile(np.mean(bd,axis=0),[.025,.975],axis=0)
            for j,name in enumerate(NAMES):contrasts.append(dict(design=design,model=model,reference='morgan_lr',metric=name,mean_difference=average[j],conditional_lower=bound[0,j],conditional_upper=bound[1,j],seed_sd=float(delta[:,j].std(ddof=1)),seed_min=delta[:,j].min(),seed_max=delta[:,j].max(),inference='within-seed group resampling averaged across five fixed splits; overlap not independent'))
    pd.DataFrame(contrasts).to_csv(out/'paired_contrasts.csv',index=False)
    # Fixed official test inference uses seed-averaged probabilities on one test.
    fixed=[]
    for design in ['official_reference','official_clean']:
        mean_predictions={};mean_boot={};mean_point={}
        for model in ['rule','descriptor_lr','morgan_lr','rf','mpnn']:
            ds=[predictions[(design,s,model)] for s in range(1,6)];assert all(np.array_equal(ds[0].rid,d.rid) for d in ds)
            d=ds[0];p=np.mean([x.calibrated.to_numpy() for x in ds],axis=0);y=d.label.to_numpy();w=weights(d.base_group.to_numpy(),stable_seed(design,0));b=weighted_metrics(y,p,w);point=weighted_metrics(y,p,np.ones(len(y)))[0]
            mean_point[model]=point;mean_boot[model]=b;mean_predictions[model]=p
            bounds=np.nanquantile(b,[.025,.975],axis=0)
            for j,name in enumerate(NAMES):fixed.append(dict(design=design,model=model,metric=name,value=point[j],lower=bounds[0,j],upper=bounds[1,j],type='seed-averaged predictions; one fixed test'))
        for model in ['rf','mpnn']:
            b=mean_boot[model]-mean_boot['morgan_lr'];bounds=np.nanquantile(b,[.025,.975],axis=0)
            for j,name in enumerate(NAMES):fixed.append(dict(design=design,model=model+' minus morgan_lr',metric=name,value=mean_point[model][j]-mean_point['morgan_lr'][j],lower=bounds[0,j],upper=bounds[1,j],type='paired fixed-test contrast of seed-averaged predictions'))
    pd.DataFrame(fixed).to_csv(out/'official_fixed_test.csv',index=False)
    decisions=[];ct=pd.DataFrame(contrasts)
    for model in ['rf','mpnn']:
        s=ct[(ct.design=='clean_strict')&(ct.model==model)].set_index('metric');auc=s.loc['AUROC'];brier=s.loc['Brier'];decisions.append(dict(model=model,comparison='Morgan LR',design='clean_strict',mean_AUROC_gain=auc.mean_difference,conditional_AUROC_lower=auc.conditional_lower,conditional_AUROC_upper=auc.conditional_upper,mean_Brier_change=brier.mean_difference,material_gain=bool(auc.mean_difference>=.02 and auc.conditional_lower>0 and brier.mean_difference<=.01),caveat='conditional fixed-split intervals; two primary contrasts without familywise significance claim'))
    (out/'primary_decisions.json').write_text(json.dumps(decisions,indent=2));(out/'verification.json').write_text(json.dumps(dict(completed_fits=len(receipts),independent_metric_comparisons=verified,bootstrap_replicates=1000,seed_resampling=False,reporting_precision='float64 from exact saved CSV; legacy float32 graph receipts separately verified',precision_adjustments=len(precision_changes),selftest=validation),indent=2));print('Statistics and independent metric verification complete.',flush=True)
if __name__=='__main__':main()
