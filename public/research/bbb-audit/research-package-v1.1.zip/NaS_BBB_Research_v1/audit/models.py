"""Training and metrics for the frozen BBBP study; never tune on test labels."""
import argparse, copy, hashlib, json, random, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logit
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors, rdFingerprintGenerator
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, matthews_corrcoef, log_loss
import torch
from torch import nn

def metrics(y,p):
    y=np.asarray(y);p=np.clip(p,1e-7,1-1e-7);pred=p>=.5
    tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
    sens=float(tp/(tp+fn)) if tp+fn else None;spec=float(tn/(tn+fp)) if tn+fp else None
    bins=np.minimum((p*10).astype(int),9);ece=sum(np.mean(bins==b)*abs(np.mean(y[bins==b])-np.mean(p[bins==b])) for b in range(10) if np.any(bins==b))
    return dict(n=len(y),positive=int(y.sum()),AUROC=float(roc_auc_score(y,p)) if len(set(y))==2 else None,AUPRC=float(average_precision_score(y,p)) if y.sum() else None,balanced_accuracy=(sens+spec)/2 if sens is not None and spec is not None else None,sensitivity=sens,specificity=spec,MCC=float(matthews_corrcoef(y,pred)),Brier=float(np.mean((p-y)**2)),log_loss=float(log_loss(y,p,labels=[0,1])),ECE=float(ece))

def calibrate(y,p):
    z=logit(np.clip(p,1e-7,1-1e-7))
    def objective(v):
        t=v[0]*z+v[1];return np.mean(np.logaddexp(0,t)-y*t)
    result=minimize(objective,[1.,0.],method='L-BFGS-B',bounds=[(0,100),(-100,100)],options={'ftol':1e-12,'maxiter':2000})
    if not result.success:raise RuntimeError('Calibration failed: '+result.message)
    return result.x

def graph(m):
    # Fixed atom vocabulary plus unknown bucket; features have no fitted statistics.
    atoms=[1,5,6,7,8,9,14,15,16,17,35,53]
    xs=[]
    for a in m.GetAtoms():
        z=a.GetAtomicNum();xs.append([float(z==v) for v in atoms]+[float(z not in atoms),a.GetDegree()/6,a.GetFormalCharge()/3,a.GetTotalNumHs()/4,float(a.GetIsAromatic()),float(a.IsInRing()),a.GetMass()/200]+[float(int(a.GetChiralTag())==v) for v in range(4)])
    edges=[];bs=[]
    for b in m.GetBonds():
        f=[float(b.GetBondTypeAsDouble()==v) for v in [1,1.5,2,3]]+[float(b.GetIsConjugated()),float(b.IsInRing())]+[float(int(b.GetStereo())==v) for v in range(6)]
        for i,j in [(b.GetBeginAtomIdx(),b.GetEndAtomIdx()),(b.GetEndAtomIdx(),b.GetBeginAtomIdx())]:edges.append([i,j]);bs.append(f)
    return (torch.tensor(xs,dtype=torch.float32),torch.tensor(edges,dtype=torch.long).reshape(-1,2),torch.tensor(bs,dtype=torch.float32).reshape(-1,12))

def batch(graphs,ids):
    xs=[];es=[];bs=[];gs=[];offset=0
    for k,i in enumerate(ids):
        x,e,b=graphs[int(i)];xs.append(x);es.append(e+offset);bs.append(b);gs.append(torch.full((len(x),),k,dtype=torch.long));offset+=len(x)
    return torch.cat(xs),torch.cat(es),torch.cat(bs),torch.cat(gs),len(ids)

class MPNN(nn.Module):
    def __init__(self):
        super().__init__();self.input=nn.Linear(23,64);self.messages=nn.ModuleList([nn.Linear(76,64) for _ in range(3)]);self.updates=nn.ModuleList([nn.GRUCell(64,64) for _ in range(3)]);self.readout=nn.Sequential(nn.Linear(128,64),nn.ReLU(),nn.Linear(64,1))
    def forward(self,batchdata):
        x,e,b,g,n=batchdata;h=torch.relu(self.input(x));src,dst=e[:,0],e[:,1]
        deg=torch.zeros((len(x),1));deg.index_add_(0,dst,torch.ones((len(dst),1)));deg=deg.clamp(min=1)
        for msg,upd in zip(self.messages,self.updates):
            a=torch.zeros_like(h);a.index_add_(0,dst,torch.relu(msg(torch.cat([h[src],b],dim=1))));h=upd(a/deg,h)
        sums=torch.zeros((n,64));sums.index_add_(0,g,h);count=torch.bincount(g,minlength=n).float().unsqueeze(1)
        return self.readout(torch.cat([sums/count,sums],dim=1)).squeeze(1)

def predict_graph(model,graphs,ids):
    model.eval();parts=[]
    with torch.no_grad():
        for start in range(0,len(ids),64):parts.append(torch.sigmoid(model(batch(graphs,ids[start:start+64]))).numpy())
    return np.concatenate(parts)

def fit_graph(graphs,y,tr,va,seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.use_deterministic_algorithms(True);torch.set_num_threads(2)
    model=MPNN();opt=torch.optim.Adam(model.parameters(),lr=.001,weight_decay=.0001);lossfn=nn.BCEWithLogitsLoss();rng=np.random.default_rng(seed)
    best=float('inf');state=None;best_epoch=0;history=[]
    for epoch in range(1,61):
        model.train();order=rng.permutation(tr);total=0
        for start in range(0,len(order),64):
            ids=order[start:start+64];opt.zero_grad();loss=lossfn(model(batch(graphs,ids)),torch.tensor(y[ids],dtype=torch.float32));loss.backward();opt.step();total+=float(loss.detach())*len(ids)
        vl=float(log_loss(y[va],predict_graph(model,graphs,va),labels=[0,1]));history.append(dict(epoch=epoch,train_loss=total/len(tr),validation_loss=vl))
        if vl<best:best=vl;state=copy.deepcopy(model.state_dict());best_epoch=epoch
        if epoch-best_epoch>=10:break
    model.load_state_dict(state)
    return model,dict(best_epoch=best_epoch,epochs=len(history),parameters=sum(p.numel() for p in model.parameters()),history=history,pretraining='none; random initialization')

def main():
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--models',nargs='+',default=['rule','descriptor_lr','morgan_lr','rf','mpnn']);p.add_argument('--designs',nargs='+');a=p.parse_args()
    root=a.results;dest=root/'runs';dest.mkdir(exist_ok=True);audit=pd.read_csv(root/'cohort_audit.csv',keep_default_na=False);splits=pd.read_csv(root/'splits.csv');y=audit.label.to_numpy()
    preparation=json.loads((root/'preparation.json').read_text())
    assert preparation['all_splits_both_classes'] and preparation['split_count']==40
    assert audit[audit.name.str.casefold().eq('mesocarb')].status.eq('standardization_instability').all()
    meso=set(audit[audit.name.str.casefold().eq('mesocarb')].rid)
    assert not(set(splits[~splits.design.str.endswith('reference')].rid)&meso)
    input_hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['cohort_audit.csv','splits.csv','preparation.json']}
    RDLogger.DisableLog('rdApp.*');gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False)
    funcs=[Descriptors.MolWt,Descriptors.MolLogP,Descriptors.TPSA,Descriptors.NumHDonors,Descriptors.NumHAcceptors,Descriptors.NumRotatableBonds,Descriptors.RingCount,Descriptors.FractionCSP3]
    features={}
    for rep in ['original','clean']:
        smis=audit.canonical if rep=='original' else [r.neutral or r.canonical for r in audit.itertuples()]
        mols=[Chem.MolFromSmiles(s) for s in smis];desc=np.array([[f(m) for f in funcs] for m in mols]);assert np.isfinite(desc).all()
        features[rep]=(desc,np.array([gen.GetFingerprintAsNumPy(m) for m in mols]),[graph(m) for m in mols])
    source_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    for (design,seed),sp in splits.groupby(['design','seed'],sort=False):
        if a.designs and design not in a.designs:continue
        tr,va,te=[sp[sp.partition.eq(k)].rid.to_numpy() for k in ['train','valid','test']]
        if any(len(set(y[ids]))<2 for ids in [tr,va,te]):raise RuntimeError(f'Infeasible registered split: {design} {seed}')
        desc,fp,graphs=features['original' if design.endswith('reference') else 'clean']
        for name in a.models:
            run=dest/f'{design}__{seed}__{name}';receipt=run.with_suffix('.json')
            if receipt.exists():
                old=json.loads(receipt.read_text());assert old['code_sha256']==source_hash and old['input_sha256']==input_hashes,'Do not silently resume under changed code or inputs';continue
            start=time.monotonic();extra={}
            if name=='rule':pv=expit((90-desc[va,2])/20);pt=expit((90-desc[te,2])/20)
            elif name=='mpnn':
                model,extra=fit_graph(graphs,y,tr,va,int(seed));pv=predict_graph(model,graphs,va);pt=predict_graph(model,graphs,te);torch.save(model.state_dict(),run.with_suffix('.pt'))
            else:
                X=desc if name=='descriptor_lr' else fp
                if name=='rf':model=RandomForestClassifier(n_estimators=300,min_samples_leaf=2,max_features='sqrt',random_state=int(seed),n_jobs=2)
                else:
                    model=LogisticRegression(C=1,max_iter=2000,solver='liblinear',random_state=int(seed))
                    if name=='descriptor_lr':model=make_pipeline(StandardScaler(),model)
                model.fit(X[tr],y[tr]);pv=model.predict_proba(X[va])[:,1];pt=model.predict_proba(X[te])[:,1]
            ab=calibrate(y[va],pv);pc=expit(ab[0]*logit(np.clip(pt,1e-7,1-1e-7))+ab[1])
            pred=pd.DataFrame({'rid':te,'label':y[te],'uncalibrated':pt,'calibrated':pc,'base_group':audit.iloc[te].base_group.to_numpy()});pred.to_csv(run.with_suffix('.csv'),index=False)
            pd.DataFrame({'rid':va,'label':y[va],'uncalibrated':pv}).to_csv(run.with_suffix('.validation.csv'),index=False)
            data=dict(design=design,seed=int(seed),model=name,code_sha256=source_hash,input_sha256=input_hashes,seconds=time.monotonic()-start,calibration_slope=float(ab[0]),calibration_intercept=float(ab[1]),uncalibrated=metrics(y[te],pt),calibrated=metrics(y[te],pc),training=extra)
            receipt.write_text(json.dumps(data,indent=2,allow_nan=False));print(f'{design} seed={seed} {name} completed in {data["seconds"]:.1f}s',flush=True)
if __name__=='__main__':main()
