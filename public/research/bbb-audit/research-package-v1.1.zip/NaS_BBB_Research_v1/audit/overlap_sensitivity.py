"""Exploratory shared-group bootstrap preserving repeated-test-group dependence."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from inference import weighted_metrics,NAMES,stable_seed
p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);a=p.parse_args();root=a.results;out=root/'statistics';out.mkdir(exist_ok=True);rows=[]
designs=sorted(pd.read_csv(root/'splits.csv').design.unique())
for design in designs:
 ds={}
 for seed in range(1,6):
  for model in ['morgan_lr','rf','mpnn']:
   ds[seed,model]=pd.read_csv(root/'runs'/f'{design}__{seed}__{model}.csv',float_precision='round_trip').sort_values('rid')
 groups=sorted(set().union(*(set(d.base_group) for d in ds.values())));lookup={g:i for i,g in enumerate(groups)};n=len(groups)
 rng=np.random.default_rng(stable_seed(design,991));counts=rng.multinomial(n,np.full(n,1/n),size=1000);boot={};point={}
 for key,d in ds.items():
  w=counts[:,[lookup[g] for g in d.base_group]];boot[key]=weighted_metrics(d.label.to_numpy(),d.calibrated.to_numpy(),w);point[key]=weighted_metrics(d.label.to_numpy(),d.calibrated.to_numpy(),np.ones(len(d)))[0]
 for model in ['rf','mpnn']:
  b=np.mean([boot[s,model]-boot[s,'morgan_lr'] for s in range(1,6)],axis=0);v=np.mean([point[s,model]-point[s,'morgan_lr'] for s in range(1,6)],axis=0);limits=np.nanquantile(b,[.025,.975],axis=0)
  for j,name in enumerate(NAMES):rows.append(dict(design=design,model=model,reference='morgan_lr',metric=name,mean_difference=v[j],lower=limits[0,j],upper=limits[1,j],valid_replicates=int(np.isfinite(b[:,j]).sum()),union_test_groups=n,interpretation='exploratory shared-group bootstrap across all five fixed splits; not seed resampling'))
pd.DataFrame(rows).to_csv(out/'overlap_aware_sensitivity.csv',index=False)
(out/'overlap_sensitivity_method.json').write_text(json.dumps(dict(status='exploratory post-training methodological sensitivity; no model selection',replicates=1000,shared_weights='one multinomial group count applied to every appearance across seeds',registered_primary_replaced=False,limits='conditional on observed union of test groups and fixed trained models; no assay uncertainty'),indent=2));print('Shared-group overlap sensitivity complete.',flush=True)
