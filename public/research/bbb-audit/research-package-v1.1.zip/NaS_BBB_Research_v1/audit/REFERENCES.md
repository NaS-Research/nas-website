# Study references

[1. Martins et al. (2012). A Bayesian approach to in silico blood-brain barrier penetration modeling. DOI:10.1021/ci300124c](https://doi.org/10.1021/ci300124c)

[2. Sakiyama, Fukuda and Okuno (2021). Prediction of BBBP based on molecular descriptors of free-form and in-blood-form datasets. DOI:10.3390/molecules26247428](https://doi.org/10.3390/molecules26247428)

[3. Wu et al. (2018). MoleculeNet: a benchmark for molecular machine learning. DOI:10.1039/C7SC02664A](https://doi.org/10.1039/C7SC02664A)

[4. Ferri and Garcia-Gomez (2026). Overrepresentation bias leads to performance overestimation in BBB permeability prediction models. DOI:10.1021/acs.jcim.5c02891](https://doi.org/10.1021/acs.jcim.5c02891)

[5. Schuh, Daniluk and Sieber (2026). Auditing widely used biomolecular benchmarks reveals systematic data inconsistencies. DOI:10.1039/D6SC01799A](https://doi.org/10.1039/D6SC01799A)

[6. Kelder et al. (1999). Polar molecular surface as a dominating determinant for oral absorption and brain penetration. PMID:10554091](https://pubmed.ncbi.nlm.nih.gov/10554091/)

[7. Gilmer et al. (2017). Neural message passing for quantum chemistry. PMLR70:1263-1272](https://proceedings.mlr.press/v70/gilmer17a.html)

[8. Schinkel et al. (1996). P-glycoprotein in the BBB of mice influences brain penetration and pharmacological activity. DOI:10.1172/JCI118699](https://pmc.ncbi.nlm.nih.gov/articles/PMC507337/)

[9. Alexander et al. (1994). Amino acids, parkinsonism and blood-to-brain levodopa transport. PMID:8058155](https://pubmed.ncbi.nlm.nih.gov/8058155/)

[10. Mannila et al. (2007). Plasma and CSF concentrations of indomethacin in children. PMID:17192507](https://pubmed.ncbi.nlm.nih.gov/17192507/)

[11. Sung et al. (1978). Miconazole therapy for fungal meningitis. PMID:580889](https://pubmed.ncbi.nlm.nih.gov/580889/)

[12. Methylprednisolone infusion during acute exacerbation of MS: plasma and CSF concentrations (1995). PMID:7628493](https://pubmed.ncbi.nlm.nih.gov/7628493/)

[13. Kubo et al. (2011). Brain H1 receptor occupancy of loratadine measured by PET. PMID:21433074](https://pubmed.ncbi.nlm.nih.gov/21433074/)

[14. Balis et al. (1986). Pharmacokinetics of trimetrexate in monkeys. PMID:2933145](https://pubmed.ncbi.nlm.nih.gov/2933145/)

[15. Neil-Dwyer et al. (1981). Beta-adrenoceptor blockers and the blood-brain barrier. PMID:6115665](https://pubmed.ncbi.nlm.nih.gov/6115665/)

[16. TDC issue #383. Unverified allegation; saved issue and comment state inspected](https://github.com/mims-harvard/TDC/issues/383)

[17. Iyer et al. (2002). Predicting BBB partitioning using membrane-interaction QSAR. PMID:12458666](https://pubmed.ncbi.nlm.nih.gov/12458666/)

[18. Publisher supplement metadata, Martins study](https://api.figshare.com/v2/articles/2511184)

[19. Creative Commons Attribution-NonCommercial 4.0 legal code](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en)

[20. Interaction of acupuncture and electroacupuncture on aspirin pharmacokinetics and brain blood flow in rats (2013). Parent/metabolite microdialysis results](https://pmc.ncbi.nlm.nih.gov/articles/PMC3858995/)
