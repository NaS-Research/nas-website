# How Reliable Is BBBP?

A Reproducibility and Dataset-Integrity Audit of a Widely Used Blood-Brain Barrier Benchmark

We audited the provenance, molecular integrity and evaluation sensitivity of TDC BBB_Martins through 200 prespecified model fits. The 2,030-row reference contains 10 canonical label-conflict groups; conservative curation retained 1,935 representatives without correcting labels. Morgan logistic regression averaged AUROC 0.913 on grouped random tests and 0.732 under strict chemical separation. The graph model improved on Morgan LR there, but the simple polar-surface rule scored higher (0.812 versus 0.782). The random-forest contrast became inconclusive under overlap-aware resampling. These findings support release-specific auditing and baseline comparisons, not a universally superior model, experimentally established label repairs or prospective biological validity.


## Question and contribution

Can this benchmark support reliable comparative claims once source versions, contradictory representations, chemical separation and probability calibration are made explicit? We examine this question as a replication and extension of prior BBBP curation and benchmark-audit studies [1-5]. Discovering duplicates or similarity-related performance changes is not claimed as novel.


## A reconstructable version chain

| Representation | Rows | Verified relationship |
| --- | --- | --- |
| Martins supplement | 2,053 | Deposited source records |
| MoleculeNet CSV | 2,050 | Three omitted source records have retained structure/label matches |
| TDC download | 2,039 | Matches parsable MoleculeNet structure/label multiset |
| TDC loader / official union | 2,030 | Nine identical full records removed |
| Unique canonical structures | 1,975 | Not the number of loader rows |


The original paper abstract describes 1,970 curated molecules. The deposited supplement and available processing history do not fully reconcile that separate figure. The official development/test union exactly matches the loader records: 1,624 development and 406 test rows. The original fixed test has 328 positive and 78 negative labels.

The current contribution is an independently replayable account of these specified inputs, together with prespecified model, calibration and chemical-distance sensitivity analyses. It does not certify each compound’s biological ground truth.


## Molecular integrity

| Disposition | Records | Interpretation |
| --- | --- | --- |
| Retained representatives | 1,935 | Eligible, nonconflicting neutral representations |
| Duplicate members | 49 | Collapsed; membership preserved privately |
| Conflicting representations | 25 | Excluded without label correction |
| Ambiguous organic mixtures | 20 | More than one carbon-containing component |
| Standardization instability | 1 | Conservative quarantine |
| Reference total | 2,030 | All original labels retained |


The reference contains 52 repeated canonical-structure groups, 55 excess rows and 10 conflicting canonical-label groups involving 20 rows. There are 105 multifragment records. These counts describe distributed representations, not an experimentally adjudicated number of erroneous molecules.

The cleaned cohort applies RDKit Cleanup, selects a fragment only when exactly one connected component contains carbon, neutralizes with Uncharger and preserves specified stereochemistry. Contradictory neutral-parent or tautomer-parent groups are excluded. Exact neutral duplicates retain a deterministic representative. Every intermediate representation and exclusion is recorded.

A known unstable standardization was quarantined after alternative processing returned a substantially changed ring representation. Successful parsing was not accepted as proof of chemical correctness. Original-reference analysis retains that row. Neutralization is not a physiological pH prediction; tautomer and stereo-free matches do not establish biological interchangeability.


## Evaluation designs

| Design | Population | Test construction |
| --- | --- | --- |
| Row random | Original 2,030 | TDC random, seeds 1-5 |
| Repeated scaffold | Original 2,030 | TDC Murcko scaffold, seeds 1-5 |
| Official fixed | Original 2,030 | Unchanged 406-row official test |
| Grouped random | Clean 1,935 | Whole base groups held out |
| Grouped scaffold | Clean 1,935 | Base and Murcko groups joined |
| Similarity <0.6 | Clean 1,935 | Similarity connected components |
| Distance <0.4 | Clean 1,935 | Stricter connected components |
| Official integrity | Modified official | Eligible test; related development groups purged |


Each design uses five fixed seeds. Base groups join stereo-free tautomer matches and Morgan radius-2, 2,048-bit similarities at or above 0.9. Scaffold and lower-threshold similarity edges add further grouping. Empty Murcko scaffolds form an explicit common group. The connected-component definition is transitive.

GroupShuffleSplit assigns 20% of groups to test, followed by 12.5% of remaining groups to validation. These are group fractions, not guaranteed record fractions. All 40 registered split/seed combinations contain both classes and pass separation checks. No seed was retried for a favorable result.

Official runs vary development allocation and training seed while keeping one test set. They are not five independent official tests. Chemical-distance tests are distribution-shift stress tests, not prospective validation.


## Models and calibration

| Model | Inputs | Fixed specification |
| --- | --- | --- |
| PSA rule | Topological polar surface | sigmoid((90 - TPSA) / 20) |
| Descriptor LR | Eight RDKit descriptors | Train-only scaling; C=1 |
| Morgan LR | Radius 2; 2,048 bits | C=1; no chirality bits |
| Random forest | Morgan fingerprints | 300 trees; minimum leaf 2 |
| Graph MPNN | Atom and bond features | 3 layers; 64 dimensions; 99,521 parameters |


Descriptors are molecular weight, logP, TPSA, hydrogen-bond donors and acceptors, rotatable bonds, ring count and fraction sp3. Logistic regression uses liblinear and a 2,000-iteration limit. Forest feature subsampling is square root, without class weighting. The polar-surface coefficients are explicit heuristic conventions, motivated by prior physicochemical evidence [6]; they are not a validated permeability equation.

The bond-aware graph network uses 23 atom features, 12 bond features, mean incoming messages, GRU updates and mean-plus-sum graph readout [7]. Adam uses learning rate 0.001, weight decay 0.0001 and batches of 64. Training stops after at most 60 epochs, with patience 10 on validation log loss. The best validation checkpoint is restored. No pretrained model, pretraining data or paid compute is used.

Each model receives validation-only sigmoid calibration with nonnegative slope. The primary decision threshold is 0.5. Graph early stopping and calibration share validation data, which is disclosed. Test performance does not select scaling, hyperparameters, calibration or thresholds.


## Discrimination depends on the test

Figure 1. Calibrated AUROC means across five seeds. Whiskers are seed SD, not confidence intervals. Official fixed uses the same 406 test rows in every run. Other designs can change chemistry, prevalence and test size.

Morgan LR averaged 0.897 on row-random reference tests, 0.830 on the official fixed test and 0.732 under strict chemical separation. Grouped random performance was 0.913; cleaning did not uniformly reduce scores. These comparisons do not isolate leakage from composition changes.


## Probability error also changes

Figure 2. Calibrated Brier score means and seed SD; lower is better. These estimates combine model error, test composition and the transfer of validation-fitted calibration to each test.

Under strict separation, Morgan LR had mean Brier 0.182, versus 0.167 for random forest and 0.155 for the graph model. The PSA rule remained competitive at 0.143. A gain against one fingerprint baseline is not general superiority over simple baselines.


## Strict-distance results

| Model | AUROC | AP | Balanced acc. | Sensitivity | Specificity |
| --- | --- | --- | --- | --- | --- |
| PSA rule | 0.812 | 0.920 | 0.676 | 0.928 | 0.424 |
| Descriptor LR | 0.812 | 0.911 | 0.671 | 0.930 | 0.413 |
| Morgan LR | 0.732 | 0.875 | 0.568 | 0.911 | 0.226 |
| Random forest | 0.767 | 0.894 | 0.672 | 0.891 | 0.453 |
| Graph MPNN | 0.782 | 0.903 | 0.663 | 0.915 | 0.412 |
| Model | MCC | Brier | Log loss | ECE |
| PSA rule | 0.426 | 0.143 | 0.445 | 0.106 |
| Descriptor LR | 0.434 | 0.144 | 0.451 | 0.113 |
| Morgan LR | 0.240 | 0.182 | 0.541 | 0.139 |
| Random forest | 0.392 | 0.167 | 0.505 | 0.131 |
| Graph MPNN | 0.412 | 0.155 | 0.482 | 0.113 |


All entries are five-seed means; AP is average precision, the AUPRC convention used here. MCC is Matthews correlation coefficient. ECE uses 10 equal-width probability bins. Per-seed values, class counts and molecular-group bootstrap intervals are supplied in the aggregate tables.

Strict test sizes range from 180 to 877 records; the smallest negative test count is 36. The polar-surface rule and descriptor LR have higher mean AUROC than either complex model in this design. Their lower capacity does not imply universal superiority either: model rankings change across evaluation designs.


## What the paired comparisons support

| Contrast vs Morgan LR | Mean AUROC gain | Registered 95% interval | Shared-group 95% interval |
| --- | --- | --- | --- |
| Random forest | 0.035 | 0.001 to 0.064 | -0.001 to 0.071 |
| Graph MPNN | 0.051 | 0.021 to 0.081 | 0.016 to 0.086 |


The registered material-gain rule requires an AUROC increase of at least 0.02, a positive lower conditional 95% bound and no mean Brier deterioration greater than 0.01. Both comparisons satisfy this rule under the registered within-seed resampling calculation. The rule is a research convention, not a clinical threshold or familywise significance test.

The exploratory shared-group sensitivity applies the same resampling weight to every appearance of a molecular group across the five tests. The forest interval then includes zero; its discrimination advantage is not robust to this treatment of overlap. The graph interval remains positive. Both registered and supplementary intervals are reported, without selecting the favorable one.

The registered reference is Morgan LR. The simple PSA rule has a higher strict-distance mean AUROC than the graph model, so the graph result cannot be generalized into a claim that model complexity wins. No external leaderboard predictions were available for a paired comparison, and modified-cohort scores are not advertised as unchanged-leaderboard results.

These intervals condition on observed molecules, grouping conventions and fitted models. They do not quantify laboratory measurement uncertainty, missing assay context or performance in future patients.


## Chemical distance and composition

Figure 3. Nearest-training similarity in each model track’s molecular representation. Curves pool test appearances across seeds, not independent molecules. The strict and cluster designs enforce their thresholds across partitions.

The strict design produces 180-877 test records across seeds because large connected components move together. This is substantial variation, not a minor nuisance. Training size and validation prevalence also change. Consequently, score changes cannot be attributed solely to removal of near-neighbor leakage.

Scaffold novelty, acyclic status, nearest-training versus nearest-development similarity and training-defined descriptor quartiles are recorded separately. Fingerprint similarity is a representation-dependent domain diagnostic; fingerprint equality does not prove molecular identity.


## Calibration under shift

Figure 4. Validation-calibrated reliability curves, pooled by probability bin across five test appearances. The diagonal is ideal calibration. Sparse bins can fluctuate; bin counts and per-seed results accompany the report.

Validation-fitted calibration reduced held-out Brier score in 116 of 200 runs and reduced ECE in 120. Improvement is not guaranteed after a change in chemistry or prevalence. This is why uncalibrated and calibrated results are both retained.

Confidence is max(p, 1-p), summarized in prespecified intervals 0.5-0.6, 0.6-0.8 and 0.8-1. High model confidence is not an assay-level uncertainty estimate or evidence that an unresolved label is wrong.


## Cleaning versus test restriction

Figure 5. Five-seed means for the original full official test, original predictions restricted to retained test rows, and cleaned-model predictions on those same retained rows. The last change also alters training representation, population and development allocation.

For Morgan LR, AUROC changes from 0.830 on the full test to 0.845 on the common test, then 0.838 after cleaned-model fitting. The graph model changes from 0.851 to 0.868 to 0.898. These patterns show why a single before/after cleaned-set score is insufficient.

Curation uses distributed labels to identify contradictions before splitting. It is retrospective and label-informed. This differs from tuning a model against test performance, but still changes the eligible population and limits prospective interpretation.


## Label evidence and its limits

The private evidence register contains 33 representation-group entries across canonical, neutral and tautomer definitions. They are overlapping entries, not 33 independent compounds. Twenty-four entries are classified as context-dependent ambiguity and nine as unresolved conflicts. No source label was adjudicated as a verified correction.

Primary studies illustrate distinctions that the binary benchmark does not preserve: transporter genotype can affect brain exposure; parent drug and metabolite can differ; detectable CSF entry need not imply a high brain/plasma ratio; receptor occupancy is not the same endpoint as tissue concentration; inflammation and direct intrathecal dosing alter interpretation [8-15,20]. None of these general observations reconstructs the missing assay provenance of a particular benchmark row.

The separate allegation in TDC issue #383 does not identify the alleged two compounds or supply experimental evidence in the saved record [16]. It remains unverified. No compounds were selected from model errors to satisfy that allegation.

Earlier structure corrections reported by Sakiyama and colleagues cite Iyer et al. [2,17]. We located the cited primary abstract but did not obtain the original structure-level tables needed to verify those corrections independently. They were not silently applied.

The justified sensitivity is retention of all original reference labels versus explicit exclusion of contradictory representations in the integrity cohort. Exclusion is not a claim that either member of a conflicting pair is biologically correct.


## Applicability and recurring errors

| Strict-distance model | Observed test groups | Recurring error groups |
| --- | --- | --- |
| PSA rule | 1554 | 10 |
| Descriptor LR | 1554 | 7 |
| Morgan LR | 1554 | 8 |
| Random forest | 1554 | 11 |
| Graph MPNN | 1554 | 8 |


A recurring error group appears in at least three distinct seeds and has an error fraction of at least 0.8. Counts are descriptive; overlapping tests are not independent replications. Private record-level tables permit inspection without redistributing molecular records.

Subgroup tables cover similarity, scaffold novelty, acyclic structures, confidence and training-defined quartiles of molecular weight, logP and TPSA. Groups with fewer than 30 records or fewer than 10 members of either class are flagged. Single-class discrimination metrics remain undefined. The tables are exploratory, not a multiple-testing screen for mechanistic conclusions.

A model can perform well in a familiar chemistry region while failing on distant structures. These diagnostics establish limits of the evaluated domain; they do not establish transporter mechanisms, clinical exposure, species transfer or a universal applicability cutoff.

No molecular importance score or error pattern was used to relabel a compound. Consistent mistakes may reflect model limitations, missing biology, ambiguous endpoints or incorrect source annotation; this dataset cannot separate all four.


## Uncertainty and reproducibility

The analysis uses 1,000 molecular-base-group bootstrap replicates with fixed seeds, keeping related repeated rows together. Paired model comparisons use shared weights. Seed mean, SD and range are reported separately. Official fixed-test intervals also use seed-averaged predictions on the same test set. Repeated-split intervals condition on the five chosen splits; they are not five independent-population trials.

Sampling, split/training-seed variation and label-sensitivity uncertainty are distinct from experimental uncertainty. Species, assay, concentration, threshold and replication metadata are missing at record level. The study therefore cannot estimate biological ground-truth confidence or an experimental accuracy ceiling.

All 200 registered fits completed. Independent weighted-metric calculations passed 3,600 comparisons against standard implementations, plus 180 synthetic checks covering ties and zero weights. Source downloads, cohort membership and splits are hash-verified. Saved predictions retain the unchanged training outputs.

Verification found and corrected two numerical reporting issues: default CSV parsing merged near-equal probabilities, and float32 graph outputs produced small differences when read as float64. Exact round-trip loading and a common float64 reporting convention are used for final tables. Original receipts are separately checked at their original precision and row order; discrepancies are tabulated.

The full training replay reproduced all four non-forest models exactly, including graph training histories. Forest raw probabilities differed by at most 2.22e-16; calibration increased the largest probability difference to 2.131e-7 and metric difference to 7.20e-8. Rank and threshold metrics were unchanged. RF-only tolerances of 1e-6 for calibrated probabilities and 1e-7 for probability metrics are disclosed; this is numerical reproduction, not bitwise identity. The exact replay script also completed in a second isolated environment, resuming the already replayed model fits. Package-review receipts remain a separate release gate.


## Interpretation and release boundary

BBBP remains useful as a specified computational benchmark when its population, representation and split are stated. It does not support a single context-free performance number. The strict-distance stress test particularly weakens fingerprint-only LR while preserving competitive performance from a simple physicochemical rule. Model complexity is not a reliable substitute for evaluation design.

The contribution is a reproducible replication and extension of established curation, overrepresentation and benchmark-integrity research [2-5]. No priority claim is made for detecting duplicates or label conflicts. Journal novelty and external expert review are separate decisions from computational reproducibility.

The original publisher supplements declare CC BY-NC 4.0, while downstream TDC/Dataverse statements differ. The noncommercial research use and unresolved redistribution chain are documented. A proposed public package excludes raw and derived molecular records and supplies upstream download/hash instructions. Code-only delivery does not erase upstream use restrictions [18,19].

Recommendation: proceed to human scientific review of an unpublished computational replication report once the attached replay, figure/PDF review and distribution scans pass. Do not represent it as clinical validation, commercial-use clearance, verified biological label correction or a universally superior model. No publication, submission, deployment or third-party contact has occurred.

The complete methods/results report, aggregate metric tables, integrity/evidence archive, figure masters, code and verification receipts form one study record. Prior feasibility and intermediate editions are preserved.


## References

[1. Martins et al. (2012). A Bayesian approach to in silico blood-brain barrier penetration modeling. DOI:10.1021/ci300124c](https://doi.org/10.1021/ci300124c)

[2. Sakiyama, Fukuda and Okuno (2021). Prediction of BBBP based on molecular descriptors of free-form and in-blood-form datasets. DOI:10.3390/molecules26247428](https://doi.org/10.3390/molecules26247428)

[3. Wu et al. (2018). MoleculeNet: a benchmark for molecular machine learning. DOI:10.1039/C7SC02664A](https://doi.org/10.1039/C7SC02664A)

[4. Ferri and Garcia-Gomez (2026). Overrepresentation bias leads to performance overestimation in BBB permeability prediction models. DOI:10.1021/acs.jcim.5c02891](https://doi.org/10.1021/acs.jcim.5c02891)

[5. Schuh, Daniluk and Sieber (2026). Auditing widely used biomolecular benchmarks reveals systematic data inconsistencies. DOI:10.1039/D6SC01799A](https://doi.org/10.1039/D6SC01799A)

[6. Kelder et al. (1999). Polar molecular surface as a dominating determinant for oral absorption and brain penetration. PMID:10554091](https://pubmed.ncbi.nlm.nih.gov/10554091/)

[7. Gilmer et al. (2017). Neural message passing for quantum chemistry. PMLR70:1263-1272](https://proceedings.mlr.press/v70/gilmer17a.html)

[8. Schinkel et al. (1996). P-glycoprotein in the BBB of mice influences brain penetration and pharmacological activity. DOI:10.1172/JCI118699](https://pmc.ncbi.nlm.nih.gov/articles/PMC507337/)

[9. Alexander et al. (1994). Amino acids, parkinsonism and blood-to-brain levodopa transport. PMID:8058155](https://pubmed.ncbi.nlm.nih.gov/8058155/)

[10. Mannila et al. (2007). Plasma and CSF concentrations of indomethacin in children. PMID:17192507](https://pubmed.ncbi.nlm.nih.gov/17192507/)


## References and data access

[11. Sung et al. (1978). Miconazole therapy for fungal meningitis. PMID:580889](https://pubmed.ncbi.nlm.nih.gov/580889/)

[12. Methylprednisolone infusion during acute exacerbation of MS: plasma and CSF concentrations (1995). PMID:7628493](https://pubmed.ncbi.nlm.nih.gov/7628493/)

[13. Kubo et al. (2011). Brain H1 receptor occupancy of loratadine measured by PET. PMID:21433074](https://pubmed.ncbi.nlm.nih.gov/21433074/)

[14. Balis et al. (1986). Pharmacokinetics of trimetrexate in monkeys. PMID:2933145](https://pubmed.ncbi.nlm.nih.gov/2933145/)

[15. Neil-Dwyer et al. (1981). Beta-adrenoceptor blockers and the blood-brain barrier. PMID:6115665](https://pubmed.ncbi.nlm.nih.gov/6115665/)

[16. TDC issue #383. Unverified allegation; saved issue and comment state inspected](https://github.com/mims-harvard/TDC/issues/383)

[17. Iyer et al. (2002). Predicting BBB partitioning using membrane-interaction QSAR. PMID:12458666](https://pubmed.ncbi.nlm.nih.gov/12458666/)

[18. Publisher supplement metadata, Martins study](https://api.figshare.com/v2/articles/2511184)

[19. Creative Commons Attribution-NonCommercial 4.0 legal code](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en)

[20. Interaction of acupuncture and electroacupuncture on aspirin pharmacokinetics and brain blood flow in rats (2013). Parent/metabolite microdialysis results](https://pmc.ncbi.nlm.nih.gov/articles/PMC3858995/)

TDC input snapshots are obtained directly from Harvard Dataverse datafiles 4259566 and 4426004. MoleculeNet and the original publisher supplements are independently downloaded and checked against pinned SHA-256 hashes. The aggregate report and replay code do not redistribute molecular records.


## Full computational methods

# Methods and limitations for the completed-experiment report

## Study status and scope
This noncommercial computational study audits one specified BBB_Martins release and its source lineage. It does not measure transport experimentally, establish clinical validity or clear commercial reuse. The original official test is retained as a separate reference.

## Prospective choices and prior exposure
The analysis protocol was frozen before main performance scoring, after an explicitly disclosed feasibility audit and development-only pilot. Seeds1–5, eight evaluation designs, five models and material-improvement criteria were fixed. Two pre-performance amendments conservatively quarantined a structure with unstable standardization. Two later implementation corrections concern exact CSV floating-point loading and consistent metric precision; they do not alter fitted models, labels or split choices. These corrections and superseded diagnostics are retained.

## Provenance and molecular processing
Original source bytes are preserved with SHA-256 hashes. The reference cohort follows the TDC loader's removal of full-row duplicates. The integrity cohort applies RDKit Cleanup, requires exactly one carbon-containing connected component, preserves specified stereochemistry and uses Uncharger for a neutral-parent representation. Neutralization is not a prediction of physiological protonation. Canonical tautomer and stereo-free keys support auditing and grouping, not assertions of biological interchangeability. Records with contradictory neutral or tautomer labels are excluded without relabeling; exact neutral duplicates retain the first source-order representative. An explicitly logged unstable structure is quarantined only from the integrity cohort.

Integrity curation is retrospective and label-informed: all distributed labels are used to identify contradictory representations before splitting. It is not a simulated prospective curation workflow. This does not tune a model on test performance, but it changes the eligible evaluation population and limits comparison with the untouched official benchmark. Source-level experimental metadata are insufficient to infer the correct biological label for every contradiction.

## Evaluation populations
Reference evaluation includes exact TDC row-random and scaffold procedures plus the fixed official test. Five official runs vary the development split and training seed, not the official test population. Integrity evaluation groups stereo-free tautomer matches and fingerprint-near neighbors at Tanimoto>=0.9 before splitting. Additional scaffold and similarity designs union these groups with Murcko scaffold or similarity-component membership. Empty scaffolds form an explicit scaffold group. GroupShuffleSplit holds out20% of groups for test and then12.5% of remaining groups for validation; record proportions can differ materially. Strict-distance edges use thresholds0.6 and0.4. All registered seeds are retained; no class-balance retry is selected after observing scores.

Base-group identity connections are constructed on the full source-row audit, including rows later excluded; only eligible representatives add the additional scaffold or lower-threshold similarity edges. This conservative transitive grouping can join eligible representatives through excluded records. Report component sizes, group counts and actual class counts so the resulting evaluation population is transparent.

Official integrity evaluation gives eligible official-test representatives priority, removes development base groups overlapping those test groups and uses scaffold-grouped development validation. The retained official test is a modified population. Comparing original-full, original-common and cleaned-common scores distinguishes test restriction from the combined consequences of representation, training-set and development-split changes; it cannot isolate a causal cleaning effect.

## Models, calibration and computation
The fixed rule uses decreasing polar surface area, with heuristic uncalibrated sigmoid((90-TPSA)/20); the coefficients are conventions, not a published permeability law. Descriptor LR uses eight named RDKit features and training-only standard scaling. Morgan LR uses radius2,2048-bit fingerprints without chirality. Both use C=1 and liblinear with2000 maximum iterations. RF uses300 trees, leaf minimum2, square-root feature sampling and no class weighting.

The graph comparator is a small bond-aware message-passing network, with23 atom features,12 bond features, three64-dimensional message/update layers, a mean-plus-sum graph readout, and a64-dimensional hidden readout layer. It has99,521 parameters. Atom features encode a fixed element vocabulary/unknown category, degree, formal charge, hydrogen count, aromaticity, ring membership, mass and chiral tag. Bond features encode bond order, conjugation, ring membership and stereo. Mean incoming messages feed GRU updates. Training uses Adam(lr0.001,weight_decay0.0001), batches64, maximum60 epochs and patience10 on validation log loss. The best validation checkpoint is restored. It is trained from scratch with no pretrained weights or pretraining-overlap question. No claim of state-of-the-art architecture or optimized graph-model competitiveness is made.

Every model is calibrated on validation predictions by a sigmoid with nonnegative slope and free intercept; optimization bounds are slope[0,100], intercept[-100,100]. Primary binary decisions use calibrated probability>=0.5. Graph stopping and calibration reuse the same validation set, a limitation to disclose. Validation results do not provide independent performance evidence. No test-based hyperparameter, calibration or threshold selection occurs. CPU training is local with bounded threads; no paid service is used.

## Statistical reporting
Positive label is1. AUROC and average precision(the reported AUPRC convention), balanced accuracy, sensitivity, specificity, MCC, Brier, log loss and10-bin equal-width ECE are computed from saved predictions. Float64 reporting is used consistently; original float32 graph receipts are separately verified. Undefined single-class metrics remain missing. The independent weighted implementation is checked against standard metrics with ties and zero weights.

Intervals use1000 resamples of molecular base groups, retaining the repeated rows in a sampled group. Paired models share bootstrap group weights. Seed SD/range is reported separately. For the fixed official test, seed-averaged probabilities are also evaluated with a paired group bootstrap. For varying tests, averaged within-seed bootstrap deltas are conditional on the chosen five overlapping splits, not evidence from five independent populations. Split and model seeds change jointly for repeated-split designs; the experiment does not separately identify their variance components. Interval and subgroup analyses are conditional, with no claim to assay-level experimental uncertainty.

The two primary comparisons are RF and graph MPNN versus Morgan LR under strict0.4 chemical separation. A material gain requires mean AUROC improvement>=0.02, a positive conditional95% lower bound, and mean Brier deterioration<=0.01. These are research decision conventions and do not establish clinical benefit or familywise statistical significance. Other comparisons and subgroup/error-region analyses are exploratory.

## Domain and generalization limits
Nearest-training and nearest-development similarities are reported separately in the model track's representation. Similarity0–0.4,0.4–0.6,0.6–0.8,0.8–1; novel scaffold; empty scaffold; and confidence0.5–0.6,0.6–0.8,0.8–1 define registered diagnostic groups. Descriptor quartiles use training features only. Small groups(n<30 or either class<10) are flagged. Persistent errors require at least three distinct seed appearances and error fraction>=0.8; this is descriptive recurrence, not independent replication or a mechanism.

Chemical separation changes sample size, prevalence, scaffolds and chemistry. It is a stress test, not temporal, prospective or clinical validation. Missing species, exposure, assay, concentration, transport and threshold metadata prevent quantified experimental uncertainty or reliable retrospective biological relabeling. The source licensing discrepancy remains unresolved; the public candidate excludes molecular datasets and derived record-level outputs. Upstream download and use conditions still apply to a code-only replay.



## Complete numerical tables

All nine metrics, seed summaries, paired intervals, calibration bins and diagnostic subgroup tables are provided in the aggregate companion tables. Record-level audit and evidence tables remain in the private research archive.

Public subgroup tables retain aggregate sample counts and suppress metric values for groups with fewer than 30 records or fewer than 10 members of either class. Complete subgroup metrics and record-level audit/evidence remain in the private research archive.
