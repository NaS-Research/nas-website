"""Registered domain, calibration, common-test cleaning and error diagnostics."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import Descriptors,rdFingerprintGenerator
from inference import weighted_metrics,NAMES

def measured(y,p):
    values=weighted_metrics(np.asarray(y),np.asarray(p),np.ones(len(y)))[0]
    return {k:float(v) if np.isfinite(v) else None for k,v in zip(NAMES,values)}

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--results',type=Path,required=True);a=pa.parse_args();root=a.results;out=root/'diagnostics';out.mkdir(exist_ok=True)
    audit=pd.read_csv(root/'cohort_audit.csv',keep_default_na=False);splits=pd.read_csv(root/'splits.csv',float_precision='round_trip');RDLogger.DisableLog('rdApp.*');gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=False)
    fs={};ds={};desc_names=['MW','logP','TPSA'];funcs=[Descriptors.MolWt,Descriptors.MolLogP,Descriptors.TPSA]
    for name,smis in [('original',audit.canonical),('clean',[r.neutral or r.canonical for r in audit.itertuples()])]:
        mols=[Chem.MolFromSmiles(s) for s in smis];fs[name]=[gen.GetFingerprint(m) for m in mols];ds[name]=np.array([[f(m) for f in funcs] for m in mols])
    domain=[];summary=[];subgroups=[];allerrors=[];calibration=[]
    for (design,seed),sp in splits.groupby(['design','seed'],sort=False):
        tr,va,te=[sp[sp.partition.eq(k)].rid.to_numpy() for k in ['train','valid','test']];dev=np.r_[tr,va];rep='original' if design.endswith('reference') else 'clean';fp=fs[rep];desc=ds[rep];scaffold=audit.original_scaffold if rep=='original' else audit.scaffold
        train_sc=set(scaffold.iloc[tr]);dev_sc=set(scaffold.iloc[dev]);sim=np.array([max(DataStructs.BulkTanimotoSimilarity(fp[i],[fp[j] for j in tr])) for i in te]);simdev=np.array([max(DataStructs.BulkTanimotoSimilarity(fp[i],[fp[j] for j in dev])) for i in te])
        dd=pd.DataFrame(dict(rid=te,nearest_train_similarity=sim,nearest_development_similarity=simdev,scaffold_novel=[scaffold.iloc[i] not in train_sc for i in te],acyclic=[scaffold.iloc[i]=='' for i in te]));dd['design']=design;dd['seed']=seed;dd['representation']=rep
        for j,dn in enumerate(desc_names):
            boundaries=np.quantile(desc[tr,j],[.25,.5,.75]);dd[dn+'_train_quartile']=np.searchsorted(boundaries,desc[te,j],side='right')+1
            for part,ids in [('train',tr),('valid',va),('test',te)]:summary.append(dict(design=design,seed=seed,kind='descriptor_'+dn,partition=part,n=len(ids),mean=float(desc[ids,j].mean()),median=float(np.median(desc[ids,j])),minimum=float(desc[ids,j].min()),maximum=float(desc[ids,j].max())))
        domain.append(dd)
        for kind,vals in [('nearest_train_similarity',sim),('nearest_development_similarity',simdev)]:summary.append(dict(design=design,seed=seed,kind=kind,partition='test',n=len(vals),mean=float(vals.mean()),median=float(np.median(vals)),minimum=float(vals.min()),maximum=float(vals.max())))
        for model in ['rule','descriptor_lr','morgan_lr','rf','mpnn']:
            d=pd.read_csv(root/'runs'/f'{design}__{seed}__{model}.csv',float_precision='round_trip').merge(dd,on='rid',validate='one_to_one');d['model']=model;d['error']=(d.calibrated>=.5)!=d.label;d['confidence']=np.maximum(d.calibrated,1-d.calibrated);d['similarity_bin']=pd.cut(d.nearest_train_similarity,[-.001,.4,.6,.8,1.000001],right=False,labels=['0-.4','.4-.6','.6-.8','.8-1']).astype(str);d['confidence_bin']=pd.cut(d.confidence,[.5,.6,.8,1.000001],right=False,labels=['.5-.6','.6-.8','.8-1']).astype(str)
            allerrors.append(d)
            for axis in ['similarity_bin','confidence_bin','scaffold_novel','acyclic']+[n+'_train_quartile' for n in desc_names]:
                for value,g in d.groupby(axis,observed=True):
                    counts=g.label.value_counts();small=len(g)<30 or counts.get(0,0)<10 or counts.get(1,0)<10
                    subgroups.append(dict(design=design,seed=seed,model=model,axis=axis,category=str(value),n=len(g),positive=int(g.label.sum()),small_subgroup=small,**measured(g.label,g.calibrated)))
            before=measured(d.label,d.uncalibrated);after=measured(d.label,d.calibrated)
            calibration.append(dict(design=design,seed=seed,model=model,Brier_change=after['Brier']-before['Brier'],ECE_change=after['ECE']-before['ECE'],log_loss_change=after['log_loss']-before['log_loss']))
    pd.concat(domain).to_csv(out/'domain_rows.csv',index=False);pd.DataFrame(summary).to_csv(out/'distribution_summary.csv',index=False);pd.DataFrame(subgroups).to_csv(out/'subgroup_metrics.csv',index=False);pd.DataFrame(calibration).to_csv(out/'calibration_changes.csv',index=False)
    errors=pd.concat(allerrors);errors.to_csv(out/'prediction_error_rows.csv',index=False)
    recurring=errors.groupby(['design','model','base_group']).agg(test_appearances=('error','size'),errors=('error','sum'),distinct_seeds=('seed','nunique'),mean_confidence=('confidence','mean'),mean_train_similarity=('nearest_train_similarity','mean')).reset_index();recurring['error_fraction']=recurring.errors/recurring.test_appearances;recurring['consistent_error']=((recurring.distinct_seeds>=3)&(recurring.error_fraction>=.8));recurring.to_csv(out/'recurring_error_groups.csv',index=False)
    recurring.groupby(['design','model']).agg(observed_groups=('base_group','size'),consistent_error_groups=('consistent_error','sum')).reset_index().to_csv(out/'recurring_error_summary.csv',index=False)
    cleaning=[]
    for seed in range(1,6):
        for model in ['rule','descriptor_lr','morgan_lr','rf','mpnn']:
            raw=pd.read_csv(root/'runs'/f'official_reference__{seed}__{model}.csv',float_precision='round_trip');clean=pd.read_csv(root/'runs'/f'official_clean__{seed}__{model}.csv',float_precision='round_trip');common=raw.merge(clean,on='rid',suffixes=('_raw','_clean'),validate='one_to_one');assert len(common)==len(clean);assert (common.label_raw==common.label_clean).all()
            for condition,y,p in [('raw_full',raw.label,raw.calibrated),('raw_common',common.label_raw,common.calibrated_raw),('clean_common',common.label_clean,common.calibrated_clean)]:cleaning.append(dict(seed=seed,model=model,condition=condition,n=len(y),positive=int(y.sum()),**measured(y,p)))
    pd.DataFrame(cleaning).to_csv(out/'cleaning_common_test.csv',index=False)
    (out/'verification.json').write_text(json.dumps({'split_designs':splits.design.nunique(),'split_seed_combinations':splits.groupby(['design','seed']).ngroups,'registered_models':5,'test_domain_rows':sum(len(d) for d in domain),'same_test_labels_for_cleaning':True,'similarity_uses_each_model_track_representation':True,'subgroups_exploratory':True,'descriptor_quartiles_train_only':True},indent=2));print('Domain, error, calibration and cleaning diagnostics complete.',flush=True)
if __name__=='__main__':main()
