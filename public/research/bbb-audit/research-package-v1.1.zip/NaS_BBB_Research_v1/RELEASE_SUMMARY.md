# What we found

## Scope

This is a computational replication and extension using existing BBB datasets. The original audit completed 200 model runs and a full numerical replay. The follow-up completed 100 additional model runs. Fixed PSA-rule runs fit calibration, not a learned molecular representation. Repeated seeds are not independent external datasets.

## Results

- The original audit reconstructed 2,053 deposited records, 2,050 MoleculeNet rows, 2,039 TDC download rows and 2,030 loader/official-union records. It retained 1,935 representatives under conservative integrity rules. The historical count of 1,970 remains unresolved. No biological label correction was established.
- Performance depended strongly on evaluation design. In the original study, Morgan LR mean AUROC was 0.913 under grouped-random evaluation and 0.732 under strict separation. These use different test populations and do not isolate a causal leakage effect.
- The controlled follow-up fixed training size, class balance and test/validation records within each seed. Morgan LR mean AUROC increased from 0.816 to 0.869 when allowing closer training chemistry; this graph implementation did not improve in the same way. Neither result establishes universal superiority of a model family.
- Conservative overlap filtering retained 428 S-data records (353 positive, 75 negative). Separately assembled records do not prove independent assays. Two B3DB secondary cohorts had insufficient negative examples for strong comparative claims.
- An illustrative descriptor-LR confidence policy reduced mean accepted error from 12.34% to 5.55% at 74.95% actual coverage. The pointwise conditional 95% interval for the 6.79-percentage-point reduction was 4.60 to 9.20 points. Thresholds were fixed using separate original-data validation records, but this example was selected for discussion after the external results were available. It is not a prospectively confirmed or deployment-selected policy.
- The same policy retained about 80% of positives and 50% of negatives. Accepted specificity was only 52.90%. Restoring the original class balance gave 8.31% standardized accepted error. No policy met the implemented full usefulness criterion on the 244-record distant external subset.

## Why this matters

The contribution is a reproducible audit of what benchmark scores and selective-prediction gains can support. A high aggregate accuracy can conceal weak negative-class discrimination and changes in retained class mixture. The study supplies testable boundaries, not a clinically validated BBB tool or an established original biological discovery.

## Evidence boundaries

Protocols were locally frozen and hashed, not externally preregistered. Prior feasibility work and later corrections are disclosed. Bootstrap intervals condition on the fitted models and observed groups, not full training or assay uncertainty. Policy comparisons are exploratory across a large grid. Independent human methods review, authorship/disclosures and final release approval remain outstanding.
