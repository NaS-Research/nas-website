"""Compare private replay aggregates with the release; report every numerical change."""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True,help='Private directory passed to replay_followup.py');args=ap.parse_args();package=Path(__file__).resolve().parent;actual=args.work/'followup_v1/results/analysis';expected=package/'followup/aggregates';rows=[];structural_failures=[]
 names=['metrics_by_seed.csv','external_seed_averaged.csv','paired_comparisons.csv','condition_comparisons.csv','selective_metrics_by_seed.csv','policy_thresholds.csv','selective_risk_comparisons.csv','descriptor_distributions.csv','selection_class_mixture_diagnostic.csv','majority_baseline_diagnostic.csv','criterion_implementation_sensitivity.csv','cohort_cautions.csv']
 for name in names:
  a=pd.read_csv(expected/name,float_precision='round_trip');b=pd.read_csv(actual/name,float_precision='round_trip')
  if a.shape!=b.shape or a.columns.tolist()!=b.columns.tolist():structural_failures.append(name+': schema/shape');continue
  for col in a:
   if pd.api.types.is_numeric_dtype(a[col]) and not pd.api.types.is_bool_dtype(a[col]):
    if not a[col].isna().equals(b[col].isna()):structural_failures.append(name+': missingness '+col)
    delta=(a[col]-b[col]).abs();maximum=float(delta.max()) if delta.notna().any() else 0
    if maximum>0:rows.append({'file':name,'column':col,'maximum_absolute_difference':maximum,'rows_changed':int((delta>0).sum()),'exceeds_1e_7':maximum>1e-7})
    if pd.api.types.is_integer_dtype(a[col]) and maximum>0:structural_failures.append(name+': count/index '+col)
   elif not a[col].fillna('').equals(b[col].fillna('')):structural_failures.append(name+': categorical '+col)
 result={'structural_failures':structural_failures,'numeric_differences':rows,'interpretation':'Nonzero values require interpretation against METHODS_ADDENDUM and the supplied fresh replay receipt. This comparator does not silently pass every floating-point change or certify scientific validity.'};dest=args.work/'AGGREGATE_COMPARISON.json';dest.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
 if structural_failures:raise SystemExit(1)
if __name__=='__main__':main()
