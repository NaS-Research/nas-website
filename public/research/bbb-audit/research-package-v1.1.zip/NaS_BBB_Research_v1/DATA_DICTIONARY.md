# Data dictionary and statistical reading guide

All shared tables are aggregate or per-model-run summaries. Fractions/probabilities are 0-1, not percentages, unless a report explicitly converts them. Positive means the source label 1 (or the explicitly named quantitative logBB >= -1 sensitivity), not clinical efficacy. Counts are records, not patients or independent experiments.

## Audit

`audit/aggregates/preparation.json` and `split_diagnostics.csv` describe attrition and designs. `statistics/` contains seed summaries, intervals, paired contrasts, reliability bins and sensitivity tables. `diagnostics/` contains common-test, calibration and subgroup summaries; sparse subgroup metrics were suppressed according to the original report. The original report and protocol define its eight designs and all amendments. Original official test rows recur across seeds.

## Follow-up

- `designs.csv`: train, model-validation, policy-validation and test counts/positives for each design and seed; realized distance summaries where defined.
- `external_summary.json`: candidate/retained counts and exclusion categories; records may occur across cohorts, so totals must not be interpreted as unique independent experiments.
- `matched_feasibility.json`: pre-model feasibility counts and fixed per-class training size.
- `metrics_by_seed.csv`: ten metrics for each design/cohort/model/seed, with sample counts. `metric_summary.csv` reports mean/SD/min/max over seeds.
- `external_seed_averaged.csv`: metrics after averaging probabilities across seeds on each external record. This differs from averaging the metrics of separate fits.
- `paired_comparisons.csv`: left-minus-right AUROC/Brier differences, conditional 95% intervals, intervals adjusted for three contrasts within a population/metric, and valid bootstrap counts. Positive AUROC and negative Brier differences favor the left model.
- `condition_comparisons.csv`: exploratory broad-minus-strict comparisons on fixed test records.
- `policy_thresholds.csv`: design, seed, model, score, nominal validation coverage and learned cutoff. Nominal coverage is not achieved external coverage.
- `selective_metrics_by_seed.csv`: actual coverage, class coverage, accepted class counts, accepted metrics, rejected error and full error. `n` is the full evaluated cohort; `accepted` is the retained count.
- `selective_risk_comparisons.csv`: full error minus accepted error, intervals, adequacy gates and implemented research criterion. Positive reduction favors abstention. `exploratory=True` applies to every row.
- `criterion_implementation_sensitivity.csv`: original criterion plus post hoc requirement of >=50% coverage in every seed. It does not replace frozen analyses.
- `selection_class_mixture_diagnostic.csv`: descriptive reweighting/decomposition after results; definitions in the methods addendum and `release_diagnostics.py`.
- `majority_baseline_diagnostic.csv`: error of always predicting positive on full/accepted cohorts, alongside model performance. This is a descriptive baseline, not a newly registered hypothesis.
- `descriptor_distributions.csv`: mean/SD/median of eight molecular descriptors within each split partition; no molecular identities.
- `cohort_cautions.csv`: class counts and whether each population meets the external 20-per-class rule. This is an interpretation aid, not a filter chosen to improve results.

Model identifiers: `rule` = heuristic PSA rule; `descriptor_lr` = eight-descriptor logistic regression; `morgan_lr` = Morgan-fingerprint logistic regression; `rf` = random forest; `mpnn` = custom message-passing network; `ensemble` = unweighted mean of the five calibrated outputs.

Design identifiers: `matched_strict`, `matched_moderate`, `matched_broad` allow training-to-test similarity <0.4/<0.6/<0.9 with equal counts and fixed test/validation rows within seed; `external` fits only original data. Cohorts ending `_strict` are nested external subsets <0.4 from the entire original pool. They are not separate validations.

Blank/NaN metrics indicate undefined or unsupported calculations, not zero. Extremely sparse discrimination estimates should not be ranked even when a numerical value exists. Each bootstrap distribution has 1,000 attempted replicates; valid counts can be lower. No intervals estimate missing assay uncertainty or clinical decision benefit.
