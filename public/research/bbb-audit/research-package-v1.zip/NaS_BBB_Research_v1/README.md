# Testing the limits of blood-brain barrier prediction

NaS Research. NAS-BBB-001. Version 1.0, September 27, 2026.
https://nasresearch.bio/research/blood-brain-barrier-prediction-audit

Read `NaS_BBB_Prediction_Audit_v1.pdf` for the current combined report, then `METHODS_ADDENDUM.md`, `CLAIMS.csv` and the source-specific rights notes.

The original audit and follow-up reports, protocols, code and aggregate results are preserved byte-for-byte for provenance. Historical NAS-BBB-002 identifiers refer to the follow-up component of the combined NAS-BBB-001 publication. Candidate and review labels inside historical documents describe those earlier editions. Website publication does not establish independent peer review or clinical validation. No new biological mechanism or experimental measurements are claimed.

## Reproduction

The original audit has a tested self-contained entry point:

```sh
sh audit/replay.sh /absolute/path/to/private-audit-replay python3.12
```

For the full follow-up, install Python 3.12 and the pinned dependencies in an isolated environment, then run:

```sh
python3.12 -m venv /absolute/path/to/venv
/absolute/path/to/venv/bin/python -m pip install -r followup/code/requirements.lock
/absolute/path/to/venv/bin/python replay_followup.py --work /absolute/path/to/new-empty-private-followup-replay
/absolute/path/to/venv/bin/python verify_aggregates.py --work /absolute/path/to/new-empty-private-followup-replay
/absolute/path/to/venv/bin/python verify_aggregates.py --work /absolute/path/to/new-empty-private-followup-replay
```

The follow-up entry point verifies the environment, obtains original-host source bytes with fixed hashes, reconstructs the original cohort, freshly fits all 100 follow-up runs, calculates every frozen analysis and executes independent checks. It also generates separately labeled post hoc reporting diagnostics. Source drift stops execution. It does not rerun the original 200 model fits; use the original audit entry point for that. All downloaded molecular records and derived per-record outputs remain in the private output directory, outside this package. Neither script grants data-use rights.

The tested platform is Apple Silicon macOS with Python 3.12.14. Numerical identity on other operating systems is not claimed. CPU execution, no pretrained weights, paid compute or credentials are needed. Public checksums protect archive integrity; they do not certify scientific validity. See `verification/` for measured release-stage results.

## Why raw molecules are absent

The source rights chain is not uniformly unrestricted. This package includes our scientific code, aggregate tables, frozen protocols/amendments, figures and reports. It excludes original molecular tables, per-compound predictions, trained checkpoints, private logs, personal paths and publication-generation machinery. Reproduction retrieves upstream records directly subject to their source terms. See `RIGHTS_AND_AVAILABILITY.md`.
