# Author disclosures

Institutional author: NaS Research, as credited in the final report.

OpenAI Codex supported research planning, literature searches, code development, computational execution, analysis and manuscript preparation. Numerical results were generated and checked using the archived datasets and scientific code. Authors are responsible for the final methods, interpretation and manuscript.

Independent scientific review has not been completed. The project used existing datasets and conducted no new human-participant or animal experiments. Individual contributions, affiliations, funding and competing-interest details have not been supplied in this package.
