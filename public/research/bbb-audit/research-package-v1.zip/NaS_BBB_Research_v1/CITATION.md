# Citation

NaS Research (2026). Testing the limits of blood-brain barrier prediction. NAS-BBB-001, version 1.0.
https://nasresearch.bio/research/blood-brain-barrier-prediction-audit

Institutional research report. No journal acceptance, DOI, independent peer review or clinical validation is claimed.
