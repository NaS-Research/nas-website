# Scientific methods

This is a public methods summary, not the original internally frozen plan.
The plan was frozen before score retrieval, but was not externally preregistered.

The primary cohort contains 435 single-nucleotide variants at 145 RNU4-2 transcript
positions. Sensitivity analysis includes all 453 SNVs at 151 positions, adding 18
downstream variants. Source data include 539 edits; 86 non-SNV edits are excluded.
All 453 SNVs have AVI scores. No score tuning or clinical threshold fitting was performed.
Variant identifiers use forward-strand hg38 coordinates; RNU4-2 is on the reverse strand.

## Data columns
- ID: chromosome-position-reference-alternate identifier.
- Type: source edit type (SNV).
- nucleotide: source transcript-relative nucleotide number.
- CADD_score: CADD 1.7 score supplied by the experimental source.
- function_score_mean: published experimental function score.
- chromosome, position, ref, alt: forward-strand hg38 variant coordinates and alleles.
- primary: whether the variant belongs to transcript nucleotides 1 through 145.
- avi: raw Atlas AVI_SCORE retrieved through the official client on 9 September 2026 UTC.
- rank_disagreement (exploratory table only): absolute difference between average AVI
  and cell-fitness-loss ranks, divided by the 435-variant primary sample size.

The outcome is negative function_score_mean, representing greater cell-fitness loss.
Spearman correlation compares predicted scores with this outcome. Within each position,
all alternate-allele pairs are compared: correct ordering scores 1, reverse ordering 0,
and prediction ties 0.5; exact experimental ties are excluded. Average within each site,
then across sites with equal weight. Compare AVI and CADD on identical observations.

Generate 2,000 paired position-cluster bootstrap resamples with seed 20260909, keeping
all alternative alleles together. Report percentile 95% intervals for each metric and
the AVI-minus-CADD differences. The same functions evaluate the sensitivity cohort.

The exploratory table selects the ten largest normalized absolute rank disagreements,
with variant ID as tie-breaker. These are not independently validated mechanisms.

## Interpretation
Weak rank agreement in this one HAP1 cell-fitness assay does not establish overall
Atlas performance, clinical accuracy, patient severity, or equivalence to CADD.
Experimental uncertainty and dependence between nearby positions remain limitations.
Google already evaluated RNU4-2; this is a focused reanalysis of the final published
experimental table, not a new independent laboratory validation or an exact replication
of Google's filtered input snapshot. See the paper for full sources and limitations.
