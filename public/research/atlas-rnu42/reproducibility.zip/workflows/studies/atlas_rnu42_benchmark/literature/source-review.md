# Targeted source review

This is a targeted methods/overlap review, not a systematic literature review.

- Atlas preprint, Methods p.28: Findlay 2018 BRCA1 is one of four online
  development-evaluation screens. RNU4-2 is among the remaining ten held-out
  screens. Exact equivalence to Google's filtered source snapshot is unverified.
- De Jonghe et al. (2026), DOI 10.1038/s41586-026-10334-9: Supplementary Table 1
  provides experimental variant IDs and cell-fitness measurements. Methods identify
  hg38 coordinates and CADD 1.7. The source article is CC BY 4.0 with its stated
  third-party exceptions. No participant-level data were needed or used.
- Official API reference: https://www.alphagenomedocs.com/api/atlas.html documents
  query_variants and scorer metadata. AVI_SCORE returns one raw score per variant.
- UCSC API provided the hg38 forward-reference interval. All 453 allele checks passed.

The RNU4-2 question and analysis plan were fixed before its AVI scores or
association results were inspected. The broader literature search was not
prospectively registered and must not be represented as such.

## Post-result context review, 9 September 2026 UTC

The v1 report omitted a directly relevant discussion passage. Atlas preprint p.18
explicitly identifies RNU4-2 as an example of missing training coverage because
poly(A)-selected RNA-seq excludes non-polyadenylated noncoding RNAs. Page 5 reports
the highest Spearman correlation for AVI in eight of ten held-out SGE screens,
not uniform superiority across every gene. This context was checked after the
results and added to v1.1; it is not a pre-result selection rationale.

The present result is consistent with that acknowledged limitation. The benchmark
does not establish the cause of its weak association, contradict aggregate results,
or discover a previously unreported limitation. The within-position ordering metric
remains a focused descriptive extension. Statistical reproducibility does not
substitute for independent scientific validation.
