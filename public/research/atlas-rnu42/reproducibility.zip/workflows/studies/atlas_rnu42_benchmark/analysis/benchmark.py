"""Reproducible public-data Atlas benchmark; outputs require the external drive."""

import argparse
import hashlib
import importlib.metadata
import itertools
import json
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr

ROOT = Path("/Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-AGA-001")
SOURCE = ROOT / "snapshots/source-v1"
WORKSPACE = Path(__file__).resolve().parents[1]
REPO = WORKSPACE.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")


def check_storage():
    if not Path("/Volumes/AGNDJ 6TB").is_mount() or not ROOT.is_dir():
        raise RuntimeError("External research drive must be mounted")


def prepare():
    source = SOURCE / "rnu42-supplementary-table-1.xlsx"
    frame = pd.read_excel(
        source,
        sheet_name=0,
        header=1,
        usecols=["ID", "Type", "nucleotide", "CADD_score", "function_score_mean"],
    )
    if len(frame) != 539 or frame["ID"].duplicated().any():
        raise ValueError("Unexpected experimental source identities")
    frame = frame.loc[frame.Type.eq("SNV")].copy()
    if len(frame) != 453:
        raise ValueError("Expected 453 experimental SNVs")
    parts = frame.ID.str.extract(r"^(chr12)-(\d+)-([ACGT])-([ACGT])$")
    if parts.isna().any().any():
        raise ValueError("Unexpected forward-strand variant ID")
    frame["chromosome"] = parts[0]
    frame["position"] = parts[1].astype(int)
    frame["ref"] = parts[2]
    frame["alt"] = parts[3]
    reference = json.loads((SOURCE / "hg38-reference.json").read_text())
    if reference["genome"] != "hg38" or reference["chrom"] != "chr12":
        raise ValueError("Reference identity mismatch")
    dna = reference["dna"].upper()
    if len(dna) != reference["end"] - reference["start"]:
        raise ValueError("Reference sequence length mismatch")
    for row in frame.itertuples():
        offset = row.position - 1 - reference["start"]
        if not 0 <= offset < len(dna) or dna[offset] != row.ref or row.ref == row.alt:
            raise ValueError(f"Reference allele mismatch: {row.ID}")
    if not frame.groupby("position").alt.nunique().eq(3).all():
        raise ValueError("Expected three alternatives per position")
    for col in ["CADD_score", "function_score_mean"]:
        if not np.isfinite(frame[col]).all():
            raise ValueError(f"Missing or nonfinite {col}")
    frame["primary"] = frame.nucleotide.between(1, 145)
    if frame.primary.sum() != 435:
        raise ValueError("Unexpected primary cohort")
    frame = frame.sort_values("ID").reset_index(drop=True)
    destination = ROOT / "snapshots/prepared-v1"
    destination.mkdir(parents=True, exist_ok=False)
    frame.to_csv(destination / "variants.csv", index=False)
    write_json(
        destination / "receipt.json",
        {
            "created_utc": datetime.now(UTC).isoformat(),
            "source_sha256": sha(source),
            "reference_sha256": sha(SOURCE / "hg38-reference.json"),
            "plan_sha256": sha(WORKSPACE / "protocol/analysis-plan.md"),
            "code_sha256": sha(Path(__file__)),
            "variants_sha256": sha(destination / "variants.csv"),
            "source_rows": 539,
            "snvs": len(frame),
            "primary_snvs": int(frame.primary.sum()),
            "reference_matches": len(frame),
            "unique_positions": int(frame.position.nunique()),
            "primary_positions": int(frame.loc[frame.primary, "position"].nunique()),
            "excluded_indels_and_other_edits": 86,
            "primary_excluded_downstream_snvs": 18,
            "atlas_scores_inspected": False,
        },
    )
    print("Prepared 453 reference-verified SNVs; primary cohort 435.", flush=True)


def fetch():
    from alphagenome.atlas import atlas
    from alphagenome.data import genome
    from dotenv import dotenv_values

    frame = pd.read_csv(ROOT / "snapshots/prepared-v1/variants.csv")
    receipt = json.loads((ROOT / "snapshots/prepared-v1/receipt.json").read_text())
    if sha(WORKSPACE / "protocol/analysis-plan.md") != receipt["plan_sha256"]:
        raise ValueError("Plan changed after input freeze")
    if sha(ROOT / "snapshots/prepared-v1/variants.csv") != receipt["variants_sha256"]:
        raise ValueError("Prepared variants changed")
    client = atlas.create(dotenv_values(REPO / ".env")["ALPHAGENOME_API_KEY"], timeout=30)
    destination = ROOT / "snapshots/atlas-v1"
    destination.mkdir(parents=True, exist_ok=True)
    for start in range(0, len(frame), 30):
        chunk = frame.iloc[start : start + 30]
        output = destination / f"batch-{start:04d}.json"
        if output.exists():
            continue
        variants = [
            genome.Variant(r.chromosome, int(r.position), r.ref, r.alt) for r in chunk.itertuples()
        ]
        result = client.query_variants(
            variants, requested_scorers=["AVI_SCORE"], max_workers=4, progress_bar=False
        )
        adata = result["AVI_SCORE"]
        if adata.X.shape[1] != 1:
            raise ValueError("Expected one AVI score column")
        returned = {
            str(v): float(score)
            for v, score in zip(adata.obs["variant"], np.asarray(adata.X)[:, 0], strict=True)
        }
        if len(returned) != len(chunk) or set(returned) != {str(v) for v in variants}:
            raise ValueError("Atlas returned incomplete or mismatched variants")
        values = [
            {"ID": row.ID, "avi": returned[str(variant)]}
            for row, variant in zip(chunk.itertuples(), variants, strict=True)
        ]
        write_json(
            output,
            {
                "created_utc": datetime.now(UTC).isoformat(),
                "scorer": "AVI_SCORE",
                "track_metadata": adata.var.to_dict("records"),
                "rows": values,
            },
        )
        print(f"Atlas received {min(start + 30, len(frame))}/{len(frame)}", flush=True)


def correlation(scores, losses):
    return float(spearmanr(scores, losses).statistic)


def allele_concordance(scores, losses):
    values = []
    for i, j in itertools.combinations(range(len(scores)), 2):
        observed = np.sign(losses[i] - losses[j])
        predicted = np.sign(scores[i] - scores[j])
        if observed:
            values.append(0.5 if predicted == 0 else float(observed == predicted))
    return float(np.mean(values)) if values else float("nan")


def evaluate(frame, bootstrap=2000):
    loss = -frame.function_score_mean.to_numpy()
    avi = frame.avi.to_numpy()
    cadd = frame.CADD_score.to_numpy()
    groups = [
        np.flatnonzero(frame.position.to_numpy() == p) for p in sorted(frame.position.unique())
    ]
    per_site = np.array(
        [
            [allele_concordance(avi[g], loss[g]), allele_concordance(cadd[g], loss[g])]
            for g in groups
        ]
    )
    if not np.isfinite(per_site).all():
        raise ValueError("Site with no experimentally ordered pairs")
    point = [
        correlation(avi, loss),
        correlation(cadd, loss),
        float(per_site[:, 0].mean()),
        float(per_site[:, 1].mean()),
    ]
    rng = np.random.default_rng(20260909)
    samples = []
    for _ in range(bootstrap):
        selected = rng.integers(0, len(groups), len(groups))
        indices = np.concatenate([groups[i] for i in selected])
        samples.append(
            [
                correlation(avi[indices], loss[indices]),
                correlation(cadd[indices], loss[indices]),
                per_site[selected, 0].mean(),
                per_site[selected, 1].mean(),
            ]
        )
    samples = np.asarray(samples)
    if not np.isfinite(samples).all():
        raise ValueError("Nonfinite bootstrap estimate")
    result = {
        "n": len(frame),
        "positions": len(groups),
        "bootstrap_replicates": bootstrap,
        "seed": 20260909,
    }
    for index, name in enumerate(
        ["avi_spearman", "cadd_spearman", "avi_within_position", "cadd_within_position"]
    ):
        result[name] = {
            "estimate": point[index],
            "ci95": np.quantile(samples[:, index], [0.025, 0.975]).tolist(),
        }
    for name, left, right in [("spearman_difference", 0, 1), ("within_position_difference", 2, 3)]:
        result[name] = {
            "estimate": point[left] - point[right],
            "ci95": np.quantile(samples[:, left] - samples[:, right], [0.025, 0.975]).tolist(),
        }
    return result


def analyze():
    destination = ROOT / "runs/analysis-v1"
    destination.mkdir(parents=True, exist_ok=False)
    frame = pd.read_csv(ROOT / "snapshots/prepared-v1/variants.csv")
    rows = []
    batches = sorted((ROOT / "snapshots/atlas-v1").glob("batch-*.json"))
    for batch in batches:
        rows.extend(json.loads(batch.read_text())["rows"])
    scores = pd.DataFrame(rows)
    if len(scores) != 453 or scores.ID.duplicated().any() or not np.isfinite(scores.avi).all():
        raise ValueError("Atlas snapshot is incomplete")
    frame = frame.merge(scores, on="ID", how="left", validate="one_to_one")
    if frame.avi.isna().any():
        raise ValueError("Unmatched experimental variant")
    primary = frame.loc[frame.primary].copy().reset_index(drop=True)
    result = {
        "primary": evaluate(primary),
        "sensitivity_all_snvs": evaluate(frame),
        "missing_atlas_scores": 0,
        "plan_sha256": sha(WORKSPACE / "protocol/analysis-plan.md"),
        "code_sha256": sha(Path(__file__)),
        "input_hashes": {str(p.relative_to(ROOT)): sha(p) for p in batches},
        "packages": {
            p: importlib.metadata.version(p)
            for p in ["numpy", "pandas", "scipy", "alphagenome", "openpyxl"]
        },
    }
    frame.to_csv(destination / "joined-variants.csv", index=False)
    primary["rank_disagreement"] = np.abs(
        rankdata(primary.avi) - rankdata(-primary.function_score_mean)
    ) / len(primary)
    primary.sort_values(["rank_disagreement", "ID"], ascending=[False, True]).head(10).to_csv(
        destination / "exploratory-disagreements.csv", index=False
    )
    write_json(destination / "results.json", result)
    print(json.dumps(result["primary"], indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=["prepare", "fetch", "analyze"])
    args = parser.parse_args()
    check_storage()
    {"prepare": prepare, "fetch": fetch, "analyze": analyze}[args.stage]()
