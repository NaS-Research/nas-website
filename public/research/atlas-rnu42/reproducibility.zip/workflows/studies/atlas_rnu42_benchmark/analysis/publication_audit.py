import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

root = Path("/Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-AGA-001")
repo = Path(__file__).resolve().parents[4]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


receipt = json.loads((root / "snapshots/prepared-v1/receipt.json").read_text())
assert (
    sha(root / "snapshots/source-v1/rnu42-supplementary-table-1.xlsx") == receipt["source_sha256"]
)
assert sha(root / "snapshots/source-v1/hg38-reference.json") == receipt["reference_sha256"]
assert sha(root / "snapshots/prepared-v1/variants.csv") == receipt["variants_sha256"]
assert (
    sha(repo / "workflows/studies/atlas_rnu42_benchmark/protocol/analysis-plan.md")
    == receipt["plan_sha256"]
)
source = pd.read_excel(
    root / "snapshots/source-v1/rnu42-supplementary-table-1.xlsx",
    header=1,
    usecols=["ID", "Type", "nucleotide", "CADD_score", "function_score_mean"],
)
data = (
    pd.read_csv(root / "runs/analysis-v1/joined-variants.csv")
    .sort_values("ID")
    .reset_index(drop=True)
)
expected = source.loc[source.Type.eq("SNV")].sort_values("ID").reset_index(drop=True)
pd.testing.assert_frame_equal(
    expected, data[expected.columns], check_dtype=False, rtol=1e-13, atol=1e-13
)
assert len(source) == 539 and len(data) == 453
assert not data.ID.duplicated().any()
reference = json.loads((root / "snapshots/source-v1/hg38-reference.json").read_text())
for row in data.itertuples():
    assert f"{row.chromosome}-{row.position}-{row.ref}-{row.alt}" == row.ID
    assert reference["dna"][row.position - 1 - reference["start"]].upper() == row.ref
    assert (
        (row.nucleotide == 120291904 - row.position)
        if row.primary
        else (pd.isna(row.nucleotide) and 120291753 <= row.position <= 120291758)
    )
for _, g in data.groupby("position"):
    assert set(g.alt) == set("ACGT") - {g.ref.iloc[0]}
assert data.primary.equals(data.nucleotide.between(1, 145))
batches = []
for p in sorted((root / "snapshots/atlas-v1").glob("batch-*.json")):
    b = json.loads(p.read_text())
    assert b["scorer"] == "AVI_SCORE"
    batches += b["rows"]
api = pd.DataFrame(batches).sort_values("ID").reset_index(drop=True)
pd.testing.assert_frame_equal(api, data[["ID", "avi"]])
results = json.loads((root / "runs/analysis-v1/results.json").read_text())
for rel, digest in results["input_hashes"].items():
    assert sha(root / rel) == digest
assert (
    sha(repo / "workflows/studies/atlas_rnu42_benchmark/analysis/benchmark.py")
    == results["code_sha256"]
)


# Independent ranks, matrix comparison and weighted cluster-resampling implementation.
def metrics(df, draws=None):
    sites = [g for _, g in df.groupby("position", sort=True)]
    rows = pd.concat(sites if draws is None else [sites[i] for i in draws], ignore_index=True)
    y = (-rows.function_score_mean).rank(method="average")
    ranks = [rows[k].rank(method="average") for k in ["avi", "CADD_score"]]
    corr = [float(np.corrcoef(x, y)[0, 1]) for x in ranks]
    return corr


checks = {}
for name, df in [("primary", data.loc[data.primary]), ("sensitivity_all_snvs", data)]:
    sites = [g for _, g in df.groupby("position", sort=True)]
    per = []
    for g in sites:
        loss = -g.function_score_mean.to_numpy()
        truth = np.sign(loss[:, None] - loss)
        mask = np.triu(np.ones((3, 3), dtype=bool), 1) & (truth != 0)
        score = []
        for k in ["avi", "CADD_score"]:
            x = g[k].to_numpy()
            order = np.sign(x[:, None] - x)
            v = np.where(order == 0, 0.5, (order == truth).astype(float))
            score.append(v[mask].mean())
        per.append(score)
    per = np.array(per)
    point = np.array(metrics(df) + per.mean(axis=0).tolist())
    rng = np.random.default_rng(20260909)
    samples = []
    for _ in range(2000):
        draws = rng.integers(len(sites), size=len(sites))
        weights = np.bincount(draws, minlength=len(sites))
        samples.append(metrics(df, draws) + np.average(per, axis=0, weights=weights).tolist())
    samples = np.array(samples)
    keys = ["avi_spearman", "cadd_spearman", "avi_within_position", "cadd_within_position"]
    for j, k in enumerate(keys):
        np.testing.assert_allclose(point[j], results[name][k]["estimate"], rtol=0, atol=1e-14)
        np.testing.assert_allclose(
            np.percentile(samples[:, j], [2.5, 97.5]), results[name][k]["ci95"], rtol=0, atol=1e-14
        )
    for k, a, b in [("spearman_difference", 0, 1), ("within_position_difference", 2, 3)]:
        np.testing.assert_allclose(
            point[a] - point[b], results[name][k]["estimate"], rtol=0, atol=1e-14
        )
        np.testing.assert_allclose(
            np.percentile(samples[:, a] - samples[:, b], [2.5, 97.5]),
            results[name][k]["ci95"],
            rtol=0,
            atol=1e-14,
        )
    checks[name] = {
        "variants": len(df),
        "positions": len(sites),
        "independent_point_and_interval_agreement": True,
        "tolerance": 1e-14,
    }
# Exploratory ranking also has to agree with the frozen plan.
primary = data.loc[data.primary].copy()
primary["rank_disagreement"] = (
    primary.avi.rank() - (-primary.function_score_mean).rank()
).abs() / len(primary)
top = primary.sort_values(["rank_disagreement", "ID"], ascending=[False, True]).head(10)
assert (
    top.ID.tolist()
    == pd.read_csv(root / "runs/analysis-v1/exploratory-disagreements.csv").ID.tolist()
)
out = root / "runs/publication-audit-v1"
out.mkdir(exist_ok=True)
report = {
    "status": "passed",
    "source_and_reference_hashes": "passed",
    "all_453_source_fields_and_API_scores": "passed",
    "coordinate_strand_and_alternate_sets": "passed",
    "independent_analysis": checks,
    "exploratory_selection": "passed",
    "review_type": "AI-assisted computational audit, not external expert review or peer review",
    "limitations": [
        "Single gene and assay",
        "Adjacent-site dependence not fully modeled",
        "Experimental uncertainty not propagated",
        "Not the exact Google filtered benchmark",
        "Known limitation, not a novel discovery",
    ],
}
(out / "review.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
