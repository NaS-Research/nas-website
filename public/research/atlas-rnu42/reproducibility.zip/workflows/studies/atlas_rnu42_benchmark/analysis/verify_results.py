"""Cross-check published inputs and independent formulations of point estimates."""

import json
import runpy
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-AGA-001")
MODULE = runpy.run_path(str(Path(__file__).with_name("benchmark.py")))
MODULE["check_storage"]()
joined = pd.read_csv(ROOT / "runs/analysis-v1/joined-variants.csv")
original = pd.read_excel(
    ROOT / "snapshots/source-v1/rnu42-supplementary-table-1.xlsx",
    sheet_name=0,
    header=1,
    usecols=["ID", "Type", "nucleotide", "CADD_score", "function_score_mean"],
)
expected = original.loc[original.Type.eq("SNV")].sort_values("ID").reset_index(drop=True)
pd.testing.assert_frame_equal(
    expected, joined[expected.columns], check_dtype=False, rtol=1e-13, atol=1e-13
)
results = json.loads((ROOT / "runs/analysis-v1/results.json").read_text())
primary = joined.loc[joined.primary].copy()
loss = -primary.function_score_mean
independent = {}
for col, prefix in [("avi", "avi"), ("CADD_score", "cadd")]:
    ranks_x = primary[col].rank().to_numpy()
    ranks_y = loss.rank().to_numpy()
    rho = float(np.corrcoef(ranks_x, ranks_y)[0, 1])
    assert abs(rho - results["primary"][prefix + "_spearman"]["estimate"]) < 1e-14
    site_values = []
    for _, site in primary.groupby("position"):
        predicted = site[col].to_numpy()
        measured = -site.function_score_mean.to_numpy()
        xdiff = predicted[:, None] - predicted[None, :]
        ydiff = measured[:, None] - measured[None, :]
        mask = np.triu(np.ones(xdiff.shape, dtype=bool), k=1) & (ydiff != 0)
        agreement = (np.sign(xdiff) == np.sign(ydiff)).astype(float)
        agreement[xdiff == 0] = 0.5
        site_values.append(float(agreement[mask].mean()))
    concordance = float(np.mean(site_values))
    assert abs(concordance - results["primary"][prefix + "_within_position"]["estimate"]) < 1e-14
    independent[prefix] = {"spearman": rho, "within_position": concordance}
for name, frame in [("primary", primary), ("sensitivity_all_snvs", joined)]:
    assert MODULE["evaluate"](frame) == results[name], "Bootstrap replay differs"
for relative, expected_hash in results["input_hashes"].items():
    assert MODULE["sha"](ROOT / relative) == expected_hash
assert MODULE["sha"](Path(__file__).with_name("benchmark.py")) == results["code_sha256"]
assert (
    MODULE["sha"](Path(__file__).parents[1] / "protocol/analysis-plan.md") == results["plan_sha256"]
)
MODULE["write_json"](
    ROOT / "runs/analysis-v1/verification.json",
    {
        "source_field_comparison": "passed for all 453 SNVs",
        "independent_point_estimates": independent,
        "primary_and_sensitivity_bootstrap_replay": "exact",
        "input_code_and_plan_hashes": "passed",
        "clinical_validation": False,
        "peer_review": False,
    },
)
print(
    "Source values, independent point estimates, frozen hashes, and both bootstrap replays passed."
)
