# NAS-AGA-001: Atlas ranking of RNU4-2 experimental effects

Version 1.0.0, 2026-09-09 UTC. Frozen before any RNU4-2 AVI score retrieval or
association calculation. Authorized by the user's instruction to work continuously
on a free life-sciences experiment until results are ready to post. This is an
internally recorded analysis plan, not an externally registered preregistration
or a completed human scientific review.

## Selection and interpretation

RNU4-2 is a non-protein-coding small nuclear RNA. Use the public experimental
Supplementary Table 1 from De Jonghe et al. (2026), DOI 10.1038/s41586-026-10334-9.
The initial Findlay 2018 BRCA1 candidate is superseded because the Atlas preprint,
Methods p.28, explicitly lists it among four online evaluation datasets used during
development. RNU4-2 is among the ten held-out evaluations. This project replicates
a published benchmark using the final 2026 experimental table; it is neither a new
independent biological validation nor an exact reproduction of an unverified
Google input snapshot. Exact equivalence to Google's filtered variant set is not claimed.

Use only digital public data. No patient records, clinical classifications, population
counts, biospecimens, new wet-lab work, paid APIs, or model training are required.

## Inputs and cohort

- Experimental table: 539 variants, 453 SNVs and 86 other edits.
- Primary: the 435 SNVs assigned transcript nucleotides 1..145 (three alternatives
  at each position). Exclude 18 downstream SNVs and all indels from primary.
- Prespecified sensitivity: all 453 SNVs, including the six downstream positions.
- Outcome: minus `function_score_mean`, so larger means greater cell-fitness loss.
- Predictions: Atlas `AVI_SCORE`, X from the official client; retain returned
  metadata and label it as the API score without assuming an undocumented scale.
  The rank-based analyses are invariant to strictly increasing rescaling. Comparator: published
  `CADD_score` (CADD 1.7 according to the source paper). No re-scoring or tuning.
- IDs are forward-strand hg38 `chr12-position-ref-alt`; transcript is reverse strand.
  Verify every reference allele against the UCSC hg38 interval [120291752,120291903).
  Verify three distinct alternate alleles per position and unique variant IDs.
- Record missing scores and retain matched finite observations only. Fail rather
  than silently reducing primary if any experimental SNV fails reference matching.

## Prespecified analyses

Primary: Spearman correlation of AVI with experimental cell-fitness loss across
the 435 transcript SNVs. Compare with CADD on the identical matched observations.
Report both correlations and their paired difference, not an unpaired comparison.

Secondary: within-position allele ordering. For each position, compare all three
pairs of alternate alleles. A prediction earns 1 for ordering the larger measured
loss higher, 0 for reversing it, and 0.5 for a prediction tie. Exclude pairs with
exact experimental-score ties. Average within each position, then across positions.
This asks whether a method distinguishes alternatives at the same site rather than
merely assigning a high score to an important region. Experimental ordering is noisy;
do not interpret tiny experimental differences as certain biological truth.

Uncertainty: 2,000 paired bootstrap samples of genomic positions with replacement,
seed 20260909. Keep all alternate alleles at each sampled position together.
Use percentile 95% intervals for each metric and AVI minus CADD. Report intervals
as conditional on this one assay, noting possible dependence between adjacent sites.
No population-wide clinical inference, p-value thresholding, or optimized cutoff.
Apply the same primary correlation comparison descriptively to all 453 SNVs as
the prespecified sensitivity. Do not select a cohort based on performance.

Exploratory: ten largest absolute AVI/experimental percentile-rank disagreements,
average ranks and genomic ID tie-breaker. Clearly separate them from primary analyses.
No inferred mechanism is experimentally established by a disagreement.

## Outputs and claims

Two figures: score versus experimental loss for AVI and CADD; overall and
within-position paired performance with bootstrap intervals. Short report includes
all prespecified results, missingness, source hashes, code/runtime versions,
selection history, citations, limitations, and an explicit not-peer-reviewed label.
Do not equate HAP1 cell fitness with pathogenicity, patient severity, or clinical utility.
No claim of a novel gene/disease discovery or first evaluation of Atlas on this gene.

The public source article is CC BY 4.0, subject to its third-party exceptions.
Google's accepted terms allow publication with required attribution and output terms;
AVI has an explicit exception in the account terms. Publish minimal derived tables,
methods, and figures, never credentials. Other Atlas modalities are outside this run.

Data and outputs: /Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-AGA-001.
Require the external volume to be mounted. Code lives in NaS-Core. Report completion
means a validated draft ready for founder review, not a completed peer review or post.
