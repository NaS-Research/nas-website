"""Apply the shared NaS publication format to the verified Atlas study."""

import json
import runpy
from pathlib import Path

ROOT = Path("/Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-AGA-001")
if not Path("/Volumes/AGNDJ 6TB").is_mount():
    raise RuntimeError("External drive must be mounted")
OUT = ROOT / "releases/research-note-v1.2"
TEMPLATE = Path(__file__).resolve().parents[3] / "publications/nas_paper_v1"
content = json.loads((OUT / "report-content.json").read_text())


def section(index):
    heading, text = content["sections"][index]
    return [{"type": "heading", "text": heading}, {"type": "paragraph", "text": text}]


document = {
    "title": content["title"],
    "subtitle": "Variant ranking against published experimental cell-fitness measurements",
    "series": "Computational life sciences / Research note",
    "study_id": "NAS-AGA-001",
    "version": "Research note v1.2",
    "date": "9 September 2026 UTC",
    "author": "NaS Research",
    "review_state": "Not peer reviewed",
    "abstract": content["sections"][0][1],
    "cover_note": (
        "Prepared with AI assistance; computational audit completed. "
        "One RNA and one experimental endpoint; no clinical validation. "
        "Version 1.2 is the public research-note edition with an expanded computational audit. "
        "Numerical results are unchanged."
    ),
    "pages": [
        [
            {"type": "heading", "text": "Results"},
            {"type": "table", "rows": content["table"]},
            {
                "type": "paragraph",
                "style": "small",
                "text": (
                    "Brackets: 95% position-cluster bootstrap intervals. pp: percentage points. "
                    "Primary analysis: 435 transcript SNVs at 145 positions."
                ),
            },
            {
                "type": "figure",
                "path": "figure-1-score-agreement.png",
                "caption": (
                    "Figure 1. Scores versus experimental cell-fitness loss. Each point is one "
                    "transcript SNV. AVI uses the raw API score; correlation is not accuracy."
                ),
            },
            {
                "type": "figure",
                "path": "figure-2-performance.png",
                "caption": (
                    "Figure 2. Estimates and 95% bootstrap intervals. "
                    "The within-position statistic "
                    "compares pairs of alternate alleles; 0.5 is its chance expectation."
                ),
            },
        ],
        [
            {"type": "heading", "text": "Question and methods"},
            {"type": "paragraph", "text": content["sections"][1][1]},
            *section(2),
            *section(3),
            *section(4),
            *section(5),
        ],
        [
            {"type": "heading", "text": "Context and reproducibility"},
            *section(6),
            *section(7),
            {"type": "heading", "text": "References and attribution"},
            {"type": "references", "items": content["references"]},
            {
                "type": "paragraph",
                "style": "small",
                "text": (
                    "Experimental source: De Jonghe et al., CC BY 4.0, "
                    "subject to source exceptions. "
                    "Figures are NaS derivatives. AlphaGenome outputs are subject to applicable "
                    "Google terms. No credentials are included."
                ),
            },
        ],
    ],
}
runpy.run_path(str(TEMPLATE / "render.py"))["render"](document, OUT / "research-note.pdf", OUT)
(OUT / "publication-layout.json").write_text(json.dumps(document, indent=2) + "\n")
print(OUT / "research-note.pdf")
