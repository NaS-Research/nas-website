"""Render the executed benchmark as figures and a standalone research note."""

# Embedded report prose and self-contained HTML intentionally retain long strings.
# ruff: noqa: E501

import base64
import hashlib
import html
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path("/Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-AGA-001")
if not Path("/Volumes/AGNDJ 6TB").is_mount():
    raise RuntimeError("External drive is not mounted")
RUN = ROOT / "runs/analysis-v1"
OUT = ROOT / "releases/research-note-v1.2"
OUT.mkdir(parents=True, exist_ok=True)
result = json.loads((RUN / "results.json").read_text())
verification = json.loads((RUN / "verification.json").read_text())
assert verification["primary_and_sensitivity_bootstrap_replay"] == "exact"
data = pd.read_csv(RUN / "joined-variants.csv")
data = data.loc[data.primary]
r = result["primary"]
s = result["sensitivity_all_snvs"]
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "white",
        "axes.titleweight": "bold",
    }
)
BRAND = json.loads(
    (Path(__file__).resolve().parents[3] / "publications/nas_paper_v1/brand.json").read_text()
)["palette"]
colors = [BRAND["gold"], BRAND["charcoal"]]
fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2), sharey=True, layout="constrained")
for ax, column, label, key, color in zip(
    axes,
    ["avi", "CADD_score"],
    ["AVI (API raw score)", "CADD 1.7 score"],
    ["avi_spearman", "cadd_spearman"],
    colors,
    strict=True,
):
    ax.scatter(
        data[column],
        -data.function_score_mean,
        s=17,
        alpha=0.65,
        color=color,
        marker="o" if column == "avi" else "s",
        edgecolors="none",
    )
    ax.set_xlabel(label)
    ax.set_title(f"{label.split(' (')[0]}: Spearman r = {r[key]['estimate']:.3f}", loc="left")
    ax.axhline(0, color="#aaa", lw=0.6)
axes[0].set_ylabel("Experimental cell-fitness loss\n(negative SGE function score)")
fig.suptitle("RNU4-2: 435 single-nucleotide variants at 145 positions", fontsize=14)
fig.savefig(OUT / "figure-1-score-agreement.png", dpi=200)
fig.savefig(OUT / "figure-1-score-agreement.svg")
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.3), layout="constrained")
for ax, suffix, title, null, limits in zip(
    axes,
    ["spearman", "within_position"],
    ["Overall rank correlation", "Within-position allele ordering"],
    [0, 0.5],
    [(-0.1, 0.35), (0.35, 0.65)],
    strict=True,
):
    for y, prefix, color, label in zip(
        [1, 0], ["avi", "cadd"], colors, ["AVI", "CADD"], strict=True
    ):
        metric = r[prefix + "_" + suffix]
        point = metric["estimate"]
        lo, hi = metric["ci95"]
        ax.errorbar(
            point,
            y,
            xerr=[[point - lo], [hi - point]],
            fmt="o" if prefix == "avi" else "s",
            color=color,
            capsize=5,
            markersize=8,
            lw=2,
        )
        ax.text(
            limits[0] + 0.008, y + 0.18, f"{label}  {point:.3f} [{lo:.3f}, {hi:.3f}]", fontsize=10
        )
    ax.axvline(null, color="#777", ls="--", lw=1)
    ax.set(xlim=limits, ylim=(-0.5, 1.55), yticks=[], title=title)
    ax.set_xlabel(
        "Spearman correlation" if suffix == "spearman" else "Concordance (0.5 = chance expectation)"
    )
fig.suptitle("Position-cluster bootstrap: 2,000 paired resamples, 95% intervals", fontsize=13)
fig.savefig(OUT / "figure-2-performance.png", dpi=200)
fig.savefig(OUT / "figure-2-performance.svg")
plt.close(fig)


def metric(key, percent=False):
    v = r[key]
    scale = 100 if percent else 1
    digits = 1 if percent else 3
    unit = "%" if percent else ""
    return (
        f"{v['estimate'] * scale:.{digits}f}{unit} "
        f"[{v['ci95'][0] * scale:.{digits}f}, {v['ci95'][1] * scale:.{digits}f}]"
    )


title = "AlphaGenome Atlas in RNU4-2: a focused computational benchmark"
sections = [
    (
        "Summary",
        f"We compared AlphaGenome Atlas AVI scores with published saturation genome editing "
        f"measurements for 435 single-nucleotide variants across the 145-base RNU4-2 transcript. "
        f"AVI showed a weak positive rank correlation with experimental cell-fitness loss "
        f"(Spearman r = {r['avi_spearman']['estimate']:.3f}). CADD 1.7 scored "
        f"{r['cadd_spearman']['estimate']:.3f}. The paired difference interval included zero. "
        f"Within-position allele concordance was "
        f"{100 * r['avi_within_position']['estimate']:.1f}%, close to its 50% chance expectation. "
        "These results provide no clear evidence of better ranking than CADD in this assay. "
        "This focused result is consistent with a limitation already discussed by the Atlas authors [2, p.18].",
    ),
    (
        "Question",
        "Does AVI track measured variant effects in a non-protein-coding RNA, and does it "
        "distinguish alternate changes at the same position? Overall correlation can reflect differences "
        "between genomic regions. Within-position ordering asks a narrower question about allele discrimination.",
    ),
    (
        "Data and methods",
        "We used the final published Supplementary Table 1 from De Jonghe et al. (2026) [1]. "
        "Of 539 engineered edits, 453 were SNVs. The primary cohort comprised all 435 transcript SNVs; "
        "18 downstream SNVs were reserved for a prespecified sensitivity analysis and 86 other edits were excluded. "
        "Every forward-strand hg38 reference allele matched the UCSC reference sequence [4]. All 453 AVI scores "
        "were retrieved through the authenticated official Atlas client on 9 September 2026 UTC; no scores were missing. "
        "The endpoint was negative function_score_mean, representing cell-fitness loss. The comparator was "
        "CADD 1.7 from the same source table. We used the API raw AVI score, not a clinical or PHRED cutoff. "
        "Spearman correlation is invariant to strictly increasing score transformations.",
    ),
    (
        "Uncertainty and allele ordering",
        "For the within-position metric, we compared all three pairs of "
        "alternative alleles at each site. Correct ordering scored 1, reversed ordering 0, and prediction ties 0.5; "
        "pairs tied experimentally were excluded. Site averages received equal weight. We used 2,000 paired "
        "bootstrap resamples of positions, preserving each site’s alternate alleles, with seed 20260909. "
        "Intervals are percentile 95% intervals conditional on this one assay. We did not tune scores, "
        "fit a model, select a clinical threshold, or optimize the cohort against results.",
    ),
    (
        "Sensitivity analysis",
        f"Including all 453 SNVs yielded AVI r = {s['avi_spearman']['estimate']:.3f} "
        f"and CADD r = {s['cadd_spearman']['estimate']:.3f}. The paired difference was "
        f"{s['spearman_difference']['estimate']:.3f} "
        f"[{s['spearman_difference']['ci95'][0]:.3f}, {s['spearman_difference']['ci95'][1]:.3f}]. "
        "This did not materially change the interpretation. Secondary all-SNV allele-ordering estimates "
        "are retained in results.json but are not promoted as a separate confirmatory finding.",
    ),
    (
        "Interpretation and limits",
        "The correlation of 0.144 describes rank agreement; it is not 14.4% accuracy. "
        "Similarly, 49.2% is a within-site pair-ordering statistic, not clinical classification accuracy. "
        "The data suggest limited rank agreement for this RNA and experimental "
        "endpoint. The near-chance allele ordering highlights a limitation that an overall correlation alone "
        "could obscure. However, tiny differences in experimental measurements can reverse allele order; "
        "our ordering metric does not incorporate replicate-level measurement uncertainty. Nearby sites may "
        "also be dependent, beyond the clustering captured by the bootstrap. HAP1 cell fitness is not patient "
        "severity, clinical pathogenicity, or performance across all non-coding variants. Failure to establish "
        "an advantage is not proof that the methods are equivalent.",
    ),
    (
        "Relationship to previous work",
        "Google's Atlas preprint explicitly identifies RNU4-2 as an example of a training-data gap: "
        "standard poly(A)-selected RNA sequencing excludes non-polyadenylated noncoding RNAs [2, p.18]. "
        "This is a plausible context for our result, not a mechanism established by this analysis. "
        "The authors report the highest Spearman correlation in eight of ten held-out SGE screens [2, p.5]; "
        "strong aggregate performance does not imply equal performance in every gene or assay. "
        "They already evaluate RNU4-2 [2, Methods p.28]. Our work is a focused reanalysis of an existing "
        "screen, not a first benchmark or new independent experimental validation. We used the final 2026 "
        "source table and did not reproduce Google's exact filtered input snapshot. The analysis plan was "
        "internally frozen before AVI retrieval, not externally preregistered. We do not establish that "
        "Atlas is broadly inaccurate or contradict Google's aggregate performance claims.",
    ),
    (
        "Reproducibility and review",
        "Deterministic code produced all numerical results. Independent "
        "formulations reproduced the point estimates; source-value comparisons, input hashes, and exact "
        "bootstrap replay passed. Public experimental data and the free non-commercial API were used. "
        "No patient-level records or paid data services were required. NaS Research prepared this report "
        "with AI assistance. A separate computational audit checked every source field, score, "
        "coordinate, estimate, and interval. This is AI-assisted verification, not external expert "
        "review or peer review. No clinical recommendation is made. Reproduction files accompany the web edition.",
    ),
]
table = [
    ["Metric", "AVI", "CADD 1.7", "AVI minus CADD"],
    [
        "Spearman correlation",
        metric("avi_spearman"),
        metric("cadd_spearman"),
        metric("spearman_difference"),
    ],
    [
        "Within-position concordance",
        metric("avi_within_position", True),
        metric("cadd_within_position", True),
        metric("within_position_difference", True).replace("%", "") + " pp",
    ],
]
references = [
    (
        "[1] De Jonghe et al. (2026). Saturation editing of RNU4-2 reveals distinct dominant and recessive disorders. Nature.",
        "https://doi.org/10.1038/s41586-026-10334-9",
    ),
    (
        "[2] Cheng et al. (2026). AlphaGenome Atlas preprint, Discussion p.18; evaluation pp.5 and 28.",
        "https://storage.googleapis.com/deepmind-media/DeepMind.com/Blog/alphagenome-atlas-a-predictive-map-of-every-possible-dna-letter-change-in-the-human-genome/alphagenome-atlas.pdf",
    ),
    (
        "[3] Google DeepMind. AlphaGenome Atlas API reference.",
        "https://www.alphagenomedocs.com/api/atlas.html",
    ),
    (
        "[4] UCSC Genome Browser API. hg38 reference, chr12:120291752-120291903 (0-based half-open).",
        "https://api.genome.ucsc.edu/getData/sequence?genome=hg38;chrom=chr12;start=120291752;end=120291903",
    ),
    (
        "[5] AlphaGenome Output Terms of Use.",
        "https://deepmind.google.com/science/alphagenome/output-terms",
    ),
]
markdown = f"# {title}\n\nNaS Research | NAS-AGA-001 | 9 September 2026 UTC\n\nResearch note v1.2. Not peer reviewed.\n\n"
body = f'<header><p class="eyebrow">NaS Research · Computational life sciences</p><h1>{title}</h1><p>NAS-AGA-001 · 9 September 2026 UTC · Research note v1.2</p><p class="status">Not peer reviewed · AI-assisted computational review</p></header>'
for i, (heading, text) in enumerate(sections):
    markdown += f"## {heading}\n\n{text}\n\n"
    body += f"<section><h2>{heading}</h2><p>{html.escape(text)}</p></section>"
    if i == 0:
        markdown += "| " + " | ".join(table[0]) + " |\n|---|---|---|---|\n"
        markdown += (
            "".join("| " + " | ".join(row) + " |\n" for row in table[1:])
            + "\nIntervals in brackets are 95% bootstrap intervals. Difference in concordance is percentage points.\n\n"
        )
        body += (
            '<div class="table-wrap"><table>'
            + "".join(
                "<tr>"
                + "".join(
                    f"<{'th' if j == 0 else 'td'}>{html.escape(cell)}</{'th' if j == 0 else 'td'}>"
                    for cell in row
                )
                + "</tr>"
                for j, row in enumerate(table)
            )
            + '</table></div><p class="caption">95% bootstrap intervals in brackets. Concordance difference is in percentage points.</p>'
        )
    if i in (1, 3):
        filename = "figure-1-score-agreement.png" if i == 1 else "figure-2-performance.png"
        alt = (
            "Model score versus experimental cell-fitness loss"
            if i == 1
            else "Paired model performance with position-cluster bootstrap intervals"
        )
        encoded = base64.b64encode((OUT / filename).read_bytes()).decode()
        body += f'<figure><img src="data:image/png;base64,{encoded}" alt="{alt}"><figcaption>{alt}. Primary cohort: 435 SNVs.</figcaption></figure>'
        markdown += f"![{alt}]({filename})\n\n"
body += "<section><h2>References and attribution</h2><ol>"
markdown += "## References and attribution\n\n"
for label, url in references:
    body += f'<li><a href="{html.escape(url)}">{html.escape(label)}</a></li>'
    markdown += f"- [{label}]({url})\n"
body += "</ol><p>Experimental source: De Jonghe et al., CC BY 4.0, subject to source exceptions. Analysis and figures are NaS derivatives. AlphaGenome outputs must be used under the applicable Google terms; the account terms provide an AVI-score exception. No credentials are included.</p></section>"
style = """body{font:17px/1.65 system-ui,sans-serif;color:#171717;background:#f5f5f5;margin:0}main{max-width:1000px;margin:40px auto;background:white;padding:56px;border-top:6px solid #B68A4B}h1{font-size:40px;line-height:1.15;letter-spacing:-1px;max-width:900px}h2{font-size:24px;margin-top:34px}.eyebrow{color:#B68A4B;text-transform:uppercase;letter-spacing:2px;font-size:12px}.status,.caption,figcaption{color:#626262;font-size:13px}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;padding:12px;border-bottom:1px solid #E8E8E8}th{background:#F5F5F5}.table-wrap{overflow-x:auto}figure{margin:28px 0}img{width:100%;height:auto}a{color:#171717;text-decoration:underline}li{margin:10px 0} @media(max-width:650px){main{margin:0;padding:24px}h1{font-size:30px}}@media print{body{background:white}main{margin:0;padding:0;border:0}figure,table{break-inside:avoid}h2{break-after:avoid}}"""
(OUT / "research-note.md").write_text(markdown)
(OUT / "research-note.html").write_text(
    f'<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{style}</style><main>{body}</main></html>'
)
(OUT / "results.json").write_bytes((RUN / "results.json").read_bytes())
(OUT / "verification.json").write_bytes((RUN / "verification.json").read_bytes())
(
    OUT / "post-draft.md"
).write_text(f"""We tested AlphaGenome Atlas against published experimental measurements for 435 single-letter variants in RNU4-2, a non-coding RNA.

AVI showed weak overall agreement with measured cell-fitness loss (Spearman r = {r["avi_spearman"]["estimate"]:.3f}). Its advantage over CADD 1.7 was uncertain. Within the same DNA position, AVI ordered alternative changes correctly {100 * r["avi_within_position"]["estimate"]:.1f}% of the time, close to chance expectation.

Google's paper already identifies RNU4-2 as an example of a training-data limitation (Discussion p.18). This result is consistent with that acknowledged limitation; it does not contradict Google's broader results.

This is a focused reanalysis of one published screen, not a new biological discovery or clinical validation. The correlation is not an accuracy percentage, and within-site ordering is not diagnostic accuracy.

NaS Research. Not peer reviewed. https://nasresearch.bio/research/alphagenome-atlas-rnu4-2
""")
(OUT / "report-content.json").write_text(
    json.dumps(
        {"title": title, "sections": sections, "table": table, "references": references}, indent=2
    )
    + "\n"
)
manifest = {
    p.name: hashlib.sha256(p.read_bytes()).hexdigest()
    for p in OUT.iterdir()
    if p.is_file() and p.name != "release-manifest.json"
}
(OUT / "release-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(OUT)
