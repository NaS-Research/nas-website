"""Portable statistical analysis for NAS-AGA-001. Scientific functions unchanged."""
import itertools
import numpy as np
from scipy.stats import spearmanr

def correlation(scores, losses):
    return float(spearmanr(scores, losses).statistic)

def allele_concordance(scores, losses):
    values = []
    for i, j in itertools.combinations(range(len(scores)), 2):
        observed = np.sign(losses[i] - losses[j])
        predicted = np.sign(scores[i] - scores[j])
        if observed:
            values.append(0.5 if predicted == 0 else float(observed == predicted))
    return float(np.mean(values)) if values else float("nan")

def evaluate(frame, bootstrap=2000):
    loss = -frame.function_score_mean.to_numpy()
    avi = frame.avi.to_numpy()
    cadd = frame.CADD_score.to_numpy()
    groups = [
        np.flatnonzero(frame.position.to_numpy() == p) for p in sorted(frame.position.unique())
    ]
    per_site = np.array(
        [
            [allele_concordance(avi[g], loss[g]), allele_concordance(cadd[g], loss[g])]
            for g in groups
        ]
    )
    if not np.isfinite(per_site).all():
        raise ValueError("Site with no experimentally ordered pairs")
    point = [
        correlation(avi, loss),
        correlation(cadd, loss),
        float(per_site[:, 0].mean()),
        float(per_site[:, 1].mean()),
    ]
    rng = np.random.default_rng(20260909)
    samples = []
    for _ in range(bootstrap):
        selected = rng.integers(0, len(groups), len(groups))
        indices = np.concatenate([groups[i] for i in selected])
        samples.append(
            [
                correlation(avi[indices], loss[indices]),
                correlation(cadd[indices], loss[indices]),
                per_site[selected, 0].mean(),
                per_site[selected, 1].mean(),
            ]
        )
    samples = np.asarray(samples)
    if not np.isfinite(samples).all():
        raise ValueError("Nonfinite bootstrap estimate")
    result = {
        "n": len(frame),
        "positions": len(groups),
        "bootstrap_replicates": bootstrap,
        "seed": 20260909,
    }
    for index, name in enumerate(
        ["avi_spearman", "cadd_spearman", "avi_within_position", "cadd_within_position"]
    ):
        result[name] = {
            "estimate": point[index],
            "ci95": np.quantile(samples[:, index], [0.025, 0.975]).tolist(),
        }
    for name, left, right in [("spearman_difference", 0, 1), ("within_position_difference", 2, 3)]:
        result[name] = {
            "estimate": point[left] - point[right],
            "ci95": np.quantile(samples[:, left] - samples[:, right], [0.025, 0.975]).tolist(),
        }
    return result
