# NAS-AGA-001: public data and analysis

Data package 1.2.1 accompanies research note 1.2. The data, statistical functions,
results and paper are unchanged. This revision provides a portable research-only package.

## Run
Use Python 3.12 in a virtual environment:

    python -m venv .venv
    source .venv/bin/activate
    python -m pip install -r requirements-replay.txt
    python replay.py

On Windows use `.venv\Scripts\activate` to activate the environment.
After dependencies are installed, replay needs no API key or network connection.
Success prints: PASS: both complete analyses and all bootstrap intervals reproduce exactly.

## Contents
- joined-variants.csv: 453 matched variants; `primary` identifies the 435 transcript SNVs.
- results.json: primary and sensitivity estimates and bootstrap intervals.
- analysis.py: the three unchanged statistical functions used in the published analysis.
- replay.py and requirements-replay.txt: portable numerical reproduction.
- methods.md: scientific methods and data dictionary.
- exploratory-disagreements.csv: ten largest rank disagreements, exploratory only.
- verification.json: summary of the original computational verification.
- manifest.json: file hashes for this package.

This replay verifies numerical reproducibility, not independent experimental validity.
The original source workbook and acquisition snapshots are not included; verification.json
records the original source-field checks. No clinical recommendation is made.

## Attribution and terms
Experimental source: De Jonghe et al. (2026), Saturation editing of RNU4-2 reveals
 distinct dominant and recessive disorders. Nature. Supplementary Table 1.
https://doi.org/10.1038/s41586-026-10334-9
The source article is CC BY 4.0, subject to the publisher's stated exceptions.
Experimental measurements and source-provided CADD 1.7 scores retain that attribution.
Google DeepMind AlphaGenome Atlas AVI predictions retain the applicable output terms:
https://deepmind.google.com/science/alphagenome/output-terms
Their inclusion does not grant broader rights to Google resources.

Research note and citation:
Dalron J. Robertson (2026). AlphaGenome Atlas in RNU4-2: a focused computational
benchmark. NaS Research. Version 1.2.
https://nasresearch.bio/research/alphagenome-atlas-rnu4-2
