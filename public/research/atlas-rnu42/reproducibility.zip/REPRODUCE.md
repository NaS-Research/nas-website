# Reproduce NAS-AGA-001

Install requirements-replay.txt in a Python environment and run `python replay.py`.
This replays both complete statistical analyses, including all 2,000 bootstrap samples,
from the 453 frozen matched variants. No API key or network connection is needed
for replay after package installation. Original acquisition/verification scripts are
included unchanged for provenance; their external-drive paths are specific to the
original environment. The portable replay does not invoke their acquisition paths.

Source: De Jonghe et al., Nature (2026), DOI 10.1038/s41586-026-10334-9,
Supplementary Table 1 (CC BY 4.0, subject to the publisher's stated exceptions).
The selected experimental measurements and supplied CADD scores retain this attribution.
AVI predictions were retrieved using Google DeepMind AlphaGenome Atlas under its
noncommercial terms. Inclusion here does not grant broader rights to Google resources;
consult https://alphagenome.google/atlas for applicable terms. No credentials are included.
See the report and source review for dataset overlap and interpretation limitations.

The preparation receipt records source hashes; the original workbook, reference sequence,
and API batches remain in the external study snapshots directory. Independent source-field
verification is recorded in verification.json. The portable replay checks numerical
reproducibility, not experimental validity or independent scientific review.


## Publication format v1.1
The unchanged statistical analysis is presented through the shared NaS renderer in
workflows/publications/nas_paper_v1. Source builders retain the external-drive output
location. Run build_report.py with matplotlib/pandas and build_pdf.py with reportlab
in the original workspace layout to regenerate the paper. The original NaS logo is
retained as a branding asset; it is not licensed as experimental data. Arial is
embedded from the system when available; otherwise Helvetica is used. Fonts are
not redistributed. The package's replay.py only requires requirements-replay.txt.


## Public edition 1.2
The numerical data and frozen analysis are unchanged. The added publication-audit.json
records a separate implementation of the estimates and all paired bootstrap intervals,
matching within 1e-14. publication_audit.py requires the original source snapshots in
the external study directory; replay.py remains the portable, offline numerical replay.
Review is AI-assisted computational verification, not external expert review or peer review.
Canonical report: https://nasresearch.bio/research/alphagenome-atlas-rnu4-2
