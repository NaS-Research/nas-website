from pathlib import Path
import json, runpy
import pandas as pd
root = Path(__file__).resolve().parent
module = runpy.run_path(str(root / "workflows/studies/atlas_rnu42_benchmark/analysis/benchmark.py"))
frame = pd.read_csv(root / "joined-variants.csv")
expected = json.loads((root / "results.json").read_text())
for name, data in [("primary", frame.loc[frame.primary]), ("sensitivity_all_snvs", frame)]:
    assert module["evaluate"](data) == expected[name], name
print("PASS: both complete analyses and all bootstrap intervals reproduce exactly")
