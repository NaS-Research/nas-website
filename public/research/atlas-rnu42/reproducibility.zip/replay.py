from pathlib import Path
import json
import pandas as pd
from analysis import evaluate
root = Path(__file__).resolve().parent
frame = pd.read_csv(root / "joined-variants.csv")
expected = json.loads((root / "results.json").read_text())
for name, data in [("primary", frame.loc[frame.primary]), ("sensitivity_all_snvs", frame)]:
    if evaluate(data) != expected[name]:
        raise RuntimeError(f"Results do not match: {name}")
print("PASS: both complete analyses and all bootstrap intervals reproduce exactly")
