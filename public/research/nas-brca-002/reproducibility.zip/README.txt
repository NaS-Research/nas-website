NAS-BRCA-002 public-report reproducibility package
Status: internally reviewed with AI assistance; not peer reviewed.
Public posting begins open post-publication review. Not for clinical use.
Raw molecular data, outcomes, identifiers, controlled data, and credentials are excluded.
