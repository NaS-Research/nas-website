"""Shared NaS print layout; content and output locations belong to each study."""

import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

HERE = Path(__file__).resolve().parent
BRAND = json.loads((HERE / "brand.json").read_text())


def render(document, output_path, asset_root):
    palette = {key: HexColor(value) for key, value in BRAND["palette"].items()}
    font_dir = Path("/System/Library/Fonts/Supplemental")
    regular, bold = "Helvetica", "Helvetica-Bold"
    if (font_dir / "Arial.ttf").exists() and (font_dir / "Arial Bold.ttf").exists():
        regular, bold = "NaSArial", "NaSArialBold"
        pdfmetrics.registerFont(TTFont(regular, str(font_dir / "Arial.ttf")))
        pdfmetrics.registerFont(TTFont(bold, str(font_dir / "Arial Bold.ttf")))
    styles = {}
    for name, font, size, leading, color, before, after in [
        ("body", regular, 10.8, 14.5, "charcoal", 0, 9),
        ("title", bold, 30, 35, "black", 0, 18),
        ("page", bold, 22, 27, "black", 0, 15),
        ("head", bold, 13, 17, "black", 9, 6),
        ("small", regular, 8.5, 11.5, "gray", 0, 7),
        ("label", bold, 9, 12, "gold", 0, 10),
        ("subtitle", regular, 14, 19, "gray", 0, 20),
        ("cell", regular, 8.3, 11.2, "charcoal", 0, 0),
        ("cellhead", bold, 8.3, 11.2, "white", 0, 0),
    ]:
        styles[name] = ParagraphStyle(
            name,
            fontName=font,
            fontSize=size,
            leading=leading,
            textColor=palette[color],
            spaceBefore=before,
            spaceAfter=after,
            keepWithNext=name in {"head", "page", "label"},
        )

    def para(text, style="body"):
        return Paragraph(escape(text).replace("–", "-").replace("’", "'"), styles[style])

    margin = BRAND["page"]["margin"]
    width = BRAND["page"]["width"] - margin * 2

    def furniture(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(palette["gray"])
        canvas.setFont(regular, 8)
        canvas.drawString(margin, 759, f"NaS Research  |  {document['study_id']}")
        canvas.setStrokeColor(palette["line"])
        canvas.line(margin, 42, 612 - margin, 42)
        canvas.drawString(margin, 28, f"{document['version']}  |  {document['review_state']}")
        canvas.drawRightString(612 - margin, 28, str(doc.page))
        canvas.restoreState()

    story = [Spacer(1, 22)]
    logo = Image(str(HERE / "nas-logo.png"), width=57.6, height=57.6)
    logo.hAlign = "LEFT"
    story.extend(
        [
            logo,
            Spacer(1, 26),
            para(document["series"].upper(), "label"),
            para(document["title"], "title"),
            para(document["subtitle"], "subtitle"),
            para(document["abstract"]),
            Spacer(1, 15),
            para("DATE  /  VERSION  /  AUTHOR", "small"),
            para(f"{document['date']}  /  {document['version']}  /  {document['author']}", "small"),
            Spacer(1, 10),
            para(document["review_state"].upper(), "label"),
            para(document["cover_note"], "small"),
        ]
    )
    for blocks in document["pages"]:
        story.append(PageBreak())
        for index, block in enumerate(blocks):
            kind = block["type"]
            if kind == "heading":
                story.append(para(block["text"], "page" if index == 0 else "head"))
            elif kind == "paragraph":
                story.append(para(block["text"], block.get("style", "body")))
            elif kind == "figure":
                img = Image(str(Path(asset_root) / block["path"]))
                img.drawHeight = width * img.imageHeight / img.imageWidth
                img.drawWidth = width
                story.append(KeepTogether([img, para(block["caption"], "small")]))
                story.append(Spacer(1, 8))
            elif kind == "table":
                rows = [
                    [para(value, "cellhead" if i == 0 else "cell") for value in row]
                    for i, row in enumerate(block["rows"])
                ]
                table = Table(rows, colWidths=[width / len(rows[0])] * len(rows[0]), repeatRows=1)
                table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), palette["black"]),
                            ("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("LINEBELOW", (0, 0), (-1, -1), 0.5, palette["line"]),
                            ("TOPPADDING", (0, 0), (-1, -1), 8),
                            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                            ("LEFTPADDING", (0, 0), (-1, -1), 7),
                            ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                        ]
                    )
                )
                story.extend([table, Spacer(1, 7)])
            elif kind == "references":
                for label, url in block["items"]:
                    story.append(
                        Paragraph(
                            f'<link href="{escape(url)}" color="#171717">{escape(label)}</link>',
                            styles["small"],
                        )
                    )
            else:
                raise ValueError(f"Unknown publication block: {kind}")
    SimpleDocTemplate(
        str(output_path),
        pagesize=(612, 792),
        leftMargin=margin,
        rightMargin=margin,
        topMargin=56,
        bottomMargin=56,
        title=document["title"],
        author=document["author"],
    ).build(story, onFirstPage=furniture, onLaterPages=furniture)
