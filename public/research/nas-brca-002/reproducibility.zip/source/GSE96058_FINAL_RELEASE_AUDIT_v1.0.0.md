# NAS-BRCA-002 final release audit v1.0.0

Date: 2026-09-11

Study: `NAS-BRCA-002`

Candidate audited: review paper `0.5.1`

Candidate PDF SHA-256:
`6aebc1f25f61a75c6f2aec61b5e6c53d07b5c0e9a4e4070a459b54429dfc490a`

Audit status: passed for a versioned open public release with the release-state
wording corrections listed below

Review provenance: AI-assisted internal release audit directed by the founder. This
is not independent scientific review, journal peer review, or clinical review.

## Scientific and numerical checks

- The GSE96058 primary result is 131 matching labels among all 136 registered
  technical-repeat pairs: 96.32%, with a two-sided 95% Wilson interval of
  91.68%-98.42%.
- The prespecified HR-positive/HER2-negative secondary result is 83/87: 95.40%,
  with a 95% Wilson interval of 88.77%-98.20%.
- The post-result-preregistered TCGA-BRCA external check is 5/5: 100%, with a
  95% Wilson interval of 56.55%-100%.
- The preregistered E-TABM-576 primary cross-platform sensitivity result is 13/16:
  81.25%, with a 95% Wilson interval of 56.99%-93.41%.
- The E-TABM-576 secondary dependent comparison is reported separately as 31/39:
  79.49%, with a 95% Wilson interval of 64.47%-89.22%.
- Cohorts are not pooled, no between-source difference test is claimed, and no
  reliability cutoff is selected after observing the results.
- The TCGA numerical-boundary incident and the accepted frozen tolerance are
  disclosed. The rejected provisional output is not presented as evidence.

## Method and provenance checks

- GSE96058 and TCGA-BRCA use the frozen 50-gene panel, immutable GSE81538
  reference, five fixed PAM50 centroids, Spearman scoring, and no cohort centering.
- E-TABM-576 is correctly separated as a cross-platform sensitivity analysis using
  the preregistered 59-reporter collapse and singleton-profile centering contract.
- The project uses public processed expression data and necessary public metadata.
  It includes no physical specimens, controlled records, clinical outcomes, or
  patient-facing execution.
- Dataset identifiers and source links were checked against NCBI GEO, NCI GDC,
  EMBL-EBI BioStudies, and the cited PubMed records.
- The reproducibility bundle excludes raw molecular data, identifiers, credentials,
  outcomes, and controlled data while preserving builders, evidence receipts,
  checksums, and source-bound review records.

## Claim-boundary checks

The report supports only a narrow, source-bound technical-repeatability conclusion.
It does not establish biological truth, diagnostic accuracy, prognostic or predictive
validity, treatment benefit, clinical utility, a population agreement rate, causal
platform effects, or general transportability. It is not clinical guidance.

## Page and presentation checks

All seven US Letter pages of the exact candidate were rendered at 144 DPI and
inspected. No clipped text, overlap, unreadable table, broken figure, missing page
number, or palette violation was found. The shared NaS white, gold, black, charcoal,
and gray publication system is applied consistently.

## Required release-state correction

The scientific content and numerical results do not require revision. The public
edition must replace candidate-only statements such as `final review pending` and
`not authorized for publication` with these accurate labels:

- public computational research report;
- internally reviewed with AI assistance;
- not independently reviewed or peer reviewed;
- not for clinical use;
- public posting begins open post-publication review.

The preserved `0.5.1` candidate must not be overwritten. The public edition is a new
versioned artifact, `public-report-v1.0.0`, with unchanged analyses and conclusions.

## Decision

Pass, conditional only on the mechanical release-state corrections above and final
verification of the newly rendered public PDF, website page, downloads, hashes, and
live route. Any substantive scientific change requires a new audit.
