# NAS-BRCA-002 exact-candidate adversarial audit v1.0.0

Date: 2026-09-11

Candidate: review paper `0.5.0`

Exact PDF SHA-256:
`b6a92c3124d6b800fbd74b60c8c61ab7b5a7c417db8525d26ab2f991492a0f03`

Review type: AI-assisted internal adversarial audit; not independent scientific
review, human review, or journal peer review

## Decision

Revision is required before consolidated human review. The audit found no numerical
result error, denominator change, unauthorized analysis, clinical claim, or visual
layout defect. It found one substantive method-summary error and two presentation or
provenance defects. Review paper `0.5.0` and its artifact remain preserved as the
audited prior candidate.

## Finding A-001 - source-specific reference methods were conflated

Severity: substantive method-description defect

Location: PDF page 2, `Frozen method`

The candidate says every profile used the immutable GSE81538 reference and that no
cohort centering was allowed. That is correct for GSE96058 and the unchanged-method
TCGA-BRCA check, but it is not correct for E-TABM-576. The preregistered cross-platform
sensitivity collapsed 59 reporters to 50 genes and centered each gene against the
median of 112 registered E-TABM-576 singleton profiles before applying the same five
fixed centroids by Spearman correlation.

Required correction: state the GSE81538 path and E-TABM-576 singleton-reference path
separately. Preserve that E-TABM-576 is a source-specific cross-platform adaptation,
not unchanged-method validation.

Evidence:

- `gse96058_etabm576_projection_kernel_contract_v1.0.0.yaml`, SHA-256
  `6f82e9ee9d6dcbe0aeec0b0db2fe1cf2faf3cf51bb2e498d1a3e7a85f2f4f903`
- `QUESTION_V0_4_WORKING_MANUSCRIPT_v0.5.0.md`, SHA-256
  `0e49d6bb6153d628dd87135c92b32256ad61deb2111d29207dbdcb22e6d2efd7`

## Finding A-002 - abstract opening excluded the microarray source

Severity: editorial scope defect

Location: PDF page 1, abstract opening

The opening sentence describes only public RNA-sequencing records, while the same
abstract and subtitle include the E-TABM-576 microarray sensitivity analysis.

Required correction: describe the inputs as public tumor-expression records, then
retain the source-specific RNA-seq and microarray labels elsewhere.

## Finding A-003 - bundled search refresh was not the latest checked-in refresh

Severity: provenance currency defect

Location: PDF page 7 and reproducibility package

The paper says the package contains the current search refresh, but the `0.5.0`
builder bundled search refresh `1.2.0`. The latest checked-in refresh before this audit
is `1.5.0`, dated 2026-09-10. It still reports zero newly eligible larger candidates,
does not claim search completeness, and does not change any study result.

Required correction: bundle and validate refresh `1.5.0`, leaving earlier refreshes
preserved.

Evidence:

- Bundled refresh `1.2.0`, SHA-256
  `23dae4f7c948ec00e912ee659cfe15672bf31a824915cbcefac172ca45f69269`
- Current refresh `1.5.0`, SHA-256
  `ca3fa8fc415290317f10225d264959514e46b442d8604d6ba06d66ec914140cd`

## Checks that passed

- GSE96058 primary: 131/136, 96.32%, 95% Wilson interval 91.68%-98.42%.
- GSE96058 secondary: 83/87, 95.40%, 95% Wilson interval 88.77%-98.20%.
- TCGA-BRCA: 5/5, 100%, 95% Wilson interval 56.55%-100%.
- E-TABM-576 primary: 13/16, 81.25%, 95% Wilson interval 56.99%-93.41%.
- E-TABM-576 secondary: 31/39, 79.49%, 95% Wilson interval 64.47%-89.22%,
  explicitly dependent.
- The sources were not pooled and no difference test was reported.
- The five GSE96058 primary discordances and four secondary discordances were
  represented correctly in the score-margin figure.
- The rejected TCGA numerical attempt and the frozen `1e-12` correction boundary were
  disclosed.
- No threshold, outcome, receptor, controlled-data, biological-truth, population-rate,
  or clinical-validity claim was introduced.
- The exact seven-page PDF remained readable, internally labeled, and visually intact.

## Repair boundary

Prepare a version-preserving `0.5.1` paper candidate that changes only the three items
above. Do not alter any analysis result, confidence interval, figure value, source
role, preregistration, or authority boundary. Build and verify it as a new external
artifact; do not overwrite `0.5.0`.
