"""Build NAS-BRCA-002 public report v1.0.0 and its evidence package."""

from __future__ import annotations

import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Any, cast

from PIL import Image, ImageDraw, ImageFont
from reportlab import rl_config  # type: ignore[import-untyped]

from nas_core.serialization import strict_yaml_load

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
REPOSITORY_ROOT = HERE.parents[3]
TEMPLATE = REPOSITORY_ROOT / "workflows/publications/nas_paper_v1"
DEFAULT_OUTPUT = Path(
    "/Volumes/AGNDJ 6TB/NaS-Core-Data/studies/NAS-BRCA-002/releases/public-report-v1.0.0"
)
MANUSCRIPT = STUDY / "manuscript/QUESTION_V0_4_WORKING_MANUSCRIPT_v0.5.0.md"
MANUSCRIPT_RECEIPT = STUDY / "manuscript/QUESTION_V0_4_WORKING_MANUSCRIPT_RECEIPT_v0.5.0.yaml"
PRIMARY_RECEIPT = STUDY / "reviews/gse96058_full_analysis_receipt_v1.0.0.yaml"
EXTERNAL_RECEIPT = (
    STUDY / "reviews/gse96058_tcga_brca_external_validation_analysis_receipt_v1.0.0.yaml"
)
INTERPRETATION = (
    STUDY / "reviews/gse96058_tcga_brca_external_validation_interpretation_packet_v1.0.0.yaml"
)
INTERPRETATION_DECISION = (
    STUDY / "reviews/GSE96058_TCGA_BRCA_EXTERNAL_VALIDATION_INTERPRETATION_DECISION_v1.0.0.yaml"
)
SENSITIVITY_RECEIPT = (
    STUDY / "reviews/gse96058_etabm576_empirical_analysis_receipt_v1.0.0.yaml"
)
SENSITIVITY_DECISION = (
    STUDY
    / "reviews/GSE96058_ETABM576_INTERPRETATION_STANDING_AUTHORIZATION_DECISION_v1.0.0.yaml"
)
REVIEW_PACKET = (
    STUDY / "reviews/GSE96058_ETABM576_SCIENTIFIC_REVIEW_PACKET_v1.2.0.md"
)
NUMERICAL_INCIDENT = STUDY / "reviews/gse96058_tcga_brca_numerical_boundary_incident_v1.0.0.yaml"
SEARCH_REFRESH = STUDY / "protocol/gse96058_external_validation_search_refresh_v1.5.0.yaml"
ADVERSARIAL_AUDIT = (
    STUDY / "reviews/GSE96058_ETABM576_EXACT_CANDIDATE_ADVERSARIAL_AUDIT_v1.0.0.md"
)
FINAL_RELEASE_AUDIT = STUDY / "reviews/GSE96058_FINAL_RELEASE_AUDIT_v1.0.0.md"
PUBLIC_RELEASE_AUTHORIZATION = (
    STUDY / "reviews/GSE96058_PUBLIC_RELEASE_AUTHORIZATION_v1.0.0.yaml"
)


def _load_mapping(path: Path) -> dict[str, Any]:
    value = strict_yaml_load(path.read_bytes())
    if not isinstance(value, dict):
        raise ValueError(f"expected a mapping: {path}")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _font(size: int, *, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    name = "Arial Bold.ttf" if bold else "Arial.ttf"
    path = Path("/System/Library/Fonts/Supplemental") / name
    if path.exists():
        return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def _palette() -> dict[str, str]:
    value = json.loads((TEMPLATE / "brand.json").read_text(encoding="utf-8"))
    return cast(dict[str, str], value["palette"])


def _agreement_rows(
    primary: dict[str, Any],
    external: dict[str, Any],
    sensitivity: dict[str, Any],
) -> list[tuple[str, int, int, float, float, float]]:
    rows = []
    for label, report in (
        ("GSE96058 primary", primary["primary"]),
        ("GSE96058 HR+/HER2-", primary["secondary"]),
        ("TCGA-BRCA external", external["report"]),
    ):
        agreement = report["attempted_pair_agreement"]
        rows.append(
            (
                label,
                int(agreement["numerator"]),
                int(agreement["denominator"]),
                float(agreement["proportion"]),
                float(agreement["wilson_95_lower"]),
                float(agreement["wilson_95_upper"]),
            )
        )
    report = sensitivity["primary"]
    rows.append(
        (
            "E-TABM-576 sensitivity",
            int(report["concordant_pair_count"]),
            int(report["attempted_pair_count"]),
            float(report["agreement_proportion"]),
            float(report["wilson_95_lower"]),
            float(report["wilson_95_upper"]),
        )
    )
    return rows


def build_agreement_figure(
    rows: list[tuple[str, int, int, float, float, float]], output_path: Path
) -> None:
    palette = _palette()
    image = Image.new("RGB", (1600, 900), palette["white"])
    draw = ImageDraw.Draw(image)
    draw.text(
        (110, 70),
        "Separate repeat-agreement estimates",
        fill=palette["black"],
        font=_font(48, bold=True),
    )
    draw.text(
        (110, 135),
        "Point estimates and two-sided 95% Wilson intervals; cohorts are not pooled",
        fill=palette["gray"],
        font=_font(25),
    )
    left, right, axis_y = 470, 1470, 735
    draw.line((left, axis_y, right, axis_y), fill=palette["line"], width=4)
    for value in (0.50, 0.60, 0.70, 0.80, 0.90, 1.00):
        x = int(left + (value - 0.50) / 0.50 * (right - left))
        draw.line((x, axis_y - 12, x, axis_y + 12), fill=palette["gray"], width=3)
        draw.text((x - 26, axis_y + 24), f"{value:.0%}", fill=palette["gray"], font=_font(22))
    colors = [palette["black"], palette["gray"], palette["gold"], palette["charcoal"]]
    markers = ["circle", "square", "triangle", "diamond"]
    for index, (label, numerator, denominator, point, lower, upper) in enumerate(rows):
        y = 245 + index * 120
        x1 = int(left + (lower - 0.50) / 0.50 * (right - left))
        x2 = int(left + (upper - 0.50) / 0.50 * (right - left))
        xp = int(left + (point - 0.50) / 0.50 * (right - left))
        draw.text((110, y - 22), label, fill=palette["charcoal"], font=_font(28, bold=True))
        draw.line((x1, y, x2, y), fill=colors[index], width=12)
        draw.line((x1, y - 18, x1, y + 18), fill=colors[index], width=5)
        draw.line((x2, y - 18, x2, y + 18), fill=colors[index], width=5)
        if markers[index] == "circle":
            draw.ellipse((xp - 17, y - 17, xp + 17, y + 17), fill=colors[index])
        elif markers[index] == "square":
            draw.rectangle((xp - 16, y - 16, xp + 16, y + 16), fill=colors[index])
        elif markers[index] == "triangle":
            draw.polygon(((xp, y - 20), (xp - 20, y + 18), (xp + 20, y + 18)), fill=colors[index])
        else:
            draw.polygon(
                ((xp, y - 20), (xp - 20, y), (xp, y + 20), (xp + 20, y)),
                fill=colors[index],
            )
        draw.text(
            (left, y + 33),
            f"{numerator}/{denominator} ({point:.2%}); 95% CI {lower:.2%}-{upper:.2%}",
            fill=palette["charcoal"],
            font=_font(23),
        )
    draw.text(
        (110, 830),
        (
            "NAS-BRCA-002 | Descriptive technical-repeat analysis | "
            "No population-rate or clinical claim"
        ),
        fill=palette["gray"],
        font=_font(21),
    )
    image.save(output_path, format="PNG", optimize=False)


def build_margin_figure(primary: dict[str, Any], output_path: Path) -> None:
    palette = _palette()
    values = [
        (
            "Primary matching",
            131,
            float(
                primary["primary"]["concordant_margin_summary"]["valid_pair_minimum_margin"][
                    "median"
                ]
            ),
            palette["gold"],
        ),
        (
            "Primary nonmatching",
            5,
            float(
                primary["primary"]["discordant_margin_summary"]["valid_pair_minimum_margin"][
                    "median"
                ]
            ),
            palette["charcoal"],
        ),
        (
            "Secondary matching",
            83,
            float(
                primary["secondary"]["concordant_margin_summary"]["valid_pair_minimum_margin"][
                    "median"
                ]
            ),
            palette["gold"],
        ),
        (
            "Secondary nonmatching",
            4,
            float(
                primary["secondary"]["discordant_margin_summary"]["valid_pair_minimum_margin"][
                    "median"
                ]
            ),
            palette["charcoal"],
        ),
    ]
    image = Image.new("RGB", (1600, 900), palette["white"])
    draw = ImageDraw.Draw(image)
    draw.text(
        (110, 70),
        "Median smaller subtype-score margin",
        fill=palette["black"],
        font=_font(48, bold=True),
    )
    draw.text(
        (110, 135),
        "Descriptive summaries only; sparse nonmatching groups do not define a threshold",
        fill=palette["gray"],
        font=_font(25),
    )
    left, right, base_y = 530, 1470, 700
    draw.line((left, base_y, right, base_y), fill=palette["line"], width=4)
    for value in (0.0, 0.1, 0.2, 0.3):
        x = int(left + value / 0.30 * (right - left))
        draw.line((x, base_y - 12, x, base_y + 12), fill=palette["gray"], width=3)
        draw.text((x - 20, base_y + 24), f"{value:.1f}", fill=palette["gray"], font=_font(22))
    for index, (label, count, value, color) in enumerate(values):
        y = 270 + index * 105
        x = int(left + value / 0.30 * (right - left))
        draw.text(
            (110, y - 16),
            f"{label}, n={count}",
            fill=palette["charcoal"],
            font=_font(27, bold=True),
        )
        draw.line((left, y, x, y), fill=color, width=28)
        if "nonmatching" in label:
            for hatch_x in range(left + 12, x, 28):
                draw.line((hatch_x, y - 14, hatch_x + 18, y + 14), fill=palette["white"], width=4)
        draw.text(
            (x + 18, y - 16), f"{value:.4f}", fill=palette["charcoal"], font=_font(25, bold=True)
        )
    draw.text(
        (110, 830),
        "Margin = winning minus runner-up Spearman score | TCGA had no nonmatching pair",
        fill=palette["gray"],
        font=_font(21),
    )
    image.save(output_path, format="PNG", optimize=False)


def build_document(
    primary: dict[str, Any],
    external: dict[str, Any],
    sensitivity: dict[str, Any],
) -> dict[str, Any]:
    rows = _agreement_rows(primary, external, sensitivity)
    return {
        "title": "Technical-repeat sensitivity of fixed-reference PAM50 subtyping",
        "subtitle": "A public-data computational study across RNA-seq and microarray data",
        "series": "Computational cancer research / Public report",
        "study_id": "NAS-BRCA-002",
        "version": "Public report v1.0.0",
        "date": "11 September 2026",
        "author": "Dalron J. Robertson / NaS Research",
        "review_state": "Internally reviewed with AI assistance / Not peer reviewed",
        "abstract": (
            "We tested whether a frozen fixed-reference PAM50 method returned the same "
            "subtype label for public tumor-expression records linked to the same reported "
            "breast-tumor RNA source. In GSE96058, labels agreed for 131 of 136 pairs "
            "(96.32%; 95% Wilson interval 91.68%-98.42%) and for 83 of 87 pairs in the "
            "prespecified HR-positive/HER2-negative subgroup (95.40%; 88.77%-98.20%). "
            "A disclosed post-result TCGA-BRCA check retained labels in all five registered "
            "pairs (100%; 56.55%-100%). In the preregistered E-TABM-576 cross-platform "
            "sensitivity, 13 of 16 primary pairs retained labels (81.25%; "
            "56.99%-93.41%). The sources were not pooled or tested for a difference. "
            "Results support source-bound repeatability evidence, not biological truth, "
            "a population agreement rate, or clinical validity."
        ),
        "cover_note": (
            "Fully computational and public-data-only. No specimens, outcomes, controlled "
            "records, clinical threshold, or patient-facing use. Public posting begins open "
            "post-publication review. This report is not independently reviewed, peer "
            "reviewed, or intended for clinical use."
        ),
        "pages": [
            [
                {"type": "heading", "text": "Question and design"},
                {
                    "type": "paragraph",
                    "text": (
                        "When two public RNA measurements come from the same reported "
                        "breast-cancer RNA source, does one frozen PAM50 computer method give "
                        "them the same subtype label? The study measures repeatability, not "
                        "whether either label is biologically correct."
                    ),
                },
                {
                    "type": "table",
                    "rows": [
                        ["Analysis", "Attempted pairs", "Role", "Timing"],
                        ["GSE96058 primary", "136", "Primary", "Preregistered"],
                        ["GSE96058 HR+/HER2-", "87", "Secondary", "Prespecified"],
                        ["TCGA-BRCA", "5", "External check", "Post-result preregistered"],
                        ["E-TABM-576", "16", "Cross-platform sensitivity", "Preregistered"],
                    ],
                },
                {"type": "heading", "text": "Frozen method"},
                {
                    "type": "paragraph",
                    "text": (
                        "GSE96058 and TCGA-BRCA profiles used the fixed 50-gene panel, "
                        "immutable GSE81538 reference, five fixed PAM50 centroids, and "
                        "Spearman correlation, with no cohort centering. E-TABM-576 used "
                        "the preregistered 59-reporter collapse and gene-wise centering "
                        "against 112 singleton profiles before the same fixed-centroid "
                        "correlation. Every linked pair remained in its attempted "
                        "denominator. No imputation, outcome-guided adaptation, or "
                        "post-result reliability threshold was allowed. Complete executions "
                        "had to be byte-identical."
                    ),
                },
                {"type": "heading", "text": "Data boundary"},
                {
                    "type": "paragraph",
                    "text": (
                        "Only public processed expression and necessary public metadata were "
                        "used. NaS handled no physical specimen and accessed no clinical "
                        "outcome or controlled record."
                    ),
                },
            ],
            [
                {"type": "heading", "text": "Repeat-agreement results"},
                {
                    "type": "table",
                    "rows": [
                        ["Cohort", "Matching / attempted", "Agreement", "95% Wilson interval"],
                        [
                            rows[0][0],
                            f"{rows[0][1]}/{rows[0][2]}",
                            f"{rows[0][3]:.2%}",
                            f"{rows[0][4]:.2%}-{rows[0][5]:.2%}",
                        ],
                        [
                            rows[1][0],
                            f"{rows[1][1]}/{rows[1][2]}",
                            f"{rows[1][3]:.2%}",
                            f"{rows[1][4]:.2%}-{rows[1][5]:.2%}",
                        ],
                        [
                            rows[2][0],
                            f"{rows[2][1]}/{rows[2][2]}",
                            f"{rows[2][3]:.2%}",
                            f"{rows[2][4]:.2%}-{rows[2][5]:.2%}",
                        ],
                        [
                            rows[3][0],
                            f"{rows[3][1]}/{rows[3][2]}",
                            f"{rows[3][3]:.2%}",
                            f"{rows[3][4]:.2%}-{rows[3][5]:.2%}",
                        ],
                    ],
                },
                {
                    "type": "figure",
                    "path": "figure-1-agreement.png",
                    "caption": (
                        "Figure 1. Separate attempted-pair agreement estimates and two-sided "
                        "95% Wilson intervals. The five-pair TCGA and 16-pair E-TABM-576 "
                        "estimates are imprecise. Cohorts were not pooled or tested for a "
                        "difference."
                    ),
                },
            ],
            [
                {"type": "heading", "text": "Cross-platform sensitivity"},
                {
                    "type": "paragraph",
                    "text": (
                        "All 16 registered E-TABM-576 primary pairs were valid. Thirteen "
                        "retained their PAM50 labels and three did not, for 81.25% agreement "
                        "with a 56.99%-93.41% Wilson interval. The median within-pair "
                        "centered-profile Spearman correlation was 0.619."
                    ),
                },
                {
                    "type": "table",
                    "rows": [
                        [
                            "E-TABM-576 view",
                            "Matching / attempted",
                            "Agreement",
                            "95% Wilson interval",
                        ],
                        ["Primary independent-source pairs", "13/16", "81.25%", "56.99%-93.41%"],
                        ["Secondary dependent comparisons", "31/39", "79.49%", "64.47%-89.22%"],
                    ],
                },
                {"type": "heading", "text": "Interpretation boundary"},
                {
                    "type": "paragraph",
                    "text": (
                        "The microarray sensitivity point estimate is numerically lower than "
                        "the GSE96058 estimate, but no between-source test was planned or "
                        "performed. Platform, processing, reference, cohort, preservation, "
                        "and other differences remain entangled. The result does not establish "
                        "a statistical difference or its cause."
                    ),
                },
                {
                    "type": "paragraph",
                    "style": "small",
                    "text": (
                        "The 39 secondary comparisons reuse profiles and are not independent. "
                        "Participant-level nonoverlap with GSE96058 was not identifier-verified."
                    ),
                },
            ],
            [
                {"type": "heading", "text": "Score margins"},
                {
                    "type": "paragraph",
                    "text": (
                        "For each valid pair, the smaller winning-versus-runner-up score margin "
                        "was summarized. The few nonmatching GSE96058 pairs had lower medians "
                        "than matching pairs, but no group test or cutoff was planned or "
                        "selected."
                    ),
                },
                {
                    "type": "figure",
                    "path": "figure-2-margins.png",
                    "caption": (
                        "Figure 2. Median smaller PAM50 score margin by repeat-label state. "
                        "Nonmatching groups contain only five primary and four secondary pairs. "
                        "This descriptive contrast does not define a reliability threshold."
                    ),
                },
                {"type": "heading", "text": "Numerical incident"},
                {
                    "type": "paragraph",
                    "text": (
                        "The first TCGA implementation attempt rejected two exact log2(0.1) "
                        "boundary values. That provisional output was rejected and not "
                        "interpreted. The accepted run applied only the 1e-12 floor tolerance "
                        "frozen before TCGA molecular access."
                    ),
                },
            ],
            [
                {"type": "heading", "text": "Interpretation"},
                {
                    "type": "paragraph",
                    "text": (
                        "The frozen implementation showed high but imperfect repeat-label "
                        "agreement in GSE96058 and retained labels in all five TCGA-BRCA pairs. "
                        "The five-pair external result is encouraging but its 56.55% lower "
                        "confidence limit shows substantial uncertainty."
                    ),
                },
                {"type": "paragraph", "style": "small", "text": " "},
                {"type": "heading", "text": "Limitations"},
                {
                    "type": "paragraph",
                    "text": (
                        "The external candidate was found after the original result. GDC and "
                        "SCAN-B used different upstream expression workflows, while the fixed "
                        "reference shares the SCAN-B context. GSE96058 mixes repeat mechanisms. "
                        "The discordant groups and external cohort are small. Technical-repeat "
                        "agreement cannot identify biological truth or establish diagnostic, "
                        "prognostic, predictive, treatment, clinical-utility, or general "
                        "transportability validity."
                    ),
                },
                {"type": "heading", "text": "Public-source search update"},
                {
                    "type": "paragraph",
                    "text": (
                        "Continued public-source screening admitted E-TABM-576 only as a "
                        "separate cross-platform sensitivity analysis. No larger eligible "
                        "unchanged-method repeat dataset has been identified, and search "
                        "completeness is not claimed."
                    ),
                },
                {"type": "heading", "text": "Conclusion"},
                {
                    "type": "paragraph",
                    "text": (
                        "The evidence supports a narrow source-bound repeatability conclusion. "
                        "It does not support a population rate or clinical claim. This public "
                        "release invites open post-publication review; it is not independent "
                        "review or journal peer review."
                    ),
                },
            ],
            [
                {"type": "heading", "text": "Reproducibility and sources"},
                {
                    "type": "paragraph",
                    "text": (
                        "The package accompanying this public report contains the versioned "
                        "manuscript, checksum receipts, review packet, numerical-incident "
                        "record, current search refresh, exact figure and paper builder, and "
                        "the shared NaS renderer and palette. It excludes raw molecular data, "
                        "identifiers, credentials, outcomes, and controlled records."
                    ),
                },
                {
                    "type": "paragraph",
                    "style": "small",
                    "text": (
                        "Review provenance: the founder directed an AI-assisted internal "
                        "release audit and authorized website publication after an audit pass. "
                        "The report has not received independent scientific review or journal "
                        "peer review and is not for clinical use."
                    ),
                },
                {"type": "heading", "text": "Public sources"},
                {
                    "type": "references",
                    "items": [
                        [
                            "GSE96058 - NCBI Gene Expression Omnibus",
                            "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE96058",
                        ],
                        [
                            "TCGA-BRCA - NCI Genomic Data Commons",
                            "https://portal.gdc.cancer.gov/projects/TCGA-BRCA",
                        ],
                        [
                            "E-TABM-576 - EMBL-EBI BioStudies",
                            "https://www.ebi.ac.uk/biostudies/arrayexpress/studies/E-TABM-576",
                        ],
                        [
                            "Original PAM50 description - PubMed 19204204",
                            "https://pubmed.ncbi.nlm.nih.gov/19204204/",
                        ],
                        [
                            "Published repeatability context - PubMed 36892725",
                            "https://pubmed.ncbi.nlm.nih.gov/36892725/",
                        ],
                    ],
                },
            ],
        ],
    }


def _copy_sources(output_dir: Path) -> None:
    source_dir = output_dir / "source"
    source_dir.mkdir()
    paths = [
        MANUSCRIPT,
        MANUSCRIPT_RECEIPT,
        PRIMARY_RECEIPT,
        EXTERNAL_RECEIPT,
        INTERPRETATION,
        INTERPRETATION_DECISION,
        SENSITIVITY_RECEIPT,
        SENSITIVITY_DECISION,
        REVIEW_PACKET,
        NUMERICAL_INCIDENT,
        SEARCH_REFRESH,
        ADVERSARIAL_AUDIT,
        FINAL_RELEASE_AUDIT,
        PUBLIC_RELEASE_AUTHORIZATION,
        HERE / "build_public_report_v1_0_0.py",
        HERE / "requirements-review-paper.txt",
        TEMPLATE / "render.py",
        TEMPLATE / "brand.json",
        TEMPLATE / "README.md",
        TEMPLATE / "nas-logo.png",
    ]
    for path in paths:
        shutil.copy2(path, source_dir / path.name)


def _write_manifest(output_dir: Path, *, source_revision: str) -> None:
    files = []
    for path in sorted(item for item in output_dir.rglob("*") if item.is_file()):
        if path.name in {"manifest.json", "reproducibility.zip", "bundle-receipt.json"}:
            continue
        files.append(
            {
                "path": path.relative_to(output_dir).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    manifest = {
        "schema_version": "1.0.0",
        "study_id": "NAS-BRCA-002",
        "artifact_version": "public-report-v1.0.0",
        "source_revision": source_revision,
        "review_state": "internally_reviewed_with_ai_assistance_not_peer_reviewed",
        "raw_or_controlled_data_included": False,
        "outcomes_included": False,
        "publication_authorized": True,
        "files": files,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def _write_deterministic_zip(output_dir: Path) -> Path:
    zip_path = output_dir / "reproducibility.zip"
    included = sorted(
        path
        for path in output_dir.rglob("*")
        if path.is_file() and path.name not in {"reproducibility.zip", "bundle-receipt.json"}
    )
    with zipfile.ZipFile(
        zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in included:
            info = zipfile.ZipInfo(path.relative_to(output_dir).as_posix())
            info.date_time = (2026, 9, 11, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    return zip_path


def build_public_release(output_dir: Path, *, source_revision: str) -> dict[str, Any]:
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError("public-report output directory must be new or empty")
    output_dir.mkdir(parents=True, exist_ok=True)
    if not all((TEMPLATE / name).is_file() for name in ("render.py", "brand.json", "nas-logo.png")):
        raise FileNotFoundError("shared NaS paper template is incomplete")

    primary = _load_mapping(PRIMARY_RECEIPT)
    external = _load_mapping(EXTERNAL_RECEIPT)
    sensitivity = _load_mapping(SENSITIVITY_RECEIPT)
    decision = _load_mapping(INTERPRETATION_DECISION)
    sensitivity_decision = _load_mapping(SENSITIVITY_DECISION)
    search = _load_mapping(SEARCH_REFRESH)
    authorization = _load_mapping(PUBLIC_RELEASE_AUTHORIZATION)
    if (
        primary.get("primary_pair_count") != 136
        or primary.get("secondary_pair_count") != 87
        or external.get("pair_count") != 5
        or external.get("valid_profile_count") != 10
        or sensitivity.get("primary", {}).get("attempted_pair_count") != 16
        or sensitivity.get("primary", {}).get("concordant_pair_count") != 13
        or sensitivity.get("secondary", {}).get("attempted_pair_count") != 39
        or decision.get("human_interpretation_review_status") != "approved"
        or decision.get("publication_authorized") is not False
        or sensitivity_decision.get("manuscript_integration_authorized") is not True
        or sensitivity_decision.get("publication_authorized") is not False
        or search.get("refresh_version") != "1.5.0"
        or search.get("searched_at") != "2026-09-10"
        or search.get("newly_eligible_larger_candidate_count") != 0
        or authorization.get("candidate_pdf_sha256")
        != "6aebc1f25f61a75c6f2aec61b5e6c53d07b5c0e9a4e4070a459b54429dfc490a"
        or authorization.get("release_artifact") != "public-report-v1.0.0"
        or authorization.get("ai_assisted_internal_release_audit_authorized") is not True
        or authorization.get("publication_execution_authorized_on_audit_pass") is not True
        or authorization.get("website_release_authorized_on_audit_pass") is not True
        or not FINAL_RELEASE_AUDIT.is_file()
    ):
        raise ValueError("public-report evidence or authority boundary changed")

    rows = _agreement_rows(primary, external, sensitivity)
    build_agreement_figure(rows, output_dir / "figure-1-agreement.png")
    build_margin_figure(primary, output_dir / "figure-2-margins.png")
    document = build_document(primary, external, sensitivity)
    (output_dir / "publication-layout.json").write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (output_dir / "README.txt").write_text(
        "NAS-BRCA-002 public-report reproducibility package\n"
        "Status: internally reviewed with AI assistance; not peer reviewed.\n"
        "Public posting begins open post-publication review. Not for clinical use.\n"
        "Raw molecular data, outcomes, identifiers, controlled data, and "
        "credentials are excluded.\n",
        encoding="utf-8",
    )
    rl_config.invariant = True
    render = runpy.run_path(str(TEMPLATE / "render.py"))["render"]
    pdf_path = output_dir / "nas-brca-002-public-report-v1.0.0.pdf"
    render(document, pdf_path, output_dir)
    _copy_sources(output_dir)
    _write_manifest(output_dir, source_revision=source_revision)
    zip_path = _write_deterministic_zip(output_dir)
    receipt = {
        "schema_version": "1.0.0",
        "study_id": "NAS-BRCA-002",
        "artifact_version": "public-report-v1.0.0",
        "source_revision": source_revision,
        "pdf_sha256": _sha256(pdf_path),
        "pdf_bytes": pdf_path.stat().st_size,
        "zip_sha256": _sha256(zip_path),
        "zip_bytes": zip_path.stat().st_size,
        "manifest_sha256": _sha256(output_dir / "manifest.json"),
        "publication_authorized": True,
    }
    (output_dir / "bundle-receipt.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return receipt


def _current_revision() -> str:
    return subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=REPOSITORY_ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--source-revision", default=None)
    args = parser.parse_args()
    receipt = build_public_release(
        args.output_dir,
        source_revision=args.source_revision or _current_revision(),
    )
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
