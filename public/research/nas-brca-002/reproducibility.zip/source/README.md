# NaS Research paper format v1

Default visual format for new NaS research PDFs and revised editions. The reference
is the existing NaS Denials publication, its original logo, and its print palette.
Established at the founder's request on 9 September 2026 UTC. This is a repository
publication template, not a Codex Template Gallery skill.

## Visual standard

- White US Letter pages; 56-point margins; generous, consistent spacing.
- Original gold NaS symbol on the opening page. Never recolor or stretch it.
- Black titles and section headings; charcoal body copy; gray metadata and captions.
- Gold is reserved for small publication labels, rules, and a figure series.
  Do not use green, teal, or colored body paragraphs.
- Arial regular/bold, embedded when available; Helvetica is the explicit fallback.
  Cover title 30/35 pt; page titles 22/27; section headings 13/17; body 10.8/14.5;
  captions and references 8.5/11.5. Never shrink text to force a page count.
- Tables use black headers with white text, gray rules, and restrained padding.
- Figures use gold and charcoal, plus distinct marker shapes/labels so meaning
  survives grayscale printing. Neutral backgrounds; no decorative chart effects.
- Running header identifies NaS and the study; footer shows version, review state,
  and page number. Review state must describe actual review, not imply endorsement.

## Structure and reuse

Use a cover with logo, series label, descriptive title, short subtitle, abstract,
date/version/author, and review state. Body pages contain question, methods, results,
figures and captions, interpretation, limitations, reproducibility, and references.
Section order and page count may vary with study length; typography and palette do not.
Titles must match the scope of the evidence. State dataset overlap and known model
limitations; distinguish ranking, classification, and clinical validation.

`render.py` accepts a document dictionary with title, subtitle, series, study_id,
version, date, author, review_state, abstract, cover_note, and pages. Each page is a
list of blocks: heading, paragraph, figure (path/caption), table (rows), or references
(label/URL pairs). Call `render(document, output_path, asset_root)` from a study
adapter. See `workflows/studies/atlas_rnu42_benchmark/release/build_pdf.py`.
Figure builders and HTML should read the same `brand.json` palette.

Generated PDFs, previews, source data, and distribution packages belong on the
external drive. Keep previously released editions intact and create a new version.
Render and visually inspect every PDF page; confirm all links, review labels,
source attributions, tables, and unchanged numerical results before delivery.

This standard applies going forward. Existing public papers are not silently replaced.
