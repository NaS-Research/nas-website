# NAS-BRCA-002 consolidated scientific review packet

Packet version: `1.2.0`

Prepared: 2026-09-11

Status: **prepared for consolidated final human review before any external release**

## Research name

Formal title: **Technical-repeat sensitivity of fixed-reference PAM50 subtyping in
public breast-cancer expression data**

Plain-language name: **The PAM50 Breast Cancer Repeatability Study**

## Question

When two public expression measurements come from the same reported breast-cancer RNA
source, does one frozen PAM50 computer method give them the same subtype label? How
does repeatability behave in the original RNA-sequencing source, a small external
RNA-sequencing check, and a separately adapted microarray sensitivity analysis?

This fully computational study measures label repeatability. It does not identify a
biologically correct subtype and does not test diagnosis, prognosis, treatment
response, clinical utility, or patient care.

## Analyzed evidence

- GSE96058 primary: all 136 linked technical-repeat pairs.
- GSE96058 prespecified secondary: all 87 HR-positive/HER2-negative pairs.
- TCGA-BRCA post-result external check: all five registered same-analyte pairs.
- E-TABM-576 preregistered cross-platform sensitivity: all 16 primary
  independent-source pairs and all 39 dependency-aware secondary comparisons.
- E-TABM-576 platform reference: all 112 registered singleton profiles.
- Execution: every registered profile was attempted and each accepted analysis
  required two byte-identical runs.

No physical specimen, wet-laboratory procedure, controlled record, clinical outcome,
or patient-facing workflow was used.

## Results requiring final review

- GSE96058 primary: 131 of 136 pairs matched, or 96.32%; two-sided 95% Wilson
  interval, 91.68%–98.42%.
- GSE96058 secondary: 83 of 87 pairs matched, or 95.40%; two-sided 95% Wilson
  interval, 88.77%–98.20%.
- TCGA-BRCA: five of five pairs matched, or 100%; two-sided 95% Wilson interval,
  56.55%–100%.
- E-TABM-576 primary: 13 of 16 pairs matched, or 81.25%; two-sided 95% Wilson
  interval, 56.99%–93.41%.
- E-TABM-576 secondary: 31 of 39 comparisons matched, or 79.49%; two-sided 95%
  Wilson interval, 64.47%–89.22%. These comparisons reuse profiles and are not
  independent.
- E-TABM-576 median within-pair centered-profile Spearman correlation: 0.619
  (range, -0.094–0.934).

GSE96058, TCGA-BRCA, and E-TABM-576 were not pooled or tested for a difference.

## Required interpretation

The original GSE96058 analysis found high but imperfect label repeatability under one
fixed RNA-sequencing implementation. The very small TCGA-BRCA set retained labels in
all five pairs but has a wide interval and does not establish a 100% population rate.

The separately preregistered E-TABM-576 stress test found incomplete repeatability
under a frozen microarray adaptation: three of 16 primary pairs were discordant. Its
81.25% point estimate is numerically lower than the 96.32% GSE96058 estimate, but no
between-cohort test was planned or performed. Platform, preprocessing, reference,
cohort, preservation, and other source differences remain entangled; the numerical
gap does not establish a statistical difference or its cause.

None of the results determines subtype truth, calibrates an individual reliability
probability, validates a threshold, or supports a clinical claim.

## Required limitations

- The TCGA-BRCA candidate and E-TABM-576 source were found after GSE96058 results.
- Five TCGA pairs and 16 E-TABM-576 primary pairs provide limited precision.
- E-TABM-576 required a platform-specific reporter collapse and singleton reference,
  so it is cross-platform sensitivity rather than unchanged-method validation.
- The 39 E-TABM-576 secondary comparisons are dependent.
- Collection eras and programs support E-TABM-576/GSE96058 specimen-cohort
  independence, but participant-level nonoverlap was not identifier-verified.
- GSE96058 repeat mechanisms are mixed and not completely labeled pair by pair.
- Discordant-pair score-margin summaries are sparse and cannot define a cutoff.
- Internal founder-led and AI-assisted work is not independent or journal peer review.

## Consolidated final-review checklist

- [ ] Confirm all three source roles and every registered denominator.
- [ ] Confirm all reported counts, percentages, intervals, and continuous summaries.
- [ ] Confirm the frozen GSE96058 and TCGA method remained unchanged.
- [ ] Confirm E-TABM-576 is described as a distinct cross-platform adaptation.
- [ ] Confirm post-result source discovery is disclosed.
- [ ] Confirm all three analyses remain unpooled and untested for a difference.
- [ ] Confirm no population-rate, superiority, causal, or threshold claim is made.
- [ ] Confirm biological-truth and clinical limitations are explicit.
- [ ] Confirm participant-identity and dependency limitations are explicit.
- [ ] Confirm this is internal computational review, not independent peer review.
- [ ] Confirm manuscript `0.5.0-working` matches the governed evidence.

## Final-review outcomes

- [ ] Accept manuscript `0.5.0-working` as an internally reviewed, source-bound
  computational research report.
- [ ] Return the manuscript for specified revisions.
- [ ] Do not accept the manuscript or current interpretation.

No box is selected in this prepared packet. Standing internal authority permits
continued reversible research work without routine approvals. This consolidated final
review is preserved before any request for external submission or publication.

## Evidence map

- Working manuscript: `QUESTION_V0_4_WORKING_MANUSCRIPT_v0.5.0.md`
- Manuscript receipt: `QUESTION_V0_4_WORKING_MANUSCRIPT_RECEIPT_v0.5.0.yaml`
- Original analysis receipt: `gse96058_full_analysis_receipt_v1.0.0.yaml`
- TCGA-BRCA analysis receipt:
  `gse96058_tcga_brca_external_validation_analysis_receipt_v1.0.0.yaml`
- TCGA-BRCA interpretation decision:
  `GSE96058_TCGA_BRCA_EXTERNAL_VALIDATION_INTERPRETATION_DECISION_v1.0.0.yaml`
- TCGA numerical incident:
  `gse96058_tcga_brca_numerical_boundary_incident_v1.0.0.yaml`
- E-TABM-576 empirical receipt:
  `gse96058_etabm576_empirical_analysis_receipt_v1.0.0.yaml`
- E-TABM-576 interpretation decision:
  `GSE96058_ETABM576_INTERPRETATION_STANDING_AUTHORIZATION_DECISION_v1.0.0.yaml`
- Figure receipt: `GSE96058_FIGURE_1_RECEIPT_v1.0.1.yaml`
