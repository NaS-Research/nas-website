# Technical-repeat sensitivity of fixed-reference PAM50 subtyping in public breast-cancer expression data

Manuscript version: `0.5.0-working`

Study: `NAS-BRCA-002`

Question version: `0.4.0`

Last updated: 2026-09-10

Overall status: **working—primary descriptive analysis, small post-result RNA-seq
external check, and preregistered cross-platform microarray sensitivity complete;
source-bound interpretations integrated under standing internal authority; final human
review, submission, and publication remain open**

## Abstract

Status: `working`

PAM50 research pipelines commonly return one breast-cancer intrinsic-subtype label,
although small changes in a profile near competing subtype centroids may change that
label. We evaluated label repeatability and continuous score separation using 136
linked technical-repeat pairs in the public GSE96058 processed RNA-seq dataset. The
analysis used a frozen patient-independent historical PAM50 implementation, a fixed
external reference, five fixed centroids, and Spearman correlation. All 272 profiles
produced valid scores. Labels agreed in 131 of 136 pairs (96.32%; two-sided 95% Wilson
interval, 91.68%–98.42%). In the prespecified 87-pair
HR-positive/HER2-negative subgroup, 83 pairs agreed (95.40%; 95% Wilson interval,
88.77%–98.20%). The median of each pair's smaller leading-versus-runner-up score margin
was 0.2656 among concordant primary pairs and 0.0081 among discordant primary pairs.
This margin comparison is descriptive: no group test, p-value, or reliability cutoff
was specified or selected. In a disclosed post-result external check, all ten profiles
from five registered TCGA-BRCA same-analyte pairs were valid and all five pairs retained
their labels (100%; 95% Wilson interval, 56.55%–100%). The cohorts were not pooled or
tested for a difference. In a separately preregistered E-TABM-576 microarray
sensitivity, 13 of 16 primary pairs retained labels (81.25%; 95% Wilson interval,
56.99%–93.41%). Its three discordances show incomplete repeatability under the frozen
platform adaptation. The cross-platform result was not pooled with or tested against
GSE96058. These analyses do not establish a biologically correct subtype, analytical
or clinical validity, a population agreement rate, calibrated reliability, or general
transportability.

## Introduction

PAM50 subtyping compares a breast-tumor expression profile with five subtype
centroids. The label with the strongest similarity is typically reported, but the
distance between the first- and second-ranked scores is often hidden. A label with a
small score separation may be more sensitive to modest measurement or processing
variation than a label with a wide separation. Prior work has shown reference,
preprocessing, cohort-composition, perturbation, and repeat-measurement sensitivity in
PAM50-related workflows. [PMID:19204204; PMID:22196354; PMID:32826944;
PMID:36892725; PMID:37857634]

The practical research question was deliberately narrow: when the same reported RNA
source appears as a linked technical repeat in GSE96058, how often does a fixed
patient-independent PAM50 implementation return the same label, and what score
margins accompany concordant and discordant pairs? The analysis was designed to
describe technical-repeat sensitivity, not to determine a tumor's biologically true
subtype or evaluate prognosis, treatment response, or clinical utility.

## Methods

### Design and data source

The primary cohort comprised all 136 GSE96058 records with an explicitly linked
technical repeat. The prespecified secondary subgroup comprised the 87 linked pairs
classified from public receptor metadata as HR-positive/HER2-negative. Every linked
pair remained in its attempted denominator. The dataset contains a mixture of newly
prepared-library repeats and same-library resequencing, but no complete public
pair-level mechanism field; the pairs were therefore analyzed as one source-bound
mixed cohort rather than as isolated assay-stage strata.

Only public processed expression and public sample metadata were used. Clinical
outcomes and published subtype fields were excluded. No specimen, wet-laboratory
procedure, controlled dataset, or patient-facing workflow was involved.

### Frozen PAM50 scoring

The deposited GSE96058 `log2(FPKM + 0.1)` matrix was used unchanged. Each profile was
restricted to the frozen 50-gene panel and centered gene by gene against the immutable
GSE81538 median reference constructed on the same declared transformed scale. The five
fixed centroid vectors came from the checksummed `genefu` 2.44.0 candidate artifact.
Spearman correlations were computed against all five centroids. Each profile retained
the top subtype, runner-up subtype, both scores, and their continuous difference. The
method used no cohort centering, imputation, outcome-guided adaptation, or post-result
threshold.

The execution revalidated four immutable input identities before reading molecular
values. All 272 frozen profile slots were scored twice from the same committed code;
canonical result bytes were required to match before the result artifact was accepted.

### Descriptive analysis

The primary estimand was the number of pairs with two valid identical labels divided
by all 136 attempted pairs. Agreement among valid pairs was also planned; because all
profiles were valid, its denominator equaled the attempted-pair denominator. Two-sided
95% Wilson score intervals summarized binomial precision.

For every valid pair, three continuous summaries were formed: the smaller of the two
top-versus-runner-up margins, the mean of the two margins, and the absolute difference
between margins. These quantities were summarized separately for concordant and
discordant pairs using minimum, Hyndman–Fan type-7 quartiles, median, and maximum. The
protocol specified no inferential group test, p-value, multiplicity adjustment, or
reliability/abstention cutoff.

### Post-result external technical-repeat check

After the GSE96058 results were known, a public-metadata search identified five
TCGA-BRCA primary-tumor sample records with two open GDC STAR-counts files sharing the
same case, sample, tissue portion, and RNA analyte. The ten files were registered before
molecular parsing. Exact canonical PAM50 `fpkm_unstranded` values were transformed as
`log2(FPKM + 0.1)` and scored with the unchanged fixed reference, centroids, and
Spearman procedure. All five registered pairs remained in the attempted denominator.

The extension was preregistered after candidate discovery and before molecular access.
It specified an attempted-pair agreement estimate and Wilson interval, prohibited
pooling or a difference test against GSE96058, and required two byte-identical runs.
No receptor field, outcome, controlled record, new threshold, or source-adapted method
was used.

### Preregistered cross-platform sensitivity analysis

E-TABM-576 was identified by public-metadata search after the GSE96058 and TCGA results
were known. Before its processed microarray expression values were opened, a separate
cross-platform sensitivity plan registered 16 primary independent-source pairs, all 39
within-source comparisons as a dependent secondary view, and 112 singleton profiles as
the platform-specific reference. Public collection-era and program metadata supported
independent specimen-generating cohorts relative to GSE96058, although no public
identifier crosswalk established participant-level nonoverlap.

For each profile, all 59 registered Illumina reporters were required and collapsed to
the 50 PAM50 genes by the frozen within-profile median rule. Each gene was centered
against its median across the 112 singleton profiles and scored against the same five
fixed centroids by Spearman correlation. The primary estimand was matching valid labels
divided by all 16 attempted pairs; failures remained in the denominator. Two-sided 95%
Wilson intervals and preregistered continuous summaries were descriptive. The plan
prohibited refitting, expression-driven reporter selection, threshold selection,
cross-cohort pooling, and a between-cohort test.

## Results

### Completeness and deterministic execution

All 272 profiles across the 136 primary pairs reached a valid terminal score; no pair
was excluded and no prespecified failure code occurred. Two complete executions
produced byte-identical 87,509-byte canonical artifacts (SHA-256
`9f6d38af030a04abe415a721d1b4d5e0da2c7595e54188305c73b05e766c36f5`).

### Technical-repeat label agreement

| Cohort | Attempted pairs | Valid pairs | Concordant | Discordant | Agreement | Two-sided 95% Wilson interval |
|---|---:|---:|---:|---:|---:|---:|
| All linked pairs (primary) | 136 | 136 | 131 | 5 | 96.32% | 91.68%–98.42% |
| HR-positive/HER2-negative (secondary) | 87 | 87 | 83 | 4 | 95.40% | 88.77%–98.20% |

Agreement was therefore high but not perfect in both prespecified cohorts. The
secondary estimate is descriptive and precision-limited; the similarity of the two
point estimates is not evidence of equivalence.

### Continuous score margins

| Cohort and label-repeat state | Pairs | Median smaller margin | Median mean margin | Median absolute within-pair margin difference |
|---|---:|---:|---:|---:|
| Primary, concordant | 131 | 0.2656 | 0.2859 | 0.0225 |
| Primary, discordant | 5 | 0.0081 | 0.0444 | 0.0091 |
| Secondary, concordant | 83 | 0.2656 | 0.2744 | 0.0226 |
| Secondary, discordant | 4 | 0.0169 | 0.0271 | 0.0078 |

Discordant pairs had lower descriptive median smaller margins than concordant pairs
in both cohorts. With only five discordant primary pairs and four discordant secondary
pairs, these summaries are sparse. They were not subjected to a hypothesis test and
must not be converted into a cutoff by inspecting these results.

Figure 1 displays both cohort agreement estimates with their two-sided 95% Wilson
intervals and the concordant-versus-discordant median smaller margins. The figure uses
aggregate values only and retains the sparse discordant denominators on its face.

**Figure 1. GSE96058 PAM50 technical-repeat agreement and score margins.** Panel A
shows identical-label proportions and two-sided 95% Wilson intervals. Panel B shows
the median, within each group, of the smaller leading-versus-runner-up Spearman score
margin across each pair. The margin panel is descriptive and does not define or
validate a reliability threshold. Governed local artifact:
`gse96058_figure_1_v1.0.1.svg`; receipt:
`GSE96058_FIGURE_1_RECEIPT_v1.0.1.yaml`.

### Post-result TCGA-BRCA external check

All ten TCGA-BRCA profiles passed the frozen input and scoring rules. All five of five
registered same-analyte pairs received matching PAM50 labels, giving 100% attempted-pair
agreement (two-sided 95% Wilson interval, 56.55%–100%). With no discordant pair, no
discordant-pair margin summary was defined. Two complete executions produced
byte-identical 4,682-byte results (SHA-256
`13ac326a2bcca479b8bd7e7d8b1de3312fcdbabb714ed82626ecfd5003af08d2`).

The first implementation attempt had rejected two profiles because mathematical
`log2(0.1)` was approximately `1.8e-15` below an older rounded floor constant. That
provisional output was not admitted or interpreted. The accepted run applied only the
`1e-12` absolute floor tolerance already frozen in the processed-input quality-control
specification before TCGA molecular access; the incident is retained in a separate
checksum-bound record.

### E-TABM-576 cross-platform sensitivity

All 153 E-TABM-576 profiles passed the frozen parser and projection rules. All 16
primary pairs were valid; 13 were label-concordant and three discordant, giving 81.25%
attempted-pair agreement (two-sided 95% Wilson interval, 56.99%–93.41%). The median
within-pair Spearman correlation of centered 50-gene profiles was 0.619 (range,
-0.094–0.934).

The dependent secondary view contained 31 concordant and eight discordant comparisons
among all 39 registered within-source comparisons, or 79.49% agreement (two-sided 95%
Wilson interval, 64.47%–89.22%). Because profiles are reused, these are not 39
independent pairs. Two complete accepted executions produced byte-identical 132,295-byte
results (SHA-256
`efb877667bbd3a0c48d89bf58955fdc463d00d120df43a550cdd36e83b26e7a1`).

## Discussion

Under one frozen fixed-reference implementation, most linked GSE96058 technical
repeats received the same PAM50 label. The five discordant pairs show that a forced
top-label output is not perfectly repeatable even when two records are linked to the
same reported RNA source. Reporting the leading-versus-runner-up margin alongside the
label makes this sensitivity visible without pretending that the margin is a calibrated
probability of correctness.

The descriptive separation between concordant and discordant margin summaries is
consistent with the study's motivating idea that close competing centroid scores can
accompany fragile calls. It does not establish causation, a universal relationship, or
an operating threshold. A cutoff chosen from these five observed discordances would be
post hoc and overfit to this source.

### Context from an independent published repeatability study

An independently conducted study reported 127 concordant PAM50 subtype pairs among 144
same-RNA technical repeats, summarized by its authors as 90% agreement
[PMID:36892725]. That result provides useful context because it also demonstrates
nonzero subtype discordance after repeated measurement of the same RNA. It is not an
external validation of the NaS result: the published study used a research NanoString
assay, a different normalization and classifier implementation, different tumor
sources and quality control, and participant-level values that are not public for
reanalysis. The published 90% and NaS 96.32% figures were neither pooled nor tested for
a difference. Their numerical difference cannot be interpreted as superiority of a
platform, method, or cohort.

### Interpretation of the external check

The five matching TCGA-BRCA pairs are consistent with technical repeatability under the
frozen method in this small external set. They do not confirm a 100% population rate:
the 56.55% lower confidence limit reflects substantial uncertainty. Candidate discovery
occurred after the GSE96058 result, GDC and SCAN-B used different upstream expression
workflows, and the fixed reference shares the SCAN-B context of GSE96058. Same-analyte
agreement also cannot determine whether either reported label is biologically correct.

Accordingly, the TCGA result remains separate from the 136 GSE96058 pairs. It was not
pooled with GSE96058, compared by a hypothesis test, or used to claim superiority. A
larger prospectively selected public repeat cohort would be needed for a more precise
external estimate.

### Interpretation of the cross-platform sensitivity

Thirteen of 16 registered E-TABM-576 primary pairs retained their labels under the
frozen microarray adaptation. The three discordant pairs demonstrate incomplete label
repeatability in this source. The 81.25% point estimate is numerically lower than the
96.32% GSE96058 primary estimate, but the analyses use different platforms, processing,
references, cohorts, and specimen contexts. They were not pooled or tested for a
difference. The observed numerical gap therefore does not establish a statistical
difference and cannot be assigned to one cause.

This result is informative as a prospective cross-platform stress test. It is not
unchanged-method external validation, a population-rate estimate, biological subtype
truth, or clinical validation. The 16-pair interval remains wide, and the 39-comparison
secondary result is dependency-aware descriptive evidence only.

## Limitations

- GSE96058 supplies processed expression rather than public raw reads, so the study
  cannot re-evaluate alignment, quantification, or raw-read quality.
- The 136 pairs mix repeat mechanisms without a complete pair-level mechanism label;
  they do not isolate one laboratory or sequencing-stage error distribution.
- The historical centroids and GSE81538 fixed reference may not transport to another
  platform, preprocessing pipeline, institution, or population.
- Only five primary and four secondary pairs were discordant, making the discordant
  margin summaries sparse and unstable.
- The 87-pair HR-positive/HER2-negative subgroup is secondary and below the earlier
  93-pair confirmatory planning floor.
- Technical-repeat agreement does not identify a biologically correct subtype and
  cannot establish diagnostic, prognostic, predictive, treatment, or utility validity.
- The external candidate was found after the original results, and its five pairs are
  too few to estimate a precise population agreement rate.
- GDC and SCAN-B used different upstream expression workflows, while the fixed reference
  shares the SCAN-B context used for GSE96058.
- E-TABM-576 required a prospectively frozen microarray-specific reporter collapse and
  singleton reference, so its result cannot be treated as unchanged-method validation.
- The 16 E-TABM-576 primary pairs give limited precision, while the 39 secondary
  comparisons reuse profiles and are not independent.
- Collection eras and programs support E-TABM-576/GSE96058 cohort independence, but no
  public participant-identity crosswalk verified individual-level nonoverlap.
- The project has internal founder-led and AI-assisted review, not journal peer review.

## Conclusions

In this public, source-bound computational analysis, 131 of 136 linked technical-repeat
pairs received identical fixed-reference PAM50 labels, with five discordances. The
prespecified HR-positive/HER2-negative subgroup showed a similar descriptive pattern.
Discordant pairs had smaller score-margin summaries, but the analysis did not test a
group hypothesis or define a reliability cutoff. The defensible conclusion is limited
to high but imperfect repeat-label agreement for GSE96058 and label retention in all
five pairs from the small post-result TCGA-BRCA check. The external result is encouraging
but imprecise and does not establish a population rate, biological truth, or clinical
validity. The E-TABM-576 cross-platform sensitivity further found matching labels in
13 of 16 primary pairs, with three discordances and substantial interval uncertainty.
That result reveals incomplete repeatability under the frozen platform adaptation but
does not establish a difference from GSE96058 or explain the numerical gap. Larger
prospectively selected public technical-repeat data are needed before any broader claim.

## References

Citation details and governed appraisals remain in the question-v0.4 literature packet
and its six bound appraisal records. This working draft uses identifiers rather than
reproducing copyrighted article text.

## Evidence-to-text ledger

| Section | Claim | Governing evidence |
|---|---|---|
| Introduction | PAM50 definition and prior sensitivity context | `question_v0_4_literature_refresh_packet_v1.0.0.yaml` and its six bound appraisals |
| Methods—design | 136 primary pairs; 87 secondary pairs; mixed mechanisms | `gse96058_preregistration_readiness_v1.0.0.yaml` |
| Methods—scoring | Fixed reference, centroids, Spearman method, no threshold | `gse96058_scoring_method_review_packet_v1.0.0.yaml` |
| Results—execution | 272 valid profiles; deterministic artifact identity | `gse96058_full_analysis_receipt_v1.0.0.yaml` |
| Results—agreement and margins | Counts, Wilson intervals, descriptive margin summaries | `gse96058_full_analysis_receipt_v1.0.0.yaml` |
| Results—Figure 1 | Aggregate agreement intervals and median minimum margins | `GSE96058_FIGURE_1_RECEIPT_v1.0.1.yaml` |
| Discussion and limitations | Source-bound interpretation and prohibited extensions | `gse96058_descriptive_interpretation_packet_v1.0.0.yaml` |
| Discussion—published context | Independent 144-pair NanoString result and comparability limits | `gse96058_published_context_packet_v1.0.0.yaml` |
| Methods and results—TCGA external check | Registered five-pair design, deterministic execution, and accepted aggregate result | `gse96058_tcga_brca_external_validation_analysis_receipt_v1.0.0.yaml` |
| Discussion and limitations—TCGA external check | Source-bound interpretation and required limitations | `gse96058_tcga_brca_external_validation_interpretation_packet_v1.0.0.yaml` |
| Internal interpretation approval | Founder self-review and manuscript-integration authority only | `GSE96058_TCGA_BRCA_EXTERNAL_VALIDATION_INTERPRETATION_DECISION_v1.0.0.yaml` |
| Methods and results—E-TABM-576 sensitivity | Preregistered 16-pair cross-platform design and deterministic aggregate result | `gse96058_etabm576_empirical_analysis_receipt_v1.0.0.yaml` |
| Discussion and limitations—E-TABM-576 sensitivity | Source-bound interpretation and required limitations | `gse96058_etabm576_interpretation_packet_v1.0.0.yaml` |
| E-TABM-576 internal integration authority | Standing-autonomy authority, founder reaffirmation, and preserved external-action locks | `GSE96058_ETABM576_INTERPRETATION_STANDING_AUTHORIZATION_DECISION_v1.0.0.yaml` |

## Revision log

- `0.5.0-working` (2026-09-10): Added the preregistered 16-pair E-TABM-576
  cross-platform microarray sensitivity result and its source-bound interpretation
  under standing internal authority. GSE96058, TCGA-BRCA, and E-TABM-576 remain
  unpooled; no difference test, clinical claim, submission, or publication authority
  was created.
- `0.4.0-working` (2026-09-09): Added the preregistered post-result five-pair
  TCGA-BRCA external technical-repeat check and its internally approved source-bound
  interpretation. The cohorts remain unpooled; no difference test, clinical claim,
  submission, or publication authority was created.
- `0.3.0-working` (2026-09-07): Added the visually inspected aggregate-only Figure 1
  reference and caption. The figure remains an ignored-local working artifact with a
  checksum receipt; no submission or publication authority was created.
- `0.2.0-working` (2026-09-07): Added nonpooled context from the independent
  144-pair published NanoString repeatability study and prohibited direct superiority
  interpretation. No external validation or publication authority was created.
- `0.1.0-working` (2026-09-06): Created the question-v0.4 manuscript from the
  preregistered full-analysis receipt and governed interpretation packet. Human
  scientific review, independent validation, submission, and publication remain open.
