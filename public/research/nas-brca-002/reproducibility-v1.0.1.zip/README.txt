NAS-BRCA-002 companion evidence package, version 1.0.1.
Editorial revision, September 27, 2026. Methods and numerical results are unchanged.
Includes the current report, figures, manuscript and scientific verification records. Prior complete editions are archived by NaS.
