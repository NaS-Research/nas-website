# NAS-CVA-001 / ClinVar Conflict Atlas / v1.0.1

Unpublished website review candidate. Founder-led observational computational research; no independent human, expert, clinical or journal peer review has been completed. Counts describe preserved submitted records, not patient risk or classification correctness.

This is a curated inspection and replay-code package, not the sealed full unpublished research archive and not a raw-data mirror. Selected exact numerical exports, all 60 public code files, dependency lock, five portable protocol editions, 24-source fetch/checksum manifest, eight figure masters, data dictionary and portable computational receipts are included. Download matching raw sources separately for source-to-export replay. The two earlier review-status interval supplements are separate commands.

The v1.0.1 manuscript adds the reviewed source-completeness sensitivity, official-rule approximation counts, persistence endpoint clarification and symmetric-log caption. Primary numerical estimates, scientific code and tables are unchanged. Existing computational receipts retain their historical v1.0-unpublished scope; their paper/figure provenance must not be interpreted as visual approval of this new manuscript. The new manuscript has undergone local rendered visual review; independent human review and founder release authorization remain pending. Original protocol wording records the original authorized execution scope; it is not a public-release authorization.

Use FILE_MANIFEST.json for member hashes. See REPLAY.md and REUSE_AND_ATTRIBUTION.md. No publication, deployment or external submission has occurred.
