"""Transparent eligibility and date rules; no clinical interpretation."""
import datetime,json
from collections import defaultdict
from conflicts import canonical,unit
CRITERIA={'criteria provided, single submitter','reviewed by expert panel','practice guideline'}
EXPERT={'reviewed by expert panel','practice guideline'}
BAD_CONDITIONS={'not provided','not specified','unspecified','not applicable','unknown'}
def age_days(value,asof):
 try:d=datetime.date.fromisoformat(value)
 except (ValueError,TypeError):return None,'missing' if not value else 'invalid'
 if d>asof:return None,'future'
 return (asof-d).days,'valid'
def condition_ok(conditions):
 return bool(conditions) and all(x.get('DB')=='MedGen' and x.get('ID') and x.get('name','').strip().lower() not in BAD_CONDITIONS for x in conditions)
def exclusion_reasons(a,v,conditions,membership_count=1):
 reasons=[]
 if not v['direct_simple'] or not a['direct_simple']:reasons.append('not_direct_simple')
 if v['species']!='Homo sapiens':reasons.append('not_human')
 if v['status']!='current' or a['status']!='current':reasons.append('not_current')
 if a['class_type']!='germline':reasons.append('not_germline_classification')
 origins=set(json.loads(a['origins_json']))
 if origins and origins<={'somatic'}:reasons.append('exclusively_somatic_origin')
 if not a['org_id']:reasons.append('missing_organization')
 if canonical(a['label']) in {'SPECIAL','UNKNOWN'}:reasons.append('nonstandard_label')
 if a['review'] not in CRITERIA:reasons.append('no_assertion_criteria')
 if membership_count!=1:reasons.append('ambiguous_or_missing_rcv_membership')
 if not condition_ok(conditions):reasons.append('nonspecific_or_unresolved_condition')
 return reasons

def summarize(assertions,asof,allow_internal=False):
 by=defaultdict(list)
 for a in assertions:by[a['org_id']].append(canonical(a['label']))
 result=unit(by,allow_internal)
 retained={o for o,labels in by.items() if allow_internal or len(set(labels))==1}
 aa=[a for a in assertions if a['org_id'] in retained]
 ages=[age_days(a['evaluated'],asof)[0] for a in aa]
 valid=[x for x in ages if x is not None]
 result.update(assertions=len(aa),oldest_age_days=max(valid) if valid else None,newest_age_days=min(valid) if valid else None,missing_or_invalid_dates=len(ages)-len(valid),expert_present=any(a['review'] in EXPERT for a in aa),excluded_inconsistent_organizations=len(by)-len(retained))
 return result,aa
