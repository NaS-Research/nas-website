"""Stream verified VCV XML to normalized SQLite, without calculating outcomes."""
import argparse,datetime,gzip,hashlib,json,os,sqlite3,time
from collections import defaultdict
from pathlib import Path
from lxml import etree as E

def txt(e,path):
    v=e.findtext(path);return v.strip() if v else ''
def attr(e,path,name):
    v=e.find(path);return v.get(name,'') if v is not None else ''
def js(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def rows(v):
    vid=v.get('VariationID'); cr=v.find('ClassifiedRecord'); direct=cr is not None and cr.find('SimpleAllele') is not None
    allele=cr.find('SimpleAllele') if direct else None
    genes=[] if allele is None else [dict(x.attrib) for x in allele.findall('GeneList/Gene')]
    coords=[] if allele is None else [dict(x.attrib) for x in allele.findall('Location/SequenceLocation')]
    germ=None if cr is None else cr.find('Classifications/GermlineClassification')
    variant=(vid,v.get('Accession',''),v.get('Version',''),v.get('RecordType',''),txt(v,'RecordStatus'),txt(v,'Species'),int(direct),'' if allele is None else allele.get('AlleleID',''),v.get('VariationName',''),v.get('VariationType',''),js([{k:g.get(k,'') for k in ['GeneID','Symbol','RelationshipType']} for g in genes]),js(coords),txt(v,'ClassifiedRecord/SimpleAllele/CanonicalSPDI'),'' if germ is None else txt(germ,'Description'),'' if germ is None else txt(germ,'ReviewStatus'),v.get('DateCreated',''),v.get('DateLastUpdated',''))
    assertions=[];rcvs=[];deleted=[]
    if cr is None:return variant,assertions,rcvs,deleted
    maps=defaultdict(dict)
    for m in cr.findall('TraitMappingList/TraitMapping'):
        g=m.find('MedGen')
        if g is not None:maps[m.get('ClinicalAssertionID')][g.get('CUI','')]=g.get('Name','')
    for r in cr.findall('RCVList/RCVAccession'):
        conditions=[dict(x.attrib,name=x.text or '') for x in r.findall('ClassifiedConditionList/ClassifiedCondition')]
        rcvs.append((r.get('Accession'),vid,r.get('Version',''),js(conditions),txt(r,'RCVClassifications/GermlineClassification/Description'),txt(r,'RCVClassifications/GermlineClassification/ReviewStatus')))
    for a in cr.findall('ClinicalAssertionList/ClinicalAssertion'):
        ac=a.find('ClinVarAccession');cl=a.find('Classification')
        if ac is None:raise ValueError('Assertion without accession')
        gc=None if cl is None else cl.find('GermlineClassification')
        raw=gc.text or '' if gc is not None else ''
        class_type='germline' if gc is not None else 'somatic_or_other'
        conditions=dict(maps[a.get('ID')])
        submitted=[]
        for trait in a.findall('TraitSet/Trait'):
            submitted.append({'ids':[dict(x.attrib) for x in trait.findall('XRef')],'names':[x.text or '' for x in trait.findall('Name/ElementValue')]})
            for x in trait.findall('XRef'):
                if x.get('DB')=='MedGen':conditions.setdefault(x.get('ID',''),'')
        moi=sorted(set((x.text or '').strip() for x in a.findall('AttributeSet/Attribute') + a.findall('TraitSet/Trait/AttributeSet/Attribute') if x.get('Type')=='ModeOfInheritance'))
        moi+=sorted(set((x.text or '').strip() for x in a.findall('.//ModeOfInheritance')))
        origins=sorted(set(x.text or '' for x in a.findall('ObservedInList/ObservedIn/Sample/Origin')))
        methods=sorted(set(x.text or '' for x in a.findall('ObservedInList/ObservedIn/Method/MethodType')))
        assertions.append((ac.get('Accession'),ac.get('Version',''),vid,a.get('ID',''),ac.get('OrgID',''),ac.get('SubmitterName',''),ac.get('OrganizationCategory',''),class_type,raw.strip(),'' if cl is None else txt(cl,'ReviewStatus'),txt(a,'RecordStatus'),'' if cl is None else cl.get('DateLastEvaluated',''),a.get('DateCreated',ac.get('DateCreated','')),a.get('DateLastUpdated',ac.get('DateUpdated','')),a.get('SubmissionDate',''),js(conditions),js(submitted),js(sorted(set(moi))),js(origins),js(methods),a.get('ContributesToAggregateClassification',''),int(a.find('SimpleAllele') is not None)))
    for d in cr.findall('DeletedSCVList/SCV'):
        ac=d.find('Accession')
        if ac is not None:deleted.append((vid,ac.text or '',ac.get('Version',''),ac.get('DateDeleted','')))
    return variant,assertions,rcvs,deleted
SCHEMA='''
CREATE TABLE variants(variation_id TEXT,vcv TEXT,version TEXT,record_type TEXT,status TEXT,species TEXT,direct_simple INTEGER,allele_id TEXT,name TEXT,variant_type TEXT,genes_json TEXT,coordinates_json TEXT,spdi TEXT,official_label TEXT,official_review TEXT,created TEXT,updated TEXT);
CREATE TABLE assertions(scv TEXT,version TEXT,variation_id TEXT,assertion_id TEXT,org_id TEXT,org_name TEXT,org_type TEXT,class_type TEXT,label TEXT,review TEXT,status TEXT,evaluated TEXT,created TEXT,updated TEXT,submitted TEXT,conditions_json TEXT,submitted_conditions_json TEXT,inheritance_json TEXT,origins_json TEXT,methods_json TEXT,contributes TEXT,direct_simple INTEGER);
CREATE TABLE rcvs(rcv TEXT,variation_id TEXT,version TEXT,conditions_json TEXT,official_label TEXT,official_review TEXT);
CREATE TABLE deleted_scvs(variation_id TEXT,scv TEXT,version TEXT,deleted TEXT);
CREATE TABLE lineage(variation_id TEXT PRIMARY KEY,replaced_by TEXT,replaced_records TEXT);
CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);
'''
def normalize(root,month):
    (root/'tmp').mkdir(exist_ok=True);os.environ['SQLITE_TMPDIR']=str(root/'tmp')
    source=root/'raw'/month/f'ClinVarVCVRelease_{month}.xml.gz'
    prov=json.loads(source.with_name(source.name+'.provenance.json').read_text())
    assert prov['status']=='verified download' and source.stat().st_size==prov['bytes']
    out=root/'normalized'/month;out.mkdir(parents=True,exist_ok=True)
    final=out/'vcv.sqlite';part=out/'vcv.sqlite.part'
    assert not final.exists() and not part.exists(),'Refusing to replace extraction'
    with gzip.open(source,'rb') as f:
        _,r=next(iter(E.iterparse(f,events=('start',))))
        release=dict(r.attrib)
    location=release.get('{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation','')
    schemafile=root/'raw/documentation'/location.rsplit('/',1)[-1]
    schema=E.XMLSchema(E.parse(str(schemafile)))
    con=sqlite3.connect(part);con.executescript(SCHEMA);con.execute('PRAGMA journal_mode=OFF');con.execute('PRAGMA synchronous=OFF');con.execute('PRAGMA temp_store=FILE');con.execute('PRAGMA cache_size=-524288')
    counts={'variants':0,'assertions':0,'rcvs':0,'deleted_scvs':0};invalid=0;t=time.monotonic()
    err=(out/'schema_errors.jsonl').open('w')
    with gzip.open(source,'rb') as stream:
        for _,v in E.iterparse(stream,events=('end',),tag='VariationArchive',huge_tree=True):
            if not schema.validate(v):
                invalid+=1
                err.write(js({'variation_id':v.get('VariationID'),'errors':[str(e) for e in schema.error_log]})+'\n')
            vr,aa,rr,dd=rows(v)
            replaced=v.findall('ReplacedBy');replaces=v.findall('ReplacedList/Replaced')
            if replaced or replaces:con.execute('INSERT INTO lineage VALUES(?,?,?)',(v.get('VariationID'),js([dict(x.attrib) for x in replaced]),js([dict(x.attrib) for x in replaces])))
            con.execute('INSERT INTO variants VALUES('+','.join('?'*len(vr))+')',vr)
            for table,data in [('assertions',aa),('rcvs',rr),('deleted_scvs',dd)]:
                if data:con.executemany('INSERT INTO '+table+' VALUES('+','.join('?'*len(data[0]))+')',data)
                counts[table]+=len(data)
            counts['variants']+=1
            v.clear()
            while v.getprevious() is not None:del v.getparent()[0]
            if counts['variants']%10000==0:
                con.commit();print(js(dict(counts,elapsed_seconds=round(time.monotonic()-t),schema_invalid=invalid)),flush=True)
    err.close()
    con.executemany('INSERT INTO metadata VALUES(?,?)',[(k,js(val)) for k,val in {'month':month,'release':release,'source_sha256':prov['sha256'],'counts':counts,'schema_invalid':invalid}.items()])
    con.execute('CREATE UNIQUE INDEX variants_id ON variants(variation_id)');con.execute('CREATE UNIQUE INDEX assertions_id ON assertions(scv)');con.execute('CREATE UNIQUE INDEX rcvs_id ON rcvs(rcv)');con.execute('CREATE INDEX assertions_variant ON assertions(variation_id)');con.execute('CREATE INDEX rcvs_variant ON rcvs(variation_id)');con.commit();con.close()
    # A failed schema check remains an explicitly partial artifact and blocks downstream analysis.
    assert invalid==0,f'{invalid} schema-invalid records; investigate before finalizing'
    part.rename(final)
    (out/'normalization.json').write_text(json.dumps(dict(counts,schema_invalid=invalid,release=release,elapsed_seconds=time.monotonic()-t,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('month');a=ap.parse_args();normalize(a.root,a.month)
