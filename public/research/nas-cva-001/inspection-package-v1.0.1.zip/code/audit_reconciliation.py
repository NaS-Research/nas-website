"""Regenerate raw source evidence for the explicit frozen-source adjudications."""
import argparse,gzip,hashlib,json,sqlite3,time
from pathlib import Path
from lxml import etree as E
from source_completeness import run as supplement

def run(root,month):
 config=json.loads(Path(__file__).with_name('source_adjudications.json').read_text());item=config['snapshots'].get(month,{})
 inventory=json.loads((root/'analysis'/month/'source_identifier_reconciliation.json').read_text())
 assert sorted(inventory['rcv_only'])==sorted(item.get('rcv_only_scvs',[])) and sorted(inventory['vcv_only'])==sorted(item.get('vcv_only_scvs',[])),'Unknown presence discrepancy requires investigation'
 out=root/'analysis'/month;evidence=out/'source_evidence';evidence.mkdir(exist_ok=True)
 expected=item.get('version_discrepancies',[]);extras=inventory['rcv_only_records']
 if expected or extras:assert hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest()==config['source_manifest_sha256']
 targets={'vcv':{x['variation_id'] for x in expected+extras},'rcv':{x['rcv'] for x in expected+extras}}
 # Each extraction is independently bound to a digest fixed during source investigation.
 hashes={'vcv':{x['variation_id']:x['raw_vcv_record_sha256'] for x in expected},'rcv':{x['rcv']:x['raw_rcv_record_sha256'] for x in expected}}
 for x in item.get('missing_assertion_evidence',[]):
  hashes['vcv'][x['variation_id']]=x['raw_vcv_record_sha256'];hashes['rcv'][x['rcv']]=x['raw_rcv_record_sha256']
 for kind,filename,tag in [('vcv',f'ClinVarVCVRelease_{month}.xml.gz','VariationArchive'),('rcv',f'ClinVarRCVRelease_{month}.xml.gz','ClinVarSet')]:
  wanted=targets[kind];missing={x for x in wanted if not (evidence/(kind+'_'+x+'.xml')).exists()}
  if missing:
   found=set();n=0;t=time.monotonic()
   with gzip.open(root/'raw'/month/filename,'rb') as f:
    for _,e in E.iterparse(f,events=('end',),tag=tag,huge_tree=True):
     n+=1;accession=e.get('VariationID') if kind=='vcv' else e.find('ReferenceClinVarAssertion/ClinVarAccession').get('Acc')
     if accession in missing:
      (evidence/(kind+'_'+accession+'.xml')).write_bytes(E.tostring(e,pretty_print=True,encoding='UTF-8',xml_declaration=True));found.add(accession)
     e.clear()
     while e.getprevious() is not None:del e.getparent()[0]
     if found==missing:break
     if n%250000==0:print(json.dumps({'source':kind,'records':n,'found':len(found),'seconds':round(time.monotonic()-t)}),flush=True)
   assert found==missing,'Raw records missing'
  for accession in wanted:
   path=evidence/(kind+'_'+accession+'.xml');assert hashlib.sha256(path.read_bytes()).hexdigest()==hashes[kind][accession],'Raw evidence differs from adjudicated freeze'
 vc=sqlite3.connect(f'file:{root}/normalized/{month}/vcv.sqlite?mode=ro',uri=True);vc.row_factory=sqlite3.Row
 rc=sqlite3.connect(f'file:{root}/normalized/{month}/rcv.sqlite?mode=ro',uri=True);rc.row_factory=sqlite3.Row
 verified=[]
 for x in expected:
  row={'scv':x['scv'],'variation_id':x['variation_id'],'rcv':x['rcv']}
  for kind in ['vcv','rcv']:
   accession=x['variation_id'] if kind=='vcv' else x['rcv'];tree=E.parse(str(evidence/(kind+'_'+accession+'.xml')))
   path='./ClassifiedRecord/ClinicalAssertionList/ClinicalAssertion[ClinVarAccession/@Accession=$s]' if kind=='vcv' else './ClinVarAssertion[ClinVarAccession/@Acc=$s]'
   aa=tree.xpath(path,s=x['scv']);assert len(aa)==1;a=aa[0];acc=a.find('ClinVarAccession');cl=a.find('Classification')
   fields={'version':acc.get('Version',''),'org_id':acc.get('OrgID',''),'label':a.findtext('Classification/GermlineClassification') or '','review':a.findtext('Classification/ReviewStatus') or '','evaluated':cl.get('DateLastEvaluated','') if cl is not None else ''}
   con,table=(vc,'assertions') if kind=='vcv' else (rc,'membership');stored=con.execute('select * from '+table+' where scv=?',(x['scv'],)).fetchone();assert stored and all(stored[k]==v for k,v in fields.items()),'Raw extraction mismatch';assert fields['version']==x[kind+'_version'];row[kind]=fields
  assert all(row['vcv'][k]==row['rcv'][k] for k in ['org_id','label','review','evaluated']);verified.append(row)
 omissions=[]
 for x in extras:
  v=E.parse(str(evidence/('vcv_'+x['variation_id']+'.xml'))).getroot();assert not v.xpath('.//ClinVarAccession[@Accession=$s]',s=x['scv']);actual=len(v.xpath('./ClassifiedRecord/ClinicalAssertionList/ClinicalAssertion'));declared=int(v.get('NumberOfSubmissions'))
  assert declared==actual+1,'Unexpected source count discrepancy'
  omissions.append({'scv':x['scv'],'variation_id':x['variation_id'],'rcv':x['rcv'],'declared':declared,'actual':actual})
 vc.close();rc.close();supplement(root,month,evidence)
 report={'month':month,'passed':True,'verified_version_discrepancies':verified,'verified_missing_assertions':omissions,'raw_source_tables_modified':False,'source_manifest_sha256':hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest()}
 (out/'raw_reconciliation_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':True,'version_differences':len(verified),'missing_assertions':len(omissions)}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
