"""Describe completed research exports; catalog membership is not release authorization."""
import argparse,csv,gzip,json
from pathlib import Path
from replay import digest

UNITS={
 'review_status_cluster_intervals':'Official RCV review stratum; eligible primary-unit rate with variant-cluster bootstrap interval.',
 'source_dimension_participation':'Reported source method or organization category; primary-unit participation is deduplicated within category, overlapping across categories.',
 'principal_estimates':'One outcome definition and observation unit; the unit column identifies units versus variants.',
 'primary_units':'Eligible variant-RCV-inheritance unit.',
 'cohort_flow':'Named count or flag; prefixes distinguish variants, assertions and units. Rows are not additive.',
 'gene_observed_expected':'Gene; single-gene eligible variants form its denominator.',
 'gene_fractional_participation':'Gene; fractional weights divide a variant across annotated genes.',
 'condition_distribution':'Complete condition identifier set; variants can participate in several sets.',
 'organization_participation':'Organization; fractional weights divide each unit across qualifying organizations.',
 'organization_names':'Organization identifier and source display names.',
 'unit_assertion_ages':'Eligible primary unit; ages are days before the internal release date.',
 'discordant_pair_age_patterns':'Primary cross-band unit; age-pattern flags can overlap.',
 'age_filter_retention':'Baseline tier and filtered state; the primary denominator is held fixed.',
 'variant_features':'Eligible variant; qualifying organizations are deduplicated across units.',
 'transitions':'Historical condition/inheritance identity and snapshot pair.',
 'transition_counts':'Snapshot pair and observed transition category.',
 'three_snapshot_paths':'Historical identity observed in at least one eligible snapshot.',
 'three_snapshot_path_counts':'Three-snapshot state/comparability pattern.',
 'first_resolution_intervals':'Baseline prevalent cross-band unit; elapsed days from baseline, with null upper time for right censoring.',
 'turnbull_survival_bounds':'Elapsed day and right-continuous survival bounds conditional on fitted support masses.',
 'baseline_associations':'Snapshot pair, baseline exposure and category; losses are separate.',
 'baseline_association_effects':'Snapshot pair and baseline exposure; observed comparable-pair effect estimate.',
 'resolution_record_changes':'Observed resolved historical unit; change flags overlap.',
 'resolution_record_change_counts':'Snapshot pair and overlapping record-change flag.',
 'official_pair_report_scope':'Source conflict-report pair rows grouped by reported flag and primary-unit scope.',
 'official_replication':'Official aggregate level and observed/reconstructed flag comparison.',
}
BOOL={'observed_resolution','volume_threshold_met','expert','eligible','both_recent_pair','old_recent_pair','both_old_pair','contains_low_penetrance','contains_risk_term','same_eligible_primary_unit'}
FLOAT={'fraction','ci_lower','ci_upper','risk_difference','cluster_ci_lower','cluster_ci_upper','expected','observed_expected','excess_per_1000','eligible_fractional_weight','disputed_fractional_weight','eligible_variant_weight','T1_T2_variant_weight','survival_lower','survival_upper','days_since_baseline','resolution_fraction_observed_pairs','odds_ratio_without_zero_cell_correction'}
INTEGER={'tier','highest_tier','baseline_tier','start_tier','end_tier','numerator','denominator','assertions','organizations','missing_dates','units','records','pair_rows','eligible_units','eligible_variants','T1','T1_T2','T1_T3','T1_T2_variants','eligible_single_gene_variants','reference_covered_variants','gene_count','resolved','persistent','lost_or_noncomparable','exposed_resolved','exposed_observed','comparison_resolved','comparison_observed','baseline_units'}

def describe_column(name):
 typ='boolean' if name in BOOL else 'number' if name in FLOAT or name.endswith('_days') else 'integer' if name in INTEGER else 'text; interpret using the data dictionary'
 result={'name':name,'csv_storage':'text','logical_type':typ,'null':'empty field'}
 if name.endswith('_days') or name=='days_since_baseline':result['measurement_unit']='days'
 if name in BOOL:result['accepted_boolean_representation']='True/False or 1/0, as exported'
 return result

def run(root,allowlist=None):
 manifest=root/'source_manifest.json';source=json.loads(manifest.read_text());assert source['status']=='frozen_verified_sources'
 selected=None if allowlist is None else set(json.loads(allowlist.read_text())['files'])
 files=[]
 for partition in ['2025-09','2026-03','2026-09','history']:
  folder=root/'analysis'/partition;assert folder.is_dir(),f'Missing analysis partition {partition}'
  for path in sorted(folder.rglob('*')):
   if not path.is_file() or not (path.name.endswith('.csv') or path.name.endswith('.csv.gz') or path.suffix=='.json'):continue
   rel=str(path.relative_to(root))
   if selected is not None and rel not in selected:continue
   assert path.resolve().is_relative_to(folder.resolve()),'Export symlink leaves its analysis partition'
   name=path.name.removesuffix('.gz').removesuffix('.csv').removesuffix('.json')
   item={'path':rel,'schema_version':'1.0','snapshot_partition':partition,'bytes':path.stat().st_size,'sha256':digest(path)}
   if path.suffix=='.json':
    def invalid_number(value):raise ValueError('Nonstandard JSON number: '+value)
    value=json.loads(path.read_text(),parse_constant=invalid_number);item.update(format='JSON',observation_unit='Structured analysis or validation report; see document keys and data dictionary.',root_keys=sorted(value) if isinstance(value,dict) else None,null_convention='JSON null; false and numeric zero are distinct values.')
   else:
    with gzip.open(path,'rt',newline='') if path.suffix=='.gz' else path.open(newline='') as f:
     reader=csv.reader(f);columns=next(reader);assert len(columns)==len(set(columns)),f'Duplicate columns: {rel}';n=0
     for row in reader:
      assert len(row)==len(columns),f'Malformed row in {rel}';n+=1
    unit=UNITS.get(name,'Diagnostic/source-vocabulary record or named stratum; see the data dictionary and column names.')
    if name.startswith('variant_outcomes_'):unit='One eligible variant with highest-severity outcome for the named mode.'
    if name.startswith('by_'):unit='Named stratum; eligible-unit denominator and event counts are explicit.'
    item.update(format='gzip-compressed CSV' if path.suffix=='.gz' else 'CSV',rows=n,columns=[describe_column(c) for c in columns],observation_unit=unit,null_convention='Empty CSV field means missing or undefined, not zero. Identifiers remain text.')
   files.append(item)
 result={'catalog_schema_version':'1.0','source_manifest':'source_manifest.json','source_manifest_sha256':digest(manifest),'study_definitions':'Frozen protocol and dated addenda; DATA_DICTIONARY.md defines counting units and interpretation.','release_authorization':'Catalog inclusion does not authorize publication or automatically add files to the explicit release allowlist.','files':files}
 output=root/'export_catalog.json';part=output.with_suffix('.json.part');part.write_text(json.dumps(result,indent=2)+'\n');part.replace(output)
 print(f'Cataloged {len(files)} completed research exports')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--allowlist',type=Path);a=p.parse_args();run(a.root,a.allowlist)
