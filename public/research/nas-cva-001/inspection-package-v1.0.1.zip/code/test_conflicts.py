import unittest
from conflicts import canonical,tier,unit
class Rules(unittest.TestCase):
 def test_all_pairs(self):
  labels=['P','LP','U','LB','B']
  expected=[[0,4,2,1,1],[4,0,2,1,1],[2,2,0,3,3],[1,1,3,0,4],[1,1,3,4,0]]
  for i,a in enumerate(labels):
   for j,b in enumerate(labels):self.assertEqual(tier(a,b),expected[i][j])
 def test_compound(self):
  self.assertEqual(tier('PLP','P'),0);self.assertEqual(tier('PLP','B'),1);self.assertEqual(tier('BLB','U'),3)
 def test_special_not_reclassified(self):
  for s in ['Pathogenic, low penetrance','Established risk allele','drug response']:self.assertEqual(canonical(s),'SPECIAL')
 def test_unknown(self):self.assertEqual(canonical('some plausible pathogenic phrase'),'UNKNOWN')
 def test_vus_subtypes(self):self.assertEqual(canonical('VUS-high'),'U')
 def test_same_org_not_multiple_votes(self):self.assertFalse(unit({'1':['P','B']})['eligible'])
 def test_intra_org_excluded(self):self.assertFalse(unit({'1':['P','B'],'2':['U']})['eligible'])
 def test_duplicate_identical(self):self.assertTrue(unit({'1':['P','P'],'2':['B']})['eligible'])
 def test_highest_and_all_flags(self):
  r=unit({'1':['P'],'2':['B'],'3':['U']});self.assertEqual(r['tier'],1);self.assertEqual(r['pair_tiers'],[1,2,3])
 def test_sensitivity(self):self.assertTrue(unit({'1':['P','B'],'2':['U']},True)['eligible'])
if __name__=='__main__':unittest.main()
