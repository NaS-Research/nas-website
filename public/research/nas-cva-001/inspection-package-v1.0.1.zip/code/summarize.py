"""Generate descriptive research tables only after independent cohort validation."""
import argparse,csv,gzip,json,sqlite3,itertools
from collections import defaultdict
from pathlib import Path
from study_stats import wilson,clustered_fraction_interval

def export(path,columns,rows):
 with gzip.open(path,'wt',newline='') if str(path).endswith('.gz') else path.open('w',newline='') as f:
  w=csv.writer(f);w.writerow(columns);w.writerows(rows)
def grouped_mode_summary(con,tables):
 """One sequential source pass; exact integer counts preserve unit/variant distinctions."""
 all_modes=[r[0] for r in con.execute('SELECT DISTINCT mode FROM units')]
 modes={};primary_clusters=[]
 query="""SELECT mode,variation_id,tier,count(*) FROM units NOT INDEXED
 WHERE eligible=1 GROUP BY mode,variation_id,tier ORDER BY mode,variation_id,tier"""
 for mode,mode_rows in itertools.groupby(con.execute(query),key=lambda r:r[0]):
  unit_counts=defaultdict(int);variant_counts=defaultdict(int);variants=[]
  for vid,variant_rows in itertools.groupby(mode_rows,key=lambda r:r[1]):
   counts={int(r[2]):int(r[3]) for r in variant_rows}
   for t,k in counts.items():unit_counts[t]+=k
   best=min((t for t in counts if t>0),default=0)
   variants.append((vid,best));variant_counts[best]+=1
   if mode=='primary':
    primary_clusters.append((counts.get(1,0),counts.get(1,0)+counts.get(2,0),sum(counts.get(t,0) for t in (1,2,3)),counts.get(4,0),sum(counts.values())))
  modes[mode]={'eligible_units':sum(unit_counts.values()),'unit_tier_counts':dict(unit_counts),'eligible_variants':len(variants),'variant_tier_counts':dict(variant_counts)}
  export(tables/f'variant_outcomes_{mode}.csv.gz',['variation_id','tier'],variants)
 for mode in all_modes:
  if mode not in modes:
   modes[mode]={'eligible_units':0,'unit_tier_counts':{},'eligible_variants':0,'variant_tier_counts':{}}
   export(tables/f'variant_outcomes_{mode}.csv.gz',['variation_id','tier'],[])
 return modes,primary_clusters

def run(root,month):
 out=root/'analysis'/month
 check=json.loads((out/'independent_validation.json').read_text());assert check['passed']
 con=sqlite3.connect(f'file:{out/"units.sqlite"}?mode=ro',uri=True);con.row_factory=sqlite3.Row
 tables=out/'tables';tables.mkdir(exist_ok=True)
 summary={'month':month,'snapshot_date':json.loads(con.execute("SELECT value FROM metadata WHERE key='snapshot_date'").fetchone()[0]),'interpretation':'Finite ClinVar record census; intervals are model-based, not uncertainty in the exact counts','modes':{}}
 summary['modes'],primary_clusters=grouped_mode_summary(con,tables)
 print('Single-pass mode aggregation complete',flush=True)
 primary=summary['modes'].get('primary',{'eligible_units':0,'unit_tier_counts':{},'eligible_variants':0,'variant_tier_counts':{}})
 intervals=[]
 for ci_index,(label,tiers) in enumerate([('T1',[1]),('T1_T2',[1,2]),('T1_T3',[1,2,3]),('T4',[4])]):
  placeholders=','.join('?'*len(tiers))
  clusters=((row[ci_index],row[4]) for row in primary_clusters)
  lo,hi=clustered_fraction_interval(tuple(x) for x in clusters);k=sum(primary['unit_tier_counts'].get(t,0) for t in tiers);n=primary['eligible_units']
  intervals.append([label,'units',k,n,k/n if n else None,lo,hi,'variant-cluster bootstrap 2000'])
  k=sum(primary['variant_tier_counts'].get(t,0) for t in tiers);n=primary['eligible_variants'];lo,hi=wilson(k,n)
  intervals.append([label,'variants',k,n,k/n if n else None,lo,hi,'Wilson superpopulation model'])
 export(tables/'principal_estimates.csv',['definition','unit','numerator','denominator','fraction','ci_lower','ci_upper','interval_model'],intervals)
 for dimension,expr in [('review_status','official_rcv_review'),('expert_presence','expert'),('variant_type','variant_type'),('organization_count',"CASE WHEN organizations=2 THEN '2' WHEN organizations<=5 THEN '3-5' WHEN organizations<=10 THEN '6-10' ELSE '>10' END")]:
  data=con.execute(f"SELECT {expr} value,count(*) n,sum(tier=1) t1,sum(tier IN(1,2)) t12,sum(tier IN(1,2,3)) t123 FROM units WHERE mode='primary' AND eligible=1 GROUP BY {expr} ORDER BY n DESC").fetchall()
  export(tables/f'by_{dimension}.csv',['category','eligible_units','T1','T1_T2','T1_T3'],[tuple(x) for x in data])
 # Fixed primary baseline: removing older assertions can destroy eligibility.
 # Such attrition is never counted as disappearance or resolution of disagreement.
 retention=[]
 for mode in ['recent_2y','recent_5y']:
  query="""SELECT p.tier,CASE WHEN r.unit_key IS NULL THEN 'insufficient_qualifying_organizations'
  WHEN r.tier IN(1,2,3) THEN 'cross_band_retained'
  WHEN r.tier=4 THEN 'adjacent_only_after_filter'
  ELSE 'no_derived_disagreement_after_filter' END status,COUNT(*)
  FROM units p LEFT JOIN units r ON r.mode=? AND r.unit_key=p.unit_key
  WHERE p.mode='primary' AND p.eligible=1 GROUP BY p.tier,status"""
  retention.extend([mode,*tuple(x)] for x in con.execute(query,(mode,)))
 export(tables/'age_filter_retention.csv',['mode','baseline_tier','filtered_state','baseline_units'],retention)
 data=con.execute("SELECT level,observed,predicted,reason,count(*) FROM official_replication GROUP BY level,observed,predicted,reason ORDER BY level,observed,predicted,reason").fetchall()
 export(tables/'official_replication.csv',['level','observed_conflict','predicted_conflict','reason','records'],[tuple(x) for x in data])
 summary['official_replication_unexplained_or_unresolved']=con.execute('SELECT count(*) FROM official_replication WHERE predicted IS NULL OR observed<>predicted').fetchone()[0]
 counts=json.loads(con.execute("SELECT value FROM metadata WHERE key='counts'").fetchone()[0]);export(tables/'cohort_flow.csv',['stage_or_flag','assertions_or_units'],sorted(counts.items()))
 fields=['unit_key','variation_id','rcv','inheritance','conditions_json','organizations','tier','pair_tiers','assertions','oldest_age_days','newest_age_days','missing_dates','expert','official_rcv_label','official_rcv_review']
 export(tables/'primary_units.csv.gz',fields,(tuple(x) for x in con.execute('SELECT '+','.join(fields)+" FROM units WHERE mode='primary' AND eligible=1 ORDER BY unit_key")))
 (out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');con.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
