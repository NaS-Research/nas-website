"""Freeze a portable source manifest only after every required input is verified."""
import argparse,datetime,gzip,json
from pathlib import Path
from lxml import etree
from replay import digest

def freeze(root):
 output=root/'source_manifest.json';assert not output.exists(),'Preserve existing source freezes; do not overwrite'
 required=[];releases={};schemas=set()
 for month in ['2025-09','2026-03','2026-09']:
  for family in ['VCV','RCV']:
   rel=Path('raw')/month/f'ClinVar{family}Release_{month}.xml.gz';required.append(rel)
   with gzip.open(root/rel,'rb') as stream:
    _,element=next(iter(etree.iterparse(stream,events=('start',))));release=dict(element.attrib)
   schema=release['{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation'].rsplit('/',1)[-1];schemas.add(Path('raw/documentation')/schema);releases[str(rel)]=release
  for stem in ['variant_summary','submission_summary','summary_of_conflicting_interpretations']:required.append(Path('raw')/month/f'{stem}_{month}.txt.gz')
 required += [Path('raw/2026-09/clinvar_20260829.vcf.gz'),*sorted(schemas)]
 required += [Path('raw/documentation')/(name+'.html') for name in ['ftp-primer','classification-definitions','review-status','ncbi-policies']]
 sources=[]
 for rel in required:
  path=root/rel;provenance=json.loads(path.with_name(path.name+'.provenance.json').read_text());assert provenance['status']=='verified download'
  assert provenance['bytes']==path.stat().st_size and digest(path)==provenance['sha256'],f'Frozen source changed: {rel}'
  path.chmod(0o444)
  print(json.dumps({'verified_source':str(rel),'bytes':provenance['bytes']}),flush=True)
  sources.append({'relative_path':str(rel),'url':provenance['url'],'bytes':provenance['bytes'],'sha256':provenance['sha256'],'provenance':provenance,'release_metadata':releases.get(str(rel))})
 data={'schema_version':'1.0','status':'frozen_verified_sources','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'snapshot_months':['2025-09','2026-03','2026-09'],'archive_caveat':'Historical releases are the archives as retrieved; original-distribution byte identity is not independently established.','sources':sources}
 output.write_text(json.dumps(data,indent=2)+'\n');output.chmod(0o444)
 print(f'Frozen {len(sources)} verified sources')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();freeze(a.root)
