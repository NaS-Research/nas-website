import csv,gzip,hashlib,json,os,shutil,sqlite3,tempfile,unittest
from pathlib import Path
from normalize_vcv import SCHEMA
from build_units import run
from independent_counts import run as independent
from summarize import run as summarize
from exploratory import run as explore
from source_audit import select as select_cases
from verify_snapshots import run as verify_snapshots
from history import run as historical
from reconcile_sources import identifier_inventory
from history_associations import run as associations
from resolution_changes import run as resolution_changes
from validate_tabular import run as validate_tabular

def insert(con,table,values):
 names=[x[1] for x in con.execute('PRAGMA table_info('+table+')')]
 con.execute('INSERT INTO '+table+' VALUES('+','.join('?'*len(names))+')',[values.get(n,'') for n in names])
class Integration(unittest.TestCase):
 def test_source_to_units_and_independent_sql(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   root=Path(temp);d=root/'normalized/2026-09';d.mkdir(parents=True)
   v=sqlite3.connect(d/'vcv.sqlite');v.executescript(SCHEMA)
   r=sqlite3.connect(d/'rcv.sqlite');r.executescript('CREATE TABLE rcvs(rcv TEXT PRIMARY KEY,version TEXT,variation_id TEXT,status TEXT,conditions_json TEXT,official_label TEXT,official_review TEXT);CREATE TABLE membership(scv TEXT,version TEXT,rcv TEXT,variation_id TEXT,label TEXT,review TEXT,evaluated TEXT,org_id TEXT,PRIMARY KEY(scv,rcv));CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);')
   v.execute('INSERT INTO metadata VALUES(?,?)',('release',json.dumps({'ReleaseDate':'2026-08-29'})));r.execute('INSERT INTO metadata VALUES(?,?)',('release',json.dumps({'Dated':'2026-08-29'})))
   v.execute('INSERT INTO metadata VALUES(?,?)',('schema_invalid','0'));r.execute('INSERT INTO metadata VALUES(?,?)',('schema_invalid','0'))
   cases=[['Pathogenic','Benign'],['Pathogenic','Uncertain significance'],['Pathogenic','Benign'],['Pathogenic','Benign','Uncertain significance'],['Pathogenic','Likely pathogenic'],['Uncertain significance','Likely benign'],['Pathogenic','Pathogenic'],['Pathogenic','Benign'],['Pathogenic/Likely pathogenic','Likely benign'],['Pathogenic','Pathogenic','Benign']]
   for i,labels in enumerate(cases,1):
    vid=str(i);rcv='RCV'+vid;cond=[{'DB':'MedGen','ID':'SYN'+vid,'name':'not provided' if i==8 else 'Synthetic disease '+vid}]
    insert(v,'variants',dict(variation_id=vid,vcv='VCV'+vid,version='1',record_type='classified',status='current',species='Homo sapiens',direct_simple=1,genes_json='[]',coordinates_json='[]',variant_type='single nucleotide variant'))
    insert(v,'rcvs',dict(rcv=rcv,variation_id=vid,version='1',conditions_json=json.dumps(cond),official_label=''))
    insert(r,'rcvs',dict(rcv=rcv,variation_id=vid,version='1',conditions_json=json.dumps([{'ids':[{'DB':x['DB'],'ID':x['ID']}],'names':[x['name']]} for x in cond]),official_label=''))
    for j,label in enumerate(labels):
     scv=f'SCV{i}_{j}';org=str(j if i not in (4,10) else (0 if j<2 else 1));inheritance='["AD"]' if i==3 and j==0 else '["AR"]' if i==3 else '[]'
     a=dict(scv=scv,version='1',variation_id=vid,org_id=org,org_type=('research' if i==10 and j==1 else 'laboratory'),class_type='germline',label=label,review='criteria provided, single submitter',status='current',evaluated='2025-01-01',conditions_json='{}',submitted_conditions_json='[]',inheritance_json=inheritance,origins_json='["germline"]',methods_json='["clinical testing"]',direct_simple=1)
     insert(v,'assertions',a);insert(r,'membership',dict(a,rcv=rcv))
   v.commit();r.commit();v.close();r.close();verify_snapshots(root,'2026-09');identifier_inventory(root,'2026-09');run(root,'2026-09');independent(root,'2026-09')
   x=sqlite3.connect(root/'analysis/2026-09/units.sqlite')
   observed=dict(x.execute("SELECT variation_id,tier FROM units WHERE mode='primary' AND eligible=1"))
   self.assertEqual(observed,{'1':1,'2':2,'5':4,'6':3,'7':0,'9':1,'10':1})
   self.assertTrue(json.loads((root/'analysis/2026-09/independent_validation.json').read_text())['passed']);x.close()
   summarize(root,'2026-09');explore(root,'2026-09');select_cases(root,'2026-09')
   sample=json.loads((root/'analysis/2026-09/validation_sample.json').read_text())
   self.assertTrue(any(c['variation_id']=='8' and c['stratum']=='excluded' for c in sample['cases']))
   report=json.loads((root/'analysis/2026-09/exploratory_summary.json').read_text())
   self.assertAlmostEqual(report['organization']['eligible']['total_weight'],7)
   # Matched tabular fixture independently exercises the full reconciliation SQL.
   raw=root/'raw/2026-09';raw.mkdir(parents=True)
   source=sqlite3.connect(root/'normalized/2026-09/vcv.sqlite');source.row_factory=sqlite3.Row
   def tab(stem,header,records):
    path=raw/(stem+'_2026-09.txt.gz')
    with gzip.open(path,'wt',newline='') as f:
     w=csv.writer(f,delimiter='\t');w.writerow(header);w.writerows(records)
    path.with_name(path.name+'.provenance.json').write_text(json.dumps({'status':'verified download','bytes':path.stat().st_size}))
   tab('submission_summary',['#VariationID','SCV','ClinicalSignificance','ReviewStatus','DateLastEvaluated','ContributesToAggregateClassification'],[(r['variation_id'],r['scv']+'.'+r['version'],r['label'],r['review'],r['evaluated'],r['contributes']) for r in source.execute('SELECT * FROM assertions')])
   tab('variant_summary',['#AlleleID','VariationID','Assembly','ClinicalSignificance','ReviewStatus'],[(r['allele_id'],r['variation_id'],'GRCh38',r['official_label'],r['official_review']) for r in source.execute('SELECT * FROM variants')])
   tab('summary_of_conflicting_interpretations',['#Gene_Symbol','NCBI_Variation_ID','Submitter1_SCV','Submitter2_SCV','Submitter1_ClinSig','Submitter2_ClinSig','Conflict_Reported'],[['SYN','1','SCV1_0','SCV1_1','Pathogenic','Benign','yes']]);source.close()
   validate_tabular(root,'2026-09');self.assertTrue(json.loads((root/'analysis/2026-09/tabular_validation.json').read_text())['automated_exact_checks_passed'])
   # Three deliberately constructed historical states exercise identity and attrition.
   for month,date in [('2025-09','2025-08-31'),('2026-03','2026-03-01')]:
    shutil.copytree(root/'normalized/2026-09',root/'normalized'/month)
    shutil.copytree(root/'analysis/2026-09',root/'analysis'/month)
    db=sqlite3.connect(root/'analysis'/month/'units.sqlite');db.execute("UPDATE metadata SET value=? WHERE key='snapshot_date'",(json.dumps(date),));db.commit();db.close()
   mid=sqlite3.connect(root/'analysis/2026-03/units.sqlite');mid.execute("UPDATE units SET eligible=0 WHERE mode='primary' AND variation_id='1'");mid.commit();mid.close()
   end=sqlite3.connect(root/'analysis/2026-09/units.sqlite');end.execute("UPDATE units SET tier=0 WHERE mode='primary' AND variation_id='1'");end.commit();end.close()
   # Synthetic normalized fixtures provide complete-coverage evidence here; raw-count extraction is exercised independently in test_source_count_coverage.
   (root/'source_manifest.json').write_text('{}')
   manifest_sha=hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest()
   for month in ['2025-09','2026-03','2026-09']:
    (root/'analysis'/month/'source_assertion_count_validation.json').write_text(json.dumps({'month':month,'source_manifest_sha256':manifest_sha,'raw_normalized_counts_agree':True,'count_discrepancies':[]}))
   historical(root);associations(root);resolution_changes(root)
   with gzip.open(root/'analysis/history/three_snapshot_paths.csv.gz','rt') as f:paths=list(csv.DictReader(f))
   path=next(r for r in paths if r['variation_id']=='1');self.assertEqual(path['2026-03'],'ineligible');self.assertEqual(path['2026-09'],'no_derived_disagreement')
   with gzip.open(root/'analysis/history/first_resolution_intervals.csv.gz','rt') as f:intervals=list(csv.DictReader(f))
   interval=next(r for r in intervals if r['variation_id']=='1');self.assertEqual(interval['last_cross_band_days'],'0');self.assertEqual(interval['observed_resolution'],'True')
   with (root/'analysis/history/baseline_associations.csv').open() as f:association_rows=list(csv.DictReader(f))
   row=next(r for r in association_rows if r['start_month']=='2025-09' and r['end_month']=='2026-03' and r['exposure']=='expert');self.assertEqual(row['lost_or_noncomparable'],'1')
   # An apparent resolution at a source-incomplete endpoint must not be an event.
   ip=root/'analysis/2026-09/source_identifier_reconciliation.json';ir=json.loads(ip.read_text());ir['rcv_only_records']=[{'variation_id':'1'}];ip.write_text(json.dumps(ir));historical(root)
   with gzip.open(root/'analysis/history/first_resolution_intervals.csv.gz','rt') as f:changed=list(csv.DictReader(f))
   affected=next(r for r in changed if r['variation_id']=='1');self.assertEqual(affected['observed_resolution'],'False');self.assertEqual(affected['status'],'non_comparable')
if __name__=='__main__':unittest.main()
