import csv,gzip,hashlib,json,os,sqlite3,tempfile,unittest
from pathlib import Path
from source_assertion_counts import run as audit
from reconcile_sources import coverage_issues
from history import run as historical
from tabular_discrepancy_context import run as discrepancy_context

class SourceCounts(unittest.TestCase):
 def fixture(self,root,declared=3,normalized=2):
  month="2025-09";raw=root/"raw"/month;raw.mkdir(parents=True);norm=root/"normalized"/month;norm.mkdir(parents=True);(root/"analysis"/month).mkdir(parents=True)
  source=raw/("ClinVarVCVRelease_"+month+".xml.gz")
  xml='<Release><VariationArchive VariationID="1" RecordType="classified" NumberOfSubmissions="'+str(declared)+'"><ClassifiedRecord><ClinicalAssertionList><ClinicalAssertion/><ClinicalAssertion/></ClinicalAssertionList></ClassifiedRecord></VariationArchive><VariationArchive VariationID="2" RecordType="included" NumberOfSubmissions="99"><IncludedRecord/></VariationArchive></Release>'
  with gzip.open(source,"wt") as f:f.write(xml)
  (root/"source_manifest.json").write_text(json.dumps({"sources":[{"relative_path":str(source.relative_to(root)),"bytes":source.stat().st_size,"sha256":hashlib.sha256(source.read_bytes()).hexdigest()}]}))
  c=sqlite3.connect(norm/"vcv.sqlite");c.execute("CREATE TABLE assertions(scv TEXT,variation_id TEXT)")
  c.executemany("INSERT INTO assertions VALUES(?,?)",[(str(x),"1") for x in range(normalized)]);c.commit();c.close()
  return month
 def test_raw_count_difference_is_retained_without_inventing_assertions(self):
  with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as temp:
   r=Path(temp);m=self.fixture(r);audit(r,m);report=json.loads((r/"analysis"/m/"source_assertion_count_validation.json").read_text())
   self.assertEqual(report["records_scanned"],2);self.assertEqual(report["classified_records"],1)
   self.assertEqual(report["present_assertion_elements"],2);self.assertEqual(report["declared_submissions_total"],3)
   self.assertEqual(report["count_discrepancies"],[{"variation_id":"1","declared":3,"actual":2}])
   self.assertTrue(report["raw_normalized_counts_agree"]);self.assertFalse(report["all_declared_counts_equal_present_elements"])
 def test_equal_declared_counts_have_no_uncertainty_flag(self):
  with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as temp:
   r=Path(temp);m=self.fixture(r,declared=2);audit(r,m);report=json.loads((r/"analysis"/m/"source_assertion_count_validation.json").read_text())
   self.assertEqual(report["count_discrepancies"],[]);self.assertTrue(report["all_declared_counts_equal_present_elements"])
 def test_extraction_count_mismatch_fails_closed(self):
  with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as temp:
   r=Path(temp);m=self.fixture(r,normalized=1)
   with self.assertRaisesRegex(AssertionError,"totals differ"):audit(r,m)

class Coverage(unittest.TestCase):
 def test_declared_uncertainty_distinct_from_proven_source_absence(self):
  report={"raw_normalized_counts_agree":True,"count_discrepancies":[{"variation_id":"1"},{"variation_id":"2"}]}
  issues=coverage_issues({"rcv_only_records":[{"variation_id":"2"}]},report)
  self.assertEqual(issues,{"1":"unresolved_source_assertion_count","2":"incomplete_source_assertion_coverage"})
 def test_invalid_extraction_cannot_be_adjudicated(self):
  with self.assertRaises(AssertionError):coverage_issues({},{"raw_normalized_counts_agree":False,"count_discrepancies":[]})
 def test_declared_count_uncertainty_prevents_observed_t0_becoming_resolution(self):
  with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as temp:
   r=Path(temp);(r/"source_manifest.json").write_text("{}");manifest_sha=hashlib.sha256((r/"source_manifest.json").read_bytes()).hexdigest()
   for month,date,tier in [("2025-09","2025-08-31",1),("2026-03","2026-03-02",0),("2026-09","2026-08-29",0)]:
    a=r/"analysis"/month;a.mkdir(parents=True);n=r/"normalized"/month;n.mkdir(parents=True)
    (a/"independent_validation.json").write_text('{"passed":true}')
    (a/"source_identifier_reconciliation.json").write_text("{}")
    (a/"source_assertion_count_validation.json").write_text(json.dumps({"month":month,"source_manifest_sha256":manifest_sha,"raw_normalized_counts_agree":True,"count_discrepancies":[{"variation_id":"1","declared":3,"actual":2}] if month=="2025-09" else []}))
    c=sqlite3.connect(a/"units.sqlite");c.execute("CREATE TABLE units(mode TEXT,unit_key TEXT,variation_id TEXT,conditions_json TEXT,inheritance TEXT,tier INTEGER,expert INTEGER,eligible INTEGER)")
    c.execute("INSERT INTO units VALUES(?,?,?,?,?,?,?,?)",("primary","1|RCV1|[]","1",'[{"DB":"MedGen","ID":"C1"}]',"[]",tier,0,1));c.execute("CREATE TABLE metadata(key TEXT,value TEXT)");c.execute("INSERT INTO metadata VALUES('snapshot_date',?)",(json.dumps(date),));c.commit();c.close()
    c=sqlite3.connect(n/"vcv.sqlite");c.execute("CREATE TABLE variants(variation_id TEXT,status TEXT,allele_id TEXT,spdi TEXT)");c.execute("INSERT INTO variants VALUES('1','current','1','S')")
    c.execute("CREATE TABLE lineage(variation_id TEXT,replaced_by TEXT,replaced_records TEXT)");c.execute("INSERT INTO lineage VALUES('1','[]','[]')");c.commit();c.close()
   historical(r);s=json.loads((r/"analysis/history/history_summary.json").read_text())
   self.assertEqual(s["baseline_cross_band_units"],1);self.assertEqual(s["observed_first_resolutions"],0);self.assertEqual(s["lost_or_noncomparable"],1)
   with gzip.open(r/"analysis/history/transitions.csv.gz","rt",newline="") as f:records=list(csv.DictReader(f))
   first=[x for x in records if x["start_month"]=="2025-09"]
   self.assertTrue(all(x["transition"]=="non_comparable" and x["comparability"]=="unresolved_source_assertion_count" for x in first))

class DiscrepancyScope(unittest.TestCase):
 def test_nonqualifying_scv_still_identifies_other_eligible_unit_at_its_variant(self):
  with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as temp:
   r=Path(temp);m="2026-09";a=r/"analysis"/m;a.mkdir(parents=True);n=r/"normalized"/m;n.mkdir(parents=True)
   (a/"tabular_validation.json").write_text('{"checks":{"submission_label_mismatch":1}}')
   with gzip.open(a/"submission_label_mismatch.csv.gz","wt",newline="") as f:
    w=csv.writer(f);w.writerow(["scv","tabular_value","xml_value"]);w.writerow(["S1","Pathogenic","Affects"])
   fields=["scv","version","variation_id","class_type","status","org_id","org_type","label","review","evaluated","contributes","direct_simple","conditions_json","inheritance_json","origins_json","methods_json"]
   values=["S1","1","1","germline","current","1","resource","Affects","no assertion criteria provided","","false","1","{}","[]","[]","[]"]
   c=sqlite3.connect(n/"vcv.sqlite");c.execute("CREATE TABLE assertions("+",".join(x+" TEXT" for x in fields)+")");c.execute("INSERT INTO assertions VALUES("+",".join("?" for _ in fields)+")",values);c.commit();c.close()
   c=sqlite3.connect(a/"units.sqlite");c.execute("CREATE TABLE units(mode TEXT,unit_key TEXT,variation_id TEXT,tier INTEGER,eligible INTEGER)");c.execute("INSERT INTO units VALUES('primary','U1','1',3,1)")
   c.execute("CREATE TABLE unit_assertions(mode TEXT,unit_key TEXT,scv TEXT)");c.execute("INSERT INTO unit_assertions VALUES('primary','U1','S2')");c.commit();c.close()
   discrepancy_context(r,m);s=json.loads((a/"tabular_discrepancy_context.json").read_text())["summary"]["submission_label_mismatch"]
   self.assertEqual(s["eligible_primary_units_at_implicated_variants"],1);self.assertEqual(s["eligible_primary_units_with_retained_affected_scvs"],0)
if __name__=="__main__":unittest.main()
