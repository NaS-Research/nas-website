"""Overlapping record changes accompanying observed cross-band resolution."""
import argparse,csv,gzip,json,sqlite3
from collections import Counter,defaultdict
from pathlib import Path
from conflicts import canonical
from history import key
from summarize import export

def changes(before,after,end_source,explicit_deleted):
 """before/after are qualifying assertions; end_source is all end-snapshot SCVs."""
 b={r['scv']:r for r in before};a={r['scv']:r for r in after};shared=set(b)&set(a)
 absent=set(b)-set(end_source)
 label_changed={s for s in b if s in end_source and canonical(b[s]['label'])!=canonical(end_source[s]['label'])}
 nonqualifying=(set(b)&set(end_source))-set(a)
 return {'baseline_qualifying_scvs':len(b),'endpoint_qualifying_scvs':len(a),
 'retained_qualifying_scvs':len(shared),'baseline_scv_label_revision':len(label_changed),
 'baseline_scv_absent_endpoint':len(absent),'baseline_scv_explicitly_deleted':len(absent&explicit_deleted),
 'baseline_scv_present_not_qualifying_same_unit':len(nonqualifying),'newly_qualifying_scvs':len(set(a)-set(b)),
 'baseline_scv_review_changed':sum(b[s]['review']!=end_source[s]['review'] for s in set(b)&set(end_source)),
 'baseline_scv_evaluation_date_changed':sum(b[s]['evaluated']!=end_source[s]['evaluated'] for s in set(b)&set(end_source)),
 'qualifying_organizations_removed':len({r['org_id'] for r in before}-{r['org_id'] for r in after}),
 'qualifying_organizations_added':len({r['org_id'] for r in after}-{r['org_id'] for r in before})}
def run(root):
 out=root/'analysis/history';records=[];summaries=defaultdict(Counter);connections={};sources={};deleted={}
 for month in ['2025-09','2026-03','2026-09']:
  c=sqlite3.connect(f'file:{root/"analysis"/month/"units.sqlite"}?mode=ro',uri=True);c.row_factory=sqlite3.Row;connections[month]=c
  s=sqlite3.connect(f'file:{root/"normalized"/month/"vcv.sqlite"}?mode=ro',uri=True);s.row_factory=sqlite3.Row;sources[month]=s
  deleted[month]={r[0] for r in s.execute('SELECT scv FROM deleted_scvs')}
 with gzip.open(out/'transitions.csv.gz','rt',newline='') as f:
  for row in csv.DictReader(f):
   if row['transition']!='cross_band_resolved':continue
   start,end=row['start_month'],row['end_month'];identity=tuple(row[x] for x in ['variation_id','condition_key','inheritance']);groups=[]
   for month in (start,end):
    db=connections[month];units=[r for r in db.execute("SELECT * FROM units WHERE mode='primary' AND eligible=1 AND variation_id=?",(identity[0],)) if key(r)==identity]
    assert len(units)==1,'Resolved transitions must have one unambiguous eligible unit at each end'
    groups.append([dict(r) for r in db.execute("SELECT scv,org_id,label,review,evaluated FROM unit_assertions WHERE mode='primary' AND unit_key=?",(units[0]['unit_key'],))])
   # Fetch baseline SCVs globally, so remapping is not mistaken for deletion.
   ids=[r['scv'] for r in groups[0]];end_source={}
   for offset in range(0,len(ids),500):
    batch=ids[offset:offset+500]
    for r in sources[end].execute('SELECT scv,label,review,evaluated FROM assertions WHERE scv IN ('+','.join('?'*len(batch))+')',batch):end_source[r['scv']]=dict(r)
   result=changes(*groups,end_source,deleted[end]);records.append(dict(start_month=start,end_month=end,variation_id=identity[0],condition_key=identity[1],inheritance=identity[2],**result))
   summary=summaries[(start,end)];summary['resolved_units']+=1
   for field,value in result.items():
    if field not in {'baseline_qualifying_scvs','endpoint_qualifying_scvs','retained_qualifying_scvs'}:summary['units_with_'+field]+=int(value>0)
 fields=['start_month','end_month','variation_id','condition_key','inheritance',*changes([],[],{},set())]
 export(out/'resolution_record_changes.csv.gz',fields,([r[f] for f in fields] for r in records))
 export(out/'resolution_record_change_counts.csv',['start_month','end_month','flag','units'],([*interval,flag,n] for interval,c in sorted(summaries.items()) for flag,n in sorted(c.items())))
 (out/'resolution_changes_interpretation.txt').write_text('Overlapping descriptive changes accompanying observed cross-band resolution. Counts do not establish a unique or causal mechanism. A source SCV absent at endpoint is distinguished from a present record no longer qualifying for the same unit; explicit deletion is counted only when listed in the endpoint DeletedSCV records. Newly qualifying SCVs need not be newly created. Changes to review status, condition membership, inheritance, organization consistency or other eligibility fields can alter inclusion. Historical snapshots cannot reveal the exact order or timing of these changes.\n')
 for db in [*connections.values(),*sources.values()]:db.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();run(a.root)
