import datetime,unittest
from history_associations import update_category,cluster_difference
class Associations(unittest.TestCase):
 def test_unknown_not_unexposed(self):self.assertEqual(update_category(['','2020-01-01'],datetime.date(2026,1,1)),'unknown')
 def test_recent_present_despite_missing(self):self.assertEqual(update_category(['','2025-12-01'],datetime.date(2026,1,1)),'recent')
 def test_old_all_known(self):self.assertEqual(update_category(['2020-01-01'],datetime.date(2026,1,1)),'older')
 def test_cluster_difference(self):self.assertEqual(cluster_difference([(1,2,0,2)]*10,reps=20),(.5,.5))
class BootstrapOrdering(unittest.TestCase):
 def test_permutation_invariance(self):
  x=[(1,2,0,1),(0,1,1,2),(2,2,1,3),(1,1,0,2)]
  self.assertEqual(cluster_difference(x,reps=200),cluster_difference(list(reversed(x)),reps=200))
if __name__=='__main__':unittest.main()
