"""Volume-aware descriptive gene, condition, submitter and assertion-age analyses."""
import argparse,itertools,json,sqlite3
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from summarize import export
from conflicts import tier

def type_group(raw,coordinates):
 s=raw.lower()
 if s in {'single nucleotide variant','snv'}:return 'SNV'
 if any(x in s for x in ['copy number','inversion','translocation','structural']):return 'CNV_structural'
 if s in {'deletion','insertion','duplication','indel'}:
  for c in coordinates:
   ref=c.get('referenceAlleleVCF','');alt=c.get('alternateAlleleVCF','')
   if ref and alt and set((ref+alt).upper())<=set('ACGTN'):
    delta=abs(len(alt)-len(ref))
    if 1<=delta<50:return 'short_indel'
    if delta>=50:return 'CNV_structural'
   try:
    if abs(int(c.get('variantLength',0)))>=50:return 'CNV_structural'
   except (TypeError,ValueError):pass
 return 'other'
def org_bin(n):return '2' if n==2 else '3-5' if n<=5 else '6-10' if n<=10 else '>10'
def age_bin(days):return 'unknown' if days is None else '<2y' if days<2*365.25 else '2-5y' if days<=5*365.25 else '>5y'
def projections(s):
 org,typ,expert,age=s
 return [s,(org,typ,expert),(org,expert),(expert,)]
def expected_for_gene(g,cells,global_levels,gene_levels):
 expected=0.;covered=0
 for s,(n,events) in cells.items():
  for level,k in enumerate(projections(s)):
   total=global_levels[level][k];own=gene_levels[level][(g,k)]
   dn=total[0]-own[0];de=total[1]-own[1]
   if dn>=50:
    expected+=n*de/dn;covered+=n;break
 total_n=sum(x[0] for x in cells.values())
 return (expected if covered==total_n else None),covered

def run(root,month):
 out=root/'analysis'/month;assert json.loads((out/'independent_validation.json').read_text())['passed']
 db=sqlite3.connect(f'file:{out/"units.sqlite"}?mode=ro',uri=True);db.row_factory=sqlite3.Row
 db.execute('ATTACH DATABASE ? AS src',(str(root/'normalized'/month/'vcv.sqlite'),))
 tables=out/'tables';tables.mkdir(exist_ok=True)
 gene_cells=defaultdict(lambda:defaultdict(lambda:[0,0]));gene_names={};gl=[defaultdict(lambda:[0,0]) for _ in range(4)];gg=[defaultdict(lambda:[0,0]) for _ in range(4)]
 condition_counts=defaultdict(lambda:[0,0,0.,0.]);condition_names={};gene_fractional=defaultdict(lambda:[0.,0.]);feature_rows=[]
 orgcounts=iter(db.execute("SELECT a.variation_id,count(DISTINCT a.org_id) n FROM unit_assertions a JOIN units u ON u.mode=a.mode AND u.unit_key=a.unit_key WHERE a.mode='primary' AND u.eligible=1 GROUP BY a.variation_id ORDER BY a.variation_id"));orgrow=next(orgcounts,None)
 units=db.execute("SELECT u.*,v.coordinates_json FROM units u JOIN src.variants v USING(variation_id) WHERE u.mode='primary' AND u.eligible=1 ORDER BY u.variation_id")
 for vid,iterator in itertools.groupby(units,key=lambda x:x['variation_id']):
  rows=list(iterator);assert orgrow is not None and orgrow['variation_id']==vid
  norg=orgrow['n'];orgrow=next(orgcounts,None);best=min((x['tier'] for x in rows if x['tier']>0),default=0);event=int(best in (1,2))
  genes={g['GeneID']:g.get('Symbol','') for g in json.loads(rows[0]['genes_json']) if g.get('GeneID')}
  expert=int(any(x['expert'] for x in rows));oldest=max((x['oldest_age_days'] for x in rows if x['oldest_age_days'] is not None),default=None)
  typ=type_group(rows[0]['variant_type'],json.loads(rows[0]['coordinates_json']));s=(org_bin(norg),typ,expert,age_bin(oldest))
  feature_rows.append([vid,best,norg,typ,expert,oldest,len(genes),'|'.join(sorted(genes))])
  if genes:
   for g,name in genes.items():gene_names[g]=name;gene_fractional[g][0]+=1/len(genes);gene_fractional[g][1]+=event/len(genes)
  if len(genes)==1:
   g=next(iter(genes));gene_cells[g][s][0]+=1;gene_cells[g][s][1]+=event
   for level,k in enumerate(projections(s)):
    gl[level][k][0]+=1;gl[level][k][1]+=event;gg[level][(g,k)][0]+=1;gg[level][(g,k)][1]+=event
  sets={};disputed=set()
  for row in rows:
   cc=json.loads(row['conditions_json']);key='|'.join(sorted(x['DB']+':'+x['ID'] for x in cc));sets[key]=cc
   if row['tier'] in (1,2):disputed.add(key)
  for key,cc in sets.items():
   condition_names[key]='; '.join(x.get('name','') for x in cc);z=condition_counts[key];z[0]+=1;z[1]+=int(key in disputed);z[2]+=1/len(sets)
   if key in disputed:z[3]+=1/len(disputed)
 export(tables/'variant_features.csv.gz',['variation_id','highest_tier','organizations','variant_group','expert','oldest_evaluation_age_days','gene_count','gene_ids'],feature_rows)
 gene_rows=[]
 for g,cells in gene_cells.items():
  n=sum(x[0] for x in cells.values());observed=sum(x[1] for x in cells.values());expected,covered=expected_for_gene(g,cells,gl,gg)
  gene_rows.append([g,gene_names[g],n,observed,expected,observed/expected if expected else None,(observed-expected)*1000/n if expected is not None else None,n>=30,covered])
 export(tables/'gene_observed_expected.csv',['gene_id','symbol','eligible_single_gene_variants','T1_T2_variants','expected','observed_expected','excess_per_1000','volume_threshold_met','reference_covered_variants'],sorted(gene_rows,key=lambda x:(-x[2],x[0])))
 export(tables/'gene_fractional_participation.csv',['gene_id','symbol','eligible_variant_weight','T1_T2_variant_weight'],[[g,gene_names[g],*v] for g,v in sorted(gene_fractional.items())])
 export(tables/'condition_distribution.csv',['condition_key','names','eligible_variants','T1_T2_variants','eligible_fractional_weight','disputed_fractional_weight'],[[k,condition_names[k],*v] for k,v in sorted(condition_counts.items(),key=lambda x:(-x[1][0],x[0]))])
 org_sql="""WITH participation AS (SELECT a.org_id,group_concat(DISTINCT a.org_type) org_type,u.unit_key,u.tier,u.organizations FROM unit_assertions a JOIN units u ON u.mode=a.mode AND u.unit_key=a.unit_key WHERE a.mode='primary' AND u.eligible=1 GROUP BY a.org_id,u.unit_key,u.tier,u.organizations) SELECT org_id,group_concat(DISTINCT org_type),count(*),sum(tier IN(1,2)),sum(1.0/organizations),sum(CASE WHEN tier IN(1,2) THEN 1.0/organizations ELSE 0 END) FROM participation GROUP BY org_id ORDER BY count(*) DESC,org_id"""
 org_rows=[tuple(x) for x in db.execute(org_sql)]
 export(tables/'organization_participation.csv',['organization_id','reported_types','eligible_units','T1_T2_units','eligible_fractional_weight','disputed_fractional_weight'],org_rows)
 org_names=db.execute('SELECT org_id,group_concat(DISTINCT org_name) FROM src.assertions WHERE org_id<>\'\' GROUP BY org_id ORDER BY org_id')
 export(tables/'organization_names.csv',['organization_id','source_names'],(tuple(x) for x in org_names))
 ages=db.execute("SELECT u.unit_key,u.tier,u.oldest_age_days,u.newest_age_days,u.missing_dates,u.assertions FROM units u WHERE mode='primary' AND eligible=1 ORDER BY unit_key")
 export(tables/'unit_assertion_ages.csv.gz',['unit_key','tier','oldest_age_days','newest_age_days','missing_dates','assertions'],(tuple(x) for x in ages))
 patterns=Counter();pair_rows=[]
 aq=db.execute("SELECT a.unit_key,a.org_id,a.canonical,a.age_days,a.date_status FROM unit_assertions a JOIN units u ON u.mode=a.mode AND u.unit_key=a.unit_key WHERE a.mode='primary' AND u.eligible=1 AND u.tier IN(1,2,3) ORDER BY a.unit_key")
 for uk,iterator in itertools.groupby(aq,key=lambda x:x['unit_key']):
  aa=list(iterator);recent=False;old_recent=False;old_old=False
  for a,b in itertools.combinations(aa,2):
   if a['org_id']==b['org_id'] or tier(a['canonical'],b['canonical']) not in (1,2,3):continue
   x,y=a['age_days'],b['age_days']
   if x is None or y is None:continue
   recent|=x<=2*365.25 and y<=2*365.25
   old_recent|=min(x,y)<=2*365.25 and max(x,y)>5*365.25
   old_old|=min(x,y)>5*365.25
  patterns['cross_band_units']+=1;patterns['recent_discordant_pair']+=recent;patterns['old_recent_discordant_pair']+=old_recent;patterns['old_old_discordant_pair']+=old_old
  pair_rows.append([uk,recent,old_recent,old_old])
 export(tables/'discordant_pair_age_patterns.csv.gz',['unit_key','both_recent_pair','old_recent_pair','both_old_pair'],pair_rows)
 def concentration(weights):
  weights=sorted([float(x) for x in weights if x>0],reverse=True);total=sum(weights)
  return {'total_weight':total,'HHI':sum((x/total)**2 for x in weights) if total else None,'top_5_share':sum(weights[:5])/total if total else None,'top_10_share':sum(weights[:10])/total if total else None}
 report={'gene':{k:concentration(v[i] for v in gene_fractional.values()) for k,i in [('eligible',0),('T1_T2',1)]},'condition':{k:concentration(v[i] for v in condition_counts.values()) for k,i in [('eligible',2),('T1_T2',3)]},'organization':{k:concentration(v[i] for v in org_rows) for k,i in [('eligible',4),('T1_T2',5)]},'assertion_age_pair_patterns':dict(patterns),'interpretation':'Descriptive exploratory comparisons; organization participation does not identify responsibility or error. Gene expected counts are leave-one-gene-out standardized estimates, not clinical risk.'}
 (out/'exploratory_summary.json').write_text(json.dumps(report,indent=2)+'\n');db.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
