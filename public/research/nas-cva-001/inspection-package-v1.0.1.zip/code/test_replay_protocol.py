import hashlib,json,os,tempfile,unittest
from pathlib import Path
from replay import verify_protocol
class ProtocolFreeze(unittest.TestCase):
 def test_both_formats_and_changed_source_fail(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   root=Path(temp)
   for name in ('v1','addendum'):
    d=root/name;d.mkdir();f=d/'addendum.md';f.write_text('synthetic frozen rule')
    sha=hashlib.sha256(f.read_bytes()).hexdigest()
    freeze={'files':{'addendum.md':sha}} if name=='v1' else {'sha256':sha}
    (d/'FREEZE.json').write_text(json.dumps(freeze))
   self.assertEqual(len(verify_protocol(root)),2)
   (root/'addendum/addendum.md').write_text('changed rule')
   with self.assertRaisesRegex(AssertionError,'Frozen protocol changed'):verify_protocol(root)
 def test_missing_freeze_fails(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   with self.assertRaisesRegex(AssertionError,'required'):verify_protocol(Path(temp))
if __name__=='__main__':unittest.main()
