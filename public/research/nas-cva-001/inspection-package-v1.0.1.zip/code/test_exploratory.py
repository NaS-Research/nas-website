import unittest
from collections import defaultdict
from exploratory import type_group,expected_for_gene,projections
class Exploratory(unittest.TestCase):
 def test_snv(self):self.assertEqual(type_group('single nucleotide variant',[]),'SNV')
 def test_symbolic_not_short_indel(self):self.assertEqual(type_group('Deletion',[{'referenceAlleleVCF':'N','alternateAlleleVCF':'<DEL>'}]),'other')
 def test_explicit_small_indel(self):self.assertEqual(type_group('Deletion',[{'referenceAlleleVCF':'ACT','alternateAlleleVCF':'A'}]),'short_indel')
 def test_explicit_structural_length(self):self.assertEqual(type_group('Deletion',[{'variantLength':'1000'}]),'CNV_structural')
 def test_leave_gene_out(self):
  s=('2','SNV',0,'<2y');g='G1';cells={s:[10,5]};glob=[defaultdict(lambda:[0,0]) for _ in range(4)];own=[defaultdict(lambda:[0,0]) for _ in range(4)]
  for i,k in enumerate(projections(s)):glob[i][k]=[70,25];own[i][(g,k)]=[10,5]
  expected,covered=expected_for_gene(g,cells,glob,own);self.assertAlmostEqual(expected,10*20/60);self.assertEqual(covered,10)
if __name__=='__main__':unittest.main()
