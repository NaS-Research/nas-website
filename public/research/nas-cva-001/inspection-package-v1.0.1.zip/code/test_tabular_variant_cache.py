import sqlite3,unittest
from validate_tabular import missing
class VariantComparisonCache(unittest.TestCase):
 def test_projected_variant_cache_preserves_all_four_comparisons_with_duplicate_assemblies(self):
  c=sqlite3.connect(':memory:');c.create_function('missing',1,missing)
  c.execute("ATTACH DATABASE ':memory:' AS src")
  c.execute('CREATE TABLE src.variants(variation_id TEXT,direct_simple INTEGER,allele_id TEXT,official_label TEXT,official_review TEXT,unrelated TEXT)')
  c.executemany('INSERT INTO src.variants VALUES(?,?,?,?,?,?)',[('1',1,'01','Pathogenic','criteria provided','ignored'),('2',1,'2','','','ignored'),('3',0,'3','U','x','ignored'),('4',1,'4','Benign','reviewed by expert panel','ignored')])
  c.execute('CREATE TABLE variant(variation_id TEXT,allele_id TEXT,assembly TEXT,label TEXT,review TEXT)')
  c.executemany('INSERT INTO variant VALUES(?,?,?,?,?)',[('1','01','GRCh37','Pathogenic','criteria provided'),('1','01','GRCh38','Pathogenic','criteria provided'),('2','2','GRCh38','-','-'),('3','wrong','GRCh38','Different','different'),('4','different','GRCh37','Likely benign','criteria provided'),('missing','9','GRCh38','','')])
  c.execute('CREATE TABLE validation_variants AS SELECT variation_id,direct_simple,allele_id,official_label,official_review FROM src.variants')
  c.execute('CREATE UNIQUE INDEX validation_variants_id ON validation_variants(variation_id)')
  queries=["SELECT DISTINCT t.variation_id FROM variant t LEFT JOIN src.variants v USING(variation_id) WHERE v.variation_id IS NULL","SELECT DISTINCT t.variation_id,t.allele_id tabular_value,v.allele_id xml_value FROM variant t JOIN src.variants v USING(variation_id) WHERE v.direct_simple=1 AND t.allele_id<>v.allele_id","SELECT DISTINCT t.variation_id,t.label tabular_value,v.official_label xml_value FROM variant t JOIN src.variants v USING(variation_id) WHERE v.direct_simple=1 AND missing(t.label)<>missing(v.official_label)","SELECT DISTINCT t.variation_id,t.review tabular_value,v.official_review xml_value FROM variant t JOIN src.variants v USING(variation_id) WHERE v.direct_simple=1 AND missing(t.review)<>missing(v.official_review)"]
  expected=[[('missing',)],[('4','different','4')],[('4','Likely benign','Benign')],[('4','criteria provided','reviewed by expert panel')]]
  for query,answer in zip(queries,expected):
   original=list(c.execute(query));cached=list(c.execute(query.replace('src.variants','validation_variants')))
   self.assertEqual(original,answer);self.assertEqual(cached,original)
  c.close()
if __name__=='__main__':unittest.main()
