import unittest
from resolution_changes import changes
class Changes(unittest.TestCase):
 def row(self,scv,label='Pathogenic',org='1'):
  return dict(scv=scv,label=label,org_id=org,review='criteria',evaluated='2020-01-01')
 def test_revision_without_deletion(self):
  a=self.row('A');b=self.row('A','Benign');r=changes([a],[b],{'A':b},set());self.assertEqual(r['baseline_scv_label_revision'],1);self.assertEqual(r['baseline_scv_absent_endpoint'],0)
 def test_remapping_is_not_deletion(self):
  a=self.row('A');r=changes([a],[],{'A':a},{'A'});self.assertEqual(r['baseline_scv_present_not_qualifying_same_unit'],1);self.assertEqual(r['baseline_scv_explicitly_deleted'],0)
 def test_absence_and_explicit_deletion_separate(self):
  a,b=self.row('A'),self.row('B');r=changes([a,b],[],{}, {'A'});self.assertEqual(r['baseline_scv_absent_endpoint'],2);self.assertEqual(r['baseline_scv_explicitly_deleted'],1)
 def test_newly_qualifying_not_newly_created(self):
  a,b=self.row('A'),self.row('B',org='2');r=changes([a],[a,b],{'A':a},set());self.assertEqual(r['newly_qualifying_scvs'],1);self.assertEqual(r['qualifying_organizations_added'],1)
if __name__=='__main__':unittest.main()
