"""Compare source-provided GRCh38 VCF representations; never merge by coordinates."""
import argparse,gzip,json,sqlite3
from pathlib import Path
from summarize import export

def run(root,month,vcf_name):
 norm=root/'normalized'/month/'vcv.sqlite';assert norm.exists()
 source=root/'raw'/month/vcf_name;prov=json.loads(source.with_name(source.name+'.provenance.json').read_text());assert prov['status']=='verified download'
 out=root/'analysis'/month;out.mkdir(exist_ok=True,parents=True);path=out/'coordinate_validation.sqlite';assert not path.exists()
 part=path.with_suffix('.sqlite.part');assert not part.exists()
 db=sqlite3.connect(part);db.execute('PRAGMA journal_mode=OFF');db.execute('PRAGMA synchronous=OFF');db.execute('PRAGMA cache_size=-524288');db.execute('PRAGMA temp_store=FILE')
 db.execute('CREATE TABLE vcf(variation_id TEXT,chrom TEXT,pos INTEGER,ref TEXT,alt TEXT,allele_id TEXT)')
 metadata={};batch=[]
 with gzip.open(source,'rt') as f:
  for line in f:
   if line.startswith('##'):
    if '=' in line:
     k,v=line[2:].strip().split('=',1)
     if k in {'fileDate','reference','fileformat'}:metadata[k]=v
    continue
   if line.startswith('#'):continue
   fields=line.rstrip('\n').split('\t');info=dict(x.split('=',1) for x in fields[7].split(';') if '=' in x)
   batch.append((fields[2],fields[0],int(fields[1]),fields[3],fields[4],info.get('ALLELEID','')))
   if len(batch)>=10000:db.executemany('INSERT INTO vcf VALUES(?,?,?,?,?,?)',batch);db.commit();batch=[]
 if batch:db.executemany('INSERT INTO vcf VALUES(?,?,?,?,?,?)',batch)
 db.execute('CREATE INDEX vcf_id ON vcf(variation_id)');db.commit();db.execute('ATTACH DATABASE ? AS src',(str(norm),))
 internal=json.loads(db.execute("SELECT value FROM src.metadata WHERE key='release'").fetchone()[0])['ReleaseDate']
 assert metadata['fileDate']==internal and metadata['reference']=='GRCh38','Coordinate audit sources differ in date or assembly'
 # Both fields are explicitly VCF-normalized by the source. HGVS start/stop is not substituted.
 db.execute('''CREATE TABLE comparison AS SELECT c.*,v.direct_simple,v.allele_id xml_allele_id,
 CASE WHEN v.variation_id IS NULL THEN 'id_not_in_xml'
 WHEN v.direct_simple<>1 THEN 'not_direct_simple_not_comparable'
 WHEN c.allele_id<>v.allele_id THEN 'allele_id_mismatch'
 WHEN EXISTS(SELECT 1 FROM json_each(v.coordinates_json) x WHERE json_extract(x.value,'$.Assembly')='GRCh38'
 AND json_extract(x.value,'$.Chr')=c.chrom AND CAST(json_extract(x.value,'$.positionVCF') AS INTEGER)=c.pos
 AND json_extract(x.value,'$.referenceAlleleVCF')=c.ref AND json_extract(x.value,'$.alternateAlleleVCF')=c.alt) THEN 'exact_source_vcf_representation'
 WHEN NOT EXISTS(SELECT 1 FROM json_each(v.coordinates_json) x WHERE json_extract(x.value,'$.Assembly')='GRCh38'
 AND json_extract(x.value,'$.positionVCF') IS NOT NULL) THEN 'no_xml_vcf_representation'
 ELSE 'coordinate_or_allele_mismatch' END status
 FROM src.variants v NOT INDEXED CROSS JOIN vcf c INDEXED BY vcf_id WHERE c.variation_id=v.variation_id''')
 # Visit source variants once; probe the compact VCF index instead of random wide-source rows.
 # Append every unmatched VCF row, retaining original duplicate multiplicity and missing fields.
 db.execute('CREATE INDEX comparison_id ON comparison(variation_id)')
 db.execute("INSERT INTO comparison SELECT c.*,NULL,NULL,'id_not_in_xml' FROM vcf c WHERE NOT EXISTS(SELECT 1 FROM comparison x WHERE x.variation_id=c.variation_id)")
 db.commit()
 counts=dict(db.execute('SELECT status,count(*) FROM comparison GROUP BY status'))
 export(out/'coordinate_discrepancies.csv.gz',['variation_id','chrom','pos','ref','alt','vcf_allele_id','direct_simple','xml_allele_id','status'],db.execute("SELECT * FROM comparison WHERE status NOT IN ('exact_source_vcf_representation','not_direct_simple_not_comparable')"))
 report={'source_vcf':vcf_name,'metadata':metadata,'rows_by_status':counts,'repeated_variation_ids_in_vcf':db.execute('SELECT count(*) FROM (SELECT variation_id FROM vcf GROUP BY variation_id HAVING count(*)>1)').fetchone()[0],'method':'Exact source-provided left-normalized VCF fields and AlleleID compared by VariationID; HGVS coordinates never compared as if left-normalized. No coordinate-based cohort merge.','unmapped_and_structural_variants':'Retained in the primary XML cohort; absence from VCF is not exclusion.'}
 (out/'coordinate_validation.json').write_text(json.dumps(report,indent=2)+'\n');db.close();part.rename(path)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');p.add_argument('vcf_name');a=p.parse_args();run(a.root,a.month,a.vcf_name)
