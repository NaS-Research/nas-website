"""Full-artifact equivalence checks for sequential coordinate comparisons."""
import csv,gzip,importlib.util,json,sqlite3,tempfile,types,unittest
from collections import Counter
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
REFERENCE_IMPLEMENTATION='"""Compare source-provided GRCh38 VCF representations; never merge by coordinates."""\nimport argparse,gzip,json,sqlite3\nfrom pathlib import Path\nfrom summarize import export\n\ndef run(root,month,vcf_name):\n norm=root/\'normalized\'/month/\'vcv.sqlite\';assert norm.exists()\n source=root/\'raw\'/month/vcf_name;prov=json.loads(source.with_name(source.name+\'.provenance.json\').read_text());assert prov[\'status\']==\'verified download\'\n out=root/\'analysis\'/month;out.mkdir(exist_ok=True,parents=True);path=out/\'coordinate_validation.sqlite\';assert not path.exists()\n part=path.with_suffix(\'.sqlite.part\');assert not part.exists()\n db=sqlite3.connect(part);db.execute(\'PRAGMA journal_mode=OFF\');db.execute(\'PRAGMA synchronous=OFF\');db.execute(\'PRAGMA cache_size=-262144\');db.execute(\'PRAGMA temp_store=FILE\')\n db.execute(\'CREATE TABLE vcf(variation_id TEXT,chrom TEXT,pos INTEGER,ref TEXT,alt TEXT,allele_id TEXT)\')\n metadata={};batch=[]\n with gzip.open(source,\'rt\') as f:\n  for line in f:\n   if line.startswith(\'##\'):\n    if \'=\' in line:\n     k,v=line[2:].strip().split(\'=\',1)\n     if k in {\'fileDate\',\'reference\',\'fileformat\'}:metadata[k]=v\n    continue\n   if line.startswith(\'#\'):continue\n   fields=line.rstrip(\'\\n\').split(\'\\t\');info=dict(x.split(\'=\',1) for x in fields[7].split(\';\') if \'=\' in x)\n   batch.append((fields[2],fields[0],int(fields[1]),fields[3],fields[4],info.get(\'ALLELEID\',\'\')))\n   if len(batch)>=10000:db.executemany(\'INSERT INTO vcf VALUES(?,?,?,?,?,?)\',batch);db.commit();batch=[]\n if batch:db.executemany(\'INSERT INTO vcf VALUES(?,?,?,?,?,?)\',batch)\n db.execute(\'CREATE INDEX vcf_id ON vcf(variation_id)\');db.commit();db.execute(\'ATTACH DATABASE ? AS src\',(str(norm),))\n internal=json.loads(db.execute("SELECT value FROM src.metadata WHERE key=\'release\'").fetchone()[0])[\'ReleaseDate\']\n assert metadata[\'fileDate\']==internal and metadata[\'reference\']==\'GRCh38\',\'Coordinate audit sources differ in date or assembly\'\n # Both fields are explicitly VCF-normalized by the source. HGVS start/stop is not substituted.\n db.execute(\'\'\'CREATE TABLE comparison AS SELECT c.*,v.direct_simple,v.allele_id xml_allele_id,\n CASE WHEN v.variation_id IS NULL THEN \'id_not_in_xml\'\n WHEN v.direct_simple<>1 THEN \'not_direct_simple_not_comparable\'\n WHEN c.allele_id<>v.allele_id THEN \'allele_id_mismatch\'\n WHEN EXISTS(SELECT 1 FROM json_each(v.coordinates_json) x WHERE json_extract(x.value,\'$.Assembly\')=\'GRCh38\'\n AND json_extract(x.value,\'$.Chr\')=c.chrom AND CAST(json_extract(x.value,\'$.positionVCF\') AS INTEGER)=c.pos\n AND json_extract(x.value,\'$.referenceAlleleVCF\')=c.ref AND json_extract(x.value,\'$.alternateAlleleVCF\')=c.alt) THEN \'exact_source_vcf_representation\'\n WHEN NOT EXISTS(SELECT 1 FROM json_each(v.coordinates_json) x WHERE json_extract(x.value,\'$.Assembly\')=\'GRCh38\'\n AND json_extract(x.value,\'$.positionVCF\') IS NOT NULL) THEN \'no_xml_vcf_representation\'\n ELSE \'coordinate_or_allele_mismatch\' END status\n FROM vcf c LEFT JOIN src.variants v USING(variation_id)\'\'\');db.commit()\n counts=dict(db.execute(\'SELECT status,count(*) FROM comparison GROUP BY status\'))\n export(out/\'coordinate_discrepancies.csv.gz\',[\'variation_id\',\'chrom\',\'pos\',\'ref\',\'alt\',\'vcf_allele_id\',\'direct_simple\',\'xml_allele_id\',\'status\'],db.execute("SELECT * FROM comparison WHERE status NOT IN (\'exact_source_vcf_representation\',\'not_direct_simple_not_comparable\')"))\n report={\'source_vcf\':vcf_name,\'metadata\':metadata,\'rows_by_status\':counts,\'repeated_variation_ids_in_vcf\':db.execute(\'SELECT count(*) FROM (SELECT variation_id FROM vcf GROUP BY variation_id HAVING count(*)>1)\').fetchone()[0],\'method\':\'Exact source-provided left-normalized VCF fields and AlleleID compared by VariationID; HGVS coordinates never compared as if left-normalized. No coordinate-based cohort merge.\',\'unmapped_and_structural_variants\':\'Retained in the primary XML cohort; absence from VCF is not exclusion.\'}\n (out/\'coordinate_validation.json\').write_text(json.dumps(report,indent=2)+\'\\n\');db.close();part.rename(path)\nif __name__==\'__main__\':\n p=argparse.ArgumentParser();p.add_argument(\'root\',type=Path);p.add_argument(\'month\');p.add_argument(\'vcf_name\');a=p.parse_args();run(a.root,a.month,a.vcf_name)\n'
OLD=types.ModuleType('reference_coordinates');exec(compile(REFERENCE_IMPLEMENTATION,'<original-coordinate-reference>','exec'),OLD.__dict__)
NEW=load('sequential_coordinates',Path(__file__).resolve().parent/'validate_coordinates.py')
def coordinate(**kw):
 x={'Assembly':'GRCh38','Chr':'1','positionVCF':'10','referenceAlleleVCF':'A','alternateAlleleVCF':'G'};x.update(kw);return x
def variant(vid='1',direct=1,allele='101',coords=None):
 return (vid,direct,allele,json.dumps([coordinate()] if coords is None else coords))
def vcf(vid='1',chrom='1',pos=10,ref='A',alt='G',allele='101'):
 return (vid,chrom,pos,ref,alt,allele)
class Equivalence(unittest.TestCase):
 def setUp(self):
  self.temporary=tempfile.TemporaryDirectory(prefix='coordinate-sequential-contract-');self.tmp=Path(self.temporary.name)
 def tearDown(self):self.temporary.cleanup()
 def fixture(self,where,variants,vcfs):
  norm=where/'normalized/2026-09';raw=where/'raw/2026-09';norm.mkdir(parents=True);raw.mkdir(parents=True)
  db=sqlite3.connect(norm/'vcv.sqlite');db.execute('CREATE TABLE variants(variation_id TEXT,direct_simple INTEGER,allele_id TEXT,coordinates_json TEXT)');db.executemany('INSERT INTO variants VALUES(?,?,?,?)',variants);db.execute('CREATE INDEX variants_id ON variants(variation_id)');db.execute('CREATE TABLE metadata(key TEXT,value TEXT)');db.execute('INSERT INTO metadata VALUES(?,?)',('release',json.dumps({'ReleaseDate':'2026-08-29'})));db.commit();db.close()
  p=raw/'fixture.vcf.gz'
  with gzip.open(p,'wt') as f:
   f.write('##fileformat=VCFv4.2\n##fileDate=2026-08-29\n##reference=GRCh38\n#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n')
   for vid,chrom,pos,ref,alt,allele in vcfs:
    f.write('\t'.join([chrom,str(pos),vid,ref,alt,'.','.','ALLELEID='+allele if allele is not None else '.'])+'\n')
  p.with_name(p.name+'.provenance.json').write_text(json.dumps({'status':'verified download','fixture_only':True}))
 def compare(self,variants,vcfs,expected):
  a=self.tmp/'old';b=self.tmp/'new'
  for root in [a,b]:self.fixture(root,variants,vcfs)
  OLD.run(a,'2026-09','fixture.vcf.gz');NEW.run(b,'2026-09','fixture.vcf.gz')
  reports=[];artifacts=[]
  for root in [a,b]:
   base=root/'analysis/2026-09';reports.append(json.loads((base/'coordinate_validation.json').read_text()))
   with gzip.open(base/'coordinate_discrepancies.csv.gz','rt',newline='') as f:
    reader=csv.reader(f);header=next(reader);rows=list(reader);artifacts.append((header,Counter(tuple(x) for x in rows)))
   db=sqlite3.connect(base/'coordinate_validation.sqlite')
   table=Counter(db.execute('SELECT * FROM comparison').fetchall());db.close()
   if root==a:first=table
   else:self.assertEqual(first,table)
  self.assertEqual(reports[0],reports[1]);self.assertEqual(artifacts[0],artifacts[1])
  self.assertEqual(reports[1]['rows_by_status'],expected)
  return reports[1]
 def test_exact(self):self.compare([variant()],[vcf()],{'exact_source_vcf_representation':1})
 def test_missing_source(self):self.compare([], [vcf()],{'id_not_in_xml':1})
 def test_non_direct_precedes_allele_mismatch(self):self.compare([variant(direct=0,allele='999')],[vcf()],{'not_direct_simple_not_comparable':1})
 def test_allele_mismatch_precedes_coordinate(self):self.compare([variant(allele='999',coords=[])],[vcf()],{'allele_id_mismatch':1})
 def test_no_coordinate(self):self.compare([variant(coords=[])],[vcf()],{'no_xml_vcf_representation':1})
 def test_other_assembly_is_not_vcf_representation(self):self.compare([variant(coords=[coordinate(Assembly='GRCh37')])],[vcf()],{'no_xml_vcf_representation':1})
 def test_hgvs_position_is_not_substituted(self):self.compare([variant(coords=[coordinate(positionVCF=None,start='10')])],[vcf()],{'no_xml_vcf_representation':1})
 def test_coordinate_mismatch(self):self.compare([variant(coords=[coordinate(alternateAlleleVCF='T')])],[vcf()],{'coordinate_or_allele_mismatch':1})
 def test_any_exact_coordinate_among_multiple(self):self.compare([variant(coords=[coordinate(Assembly='GRCh37'),coordinate(alternateAlleleVCF='T'),coordinate()])],[vcf()],{'exact_source_vcf_representation':1})
 def test_missing_info_allele(self):self.compare([variant()],[vcf(allele=None)],{'allele_id_mismatch':1})
 def test_duplicate_matched_and_unmatched_vcf_rows(self):
  r=self.compare([variant()],[vcf(),vcf(),vcf(vid='9'),vcf(vid='9')],{'exact_source_vcf_representation':2,'id_not_in_xml':2});self.assertEqual(r['repeated_variation_ids_in_vcf'],2)
 def test_duplicate_source_rows_preserved(self):self.compare([variant(),variant()],[vcf(),vcf()],{'exact_source_vcf_representation':4})
 def test_null_direct_flag_preserves_sql_semantics(self):self.compare([variant(direct=None)],[vcf()],{'exact_source_vcf_representation':1})
 def test_null_allele_flag_preserves_sql_semantics(self):self.compare([variant(allele=None)],[vcf()],{'exact_source_vcf_representation':1})
 def test_leading_zero_id_is_distinct(self):self.compare([variant('001')],[vcf('1')],{'id_not_in_xml':1})
 def test_all_statuses_and_arbitrary_source_order(self):
  variants=[variant('6',coords=[coordinate(alternateAlleleVCF='T')]),variant('1'),variant('3',direct=0,allele='999'),variant('4',allele='999'),variant('5',coords=[])]
  vcfs=[vcf('5'),vcf('4'),vcf('9'),vcf('3'),vcf('1'),vcf('6')]
  self.compare(variants,vcfs,{'exact_source_vcf_representation':1,'id_not_in_xml':1,'not_direct_simple_not_comparable':1,'allele_id_mismatch':1,'no_xml_vcf_representation':1,'coordinate_or_allele_mismatch':1})
 def test_empty_vcf_and_extra_source_records(self):self.compare([variant(),variant('2')],[],{})
 def test_both_inputs_empty(self):self.compare([],[],{})
if __name__=='__main__':unittest.main(verbosity=2)
