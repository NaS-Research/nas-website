import csv,gzip,sqlite3,tempfile,unittest
from pathlib import Path
from summarize import grouped_mode_summary
from study_stats import clustered_fraction_interval

class GroupedSummary(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.tables=Path(self.temp.name);self.db=sqlite3.connect(':memory:');self.addCleanup(self.db.close)
  self.db.execute('CREATE TABLE units(mode TEXT,variation_id TEXT,tier INTEGER,eligible INTEGER)')
  rows=[('primary','10',0,1),('primary','10',1,1),('primary','10',4,1),('primary','2',4,1),('primary','2',4,1),('primary','3',2,1),('primary','3',3,1),('primary','4',0,1),('primary','5',1,0),('variant_wide','10',1,1),('variant_wide','2',4,1),('variant_wide','3',2,1),('inactive','6',1,0)]
  self.db.executemany('INSERT INTO units VALUES(?,?,?,?)',rows)
  self.db.execute('CREATE INDEX units_variant ON units(mode,variation_id)')
 def test_matches_literal_sql_reference(self):
  actual,clusters=grouped_mode_summary(self.db,self.tables)
  for mode, in self.db.execute('SELECT DISTINCT mode FROM units'):
   counts=dict(self.db.execute('SELECT tier,count(*) FROM units WHERE mode=? AND eligible=1 GROUP BY tier',(mode,)))
   variants=self.db.execute("SELECT variation_id,CASE WHEN min(CASE WHEN tier>0 THEN tier ELSE 99 END)=99 THEN 0 ELSE min(CASE WHEN tier>0 THEN tier ELSE 99 END) END FROM units WHERE mode=? AND eligible=1 GROUP BY variation_id",(mode,)).fetchall()
   vc={t:sum(row[1]==t for row in variants) for t in sorted({row[1] for row in variants})}
   self.assertEqual(actual[mode],{'eligible_units':sum(counts.values()),'unit_tier_counts':counts,'eligible_variants':len(variants),'variant_tier_counts':vc})
   with gzip.open(self.tables/f'variant_outcomes_{mode}.csv.gz','rt',newline='') as f:rows=list(csv.reader(f))
   self.assertEqual(rows,[['variation_id','tier']]+[[str(x) for x in row] for row in variants])
 def test_unit_adjacent_event_is_distinct_from_variant_event(self):
  modes,clusters=grouped_mode_summary(self.db,self.tables)
  self.assertEqual(modes['primary']['unit_tier_counts'][4],3)
  self.assertEqual(modes['primary']['variant_tier_counts'][4],1)
  self.assertEqual(modes['primary']['eligible_units'],8)
  self.assertEqual(modes['primary']['eligible_variants'],4)
 def test_empty_eligible_mode_is_preserved(self):
  modes,clusters=grouped_mode_summary(self.db,self.tables)
  self.assertEqual(modes['inactive'],{'eligible_units':0,'unit_tier_counts':{},'eligible_variants':0,'variant_tier_counts':{}})
 def test_cluster_intervals_match_literal_grouped_sql(self):
  modes,clusters=grouped_mode_summary(self.db,self.tables)
  for i,tiers in enumerate([(1,),(1,2),(1,2,3),(4,)]):
   marks=','.join('?'*len(tiers))
   original=list(self.db.execute(f"SELECT sum(tier IN ({marks})),count(*) FROM units WHERE mode='primary' AND eligible=1 GROUP BY variation_id",tiers))
   self.assertEqual(clustered_fraction_interval(original,reps=200),clustered_fraction_interval(((row[i],row[4]) for row in clusters),reps=200))
if __name__=='__main__':unittest.main()
