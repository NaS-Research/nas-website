"""Baseline expert/recent-update associations; no causal interpretation."""
import argparse,datetime,itertools,json,sqlite3
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from cohort import age_days
from history import key,compatible_metadata
from summarize import export

def update_category(dates,asof):
 ages=[age_days(x,asof)[0] for x in dates]
 if any(x is not None and x<=365 for x in ages):return 'recent'
 if not ages or any(x is None for x in ages):return 'unknown'
 return 'older'

def cluster_difference(vectors,reps=2000):
 patterns=Counter(tuple(x) for x in vectors)
 if not patterns:return None,None
 keys=sorted(patterns);matrix=np.array(keys);counts=np.array([patterns[k] for k in keys]);n=int(counts.sum());rng=np.random.default_rng(20260926);differences=[]
 for _ in range(reps):
  a,b,c,d=rng.multinomial(n,counts/n)@matrix
  if b and d:differences.append(a/b-c/d)
 return tuple(map(float,np.quantile(differences,[.025,.975]))) if differences else (None,None)

def run(root):
 months=['2025-09','2026-03','2026-09'];out=root/'analysis/history';assert (out/'history_summary.json').exists()
 rows=[];effects=[];update_cache={}
 for start,end in [(months[0],months[1]),(months[1],months[2]),(months[0],months[2])]:
  a=sqlite3.connect(f'file:{root/"analysis"/start/"units.sqlite"}?mode=ro',uri=True);a.row_factory=sqlite3.Row
  a.execute('ATTACH DATABASE ? AS source',(str(root/'normalized'/start/'vcv.sqlite'),))
  asof=datetime.date.fromisoformat(json.loads(a.execute("SELECT value FROM metadata WHERE key='snapshot_date'").fetchone()[0]))
  a.execute('PRAGMA cache_size=-262144');a.execute('PRAGMA source.cache_size=-262144')
  if start not in update_cache:
   grouped=defaultdict(list)
   for row in a.execute("SELECT u.unit_key,u.scv FROM unit_assertions u JOIN units v ON v.mode=u.mode AND v.unit_key=u.unit_key WHERE u.mode='primary' AND v.eligible=1 AND v.tier IN(1,2,3)"):
    grouped[row['unit_key']].append(row['scv'])
   wanted={scv for ids in grouped.values() for scv in ids}
   update_dates={row['scv']:row['updated'] for row in a.execute('SELECT scv,updated FROM source.assertions NOT INDEXED') if row['scv'] in wanted}
   assert set(update_dates)==wanted,'Every retained SCV must exist in its source snapshot'
   update_cache[start]={uk:update_category([update_dates[scv] for scv in ids],asof) for uk,ids in grouped.items()}
   print('Cached interval-start update categories',start,len(update_cache[start]),flush=True)
  updates=update_cache[start]
  # Use the already lineage-checked transition table instead of recomputing identity rules.
  import csv,gzip
  transition_map={}
  with gzip.open(out/'transitions.csv.gz','rt',newline='') as f:
   for x in csv.DictReader(f):
    if x['start_month']==start and x['end_month']==end:transition_map[(x['variation_id'],x['condition_key'],x['inheritance'])]=x['transition']
  counts=defaultdict(Counter);clusters={exposure:defaultdict(lambda:[0,0,0,0]) for exposure in ['expert','updated_prior_365d']}
  for u in a.execute("SELECT * FROM units WHERE mode='primary' AND eligible=1 AND tier IN(1,2,3)"):
   outcome=transition_map.get(key(u),'non_comparable')
   status='resolved' if outcome=='cross_band_resolved' else 'persistent' if outcome in {'persistent_same_tier','persistent_changed_tier'} else 'lost_or_noncomparable'
   for exposure,category in [('expert','present' if u['expert'] else 'absent'),('updated_prior_365d',updates.get(u['unit_key'],'unknown'))]:
    counts[(exposure,category)][status]+=1
    if category=='unknown' or status=='lost_or_noncomparable':continue
    vector=clusters[exposure][u['variation_id']];idx=0 if category in {'present','recent'} else 2
    vector[idx]+=int(status=='resolved');vector[idx+1]+=1
  for (exposure,category),c in sorted(counts.items()):
   n=c['resolved']+c['persistent'];rows.append([start,end,exposure,category,c['resolved'],c['persistent'],c['lost_or_noncomparable'],c['resolved']/n if n else None])
  for exposure,patterns in clusters.items():
   vectors=list(patterns.values());total=np.sum(vectors,axis=0) if vectors else [0,0,0,0];er,en,cr,cn=map(int,total)
   difference=er/en-cr/cn if en and cn else None;lo,hi=cluster_difference(vectors)
   odds=(er*(cn-cr)/((en-er)*cr)) if en>er and cr and cn else None
   effects.append([start,end,exposure,er,en,cr,cn,difference,lo,hi,odds])
  a.close()
 export(out/'baseline_associations.csv',['start_month','end_month','exposure','category','resolved','persistent','lost_or_noncomparable','resolution_fraction_observed_pairs'],rows)
 export(out/'baseline_association_effects.csv',['start_month','end_month','exposure','exposed_resolved','exposed_observed','comparison_resolved','comparison_observed','risk_difference','cluster_ci_lower','cluster_ci_upper','odds_ratio_without_zero_cell_correction'],effects)
 (out/'association_interpretation.txt').write_text('Exploratory observational comparisons. Exposure is measured at interval start. Recent update means an SCV record update within the preceding 365 days, not necessarily a new clinical evaluation. Missing update dates form an unknown category. Risk differences use 2,000 variant-cluster bootstrap resamples. Losses and non-comparable records are tabulated separately; estimates condition on observed comparable pairs and may be biased by ascertainment and attrition. No causal claim or organization quality assessment.\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();run(a.root)
