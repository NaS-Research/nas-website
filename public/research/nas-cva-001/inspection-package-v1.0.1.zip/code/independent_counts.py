"""Independent SQL recomputation from normalized source rows, without production classifiers."""
import argparse,json,sqlite3
from datetime import datetime,timezone
from pathlib import Path
# The explicit literal matrix below deliberately does not import conflicts or cohort.
SQL=r'''
WITH mapped AS (
 SELECT a.*,m.rcv,r.conditions_json,
 CASE lower(trim(a.label)) WHEN 'pathogenic' THEN 'P' WHEN 'likely pathogenic' THEN 'LP'
 WHEN 'uncertain significance' THEN 'U' WHEN 'vus-high' THEN 'U' WHEN 'vus-mid' THEN 'U' WHEN 'vus-low' THEN 'U'
 WHEN 'likely benign' THEN 'LB' WHEN 'benign' THEN 'B'
 WHEN 'pathogenic/likely pathogenic' THEN 'PLP' WHEN 'benign/likely benign' THEN 'BLB' END AS c
 FROM src.assertions a JOIN src.variants v USING(variation_id)
 JOIN rcv.membership m ON m.scv=a.scv
 JOIN src.rcvs r ON r.rcv=m.rcv AND r.variation_id=a.variation_id
 WHERE v.direct_simple=1 AND a.direct_simple=1 AND v.species='Homo sapiens'
 AND v.status='current' AND a.status='current' AND a.class_type='germline' AND a.org_id<>''
 AND a.review IN ('criteria provided, single submitter','reviewed by expert panel','practice guideline')
 AND NOT (json_array_length(a.origins_json)>0 AND NOT EXISTS(SELECT 1 FROM json_each(a.origins_json) WHERE value<>'somatic'))
 AND (SELECT count(*) FROM rcv.membership m2 WHERE m2.scv=a.scv)=1
 AND json_array_length(r.conditions_json)>0
 AND NOT EXISTS(SELECT 1 FROM json_each(r.conditions_json) c WHERE json_extract(c.value,'$.DB')<>'MedGen'
 OR coalesce(json_extract(c.value,'$.ID'),'')='' OR lower(trim(coalesce(json_extract(c.value,'$.name'),''))) IN ('not provided','not specified','unspecified','not applicable','unknown'))
), consistent AS (
 SELECT variation_id,rcv,inheritance_json,org_id,min(c) c
 FROM mapped WHERE c IS NOT NULL GROUP BY variation_id,rcv,inheritance_json,org_id HAVING count(DISTINCT c)=1
), totals AS (
 SELECT variation_id,rcv,inheritance_json,count(*) n,
 max(c IN ('P','LP','PLP')) p,max(c IN ('B','LB','BLB')) b,max(c='U') u,
 max(c='P') p_exact,max(c='LP') lp_exact,max(c='B') b_exact,max(c='LB') lb_exact
 FROM consistent GROUP BY variation_id,rcv,inheritance_json HAVING count(*)>=2
)
SELECT variation_id,rcv,inheritance_json,n,
 CASE WHEN p AND b THEN 1 WHEN p AND u THEN 2 WHEN b AND u THEN 3
 WHEN (p_exact AND lp_exact) OR (b_exact AND lb_exact) THEN 4 ELSE 0 END tier FROM totals
'''
def run(root,month):
 out=root/'analysis'/month
 con=sqlite3.connect(out/'independent.sqlite');con.execute('PRAGMA temp_store=FILE');con.execute('PRAGMA cache_size=-131072')
 con.execute('ATTACH DATABASE ? AS src',(str(root/'normalized'/month/'vcv.sqlite'),));con.execute('ATTACH DATABASE ? AS rcv',(str(root/'normalized'/month/'rcv.sqlite'),));con.execute('ATTACH DATABASE ? AS prod',(str(out/'units.sqlite'),))
 for schema in ('src','rcv','prod'): con.execute(f'PRAGMA {schema}.cache_size=-524288')
 print(datetime.now(timezone.utc).isoformat(),'starting independent SQL construction',flush=True)
 con.execute('CREATE TABLE independent AS '+SQL);con.commit()
 print(datetime.now(timezone.utc).isoformat(),'independent SQL construction complete; indexing comparison keys',flush=True)
 con.execute('CREATE INDEX independent_unit ON independent(variation_id,rcv,inheritance_json)');con.commit()
 print(datetime.now(timezone.utc).isoformat(),'starting bidirectional comparison',flush=True)
 mismatches=con.execute('''SELECT count(*) FROM independent i LEFT JOIN prod.units u ON u.mode='primary' AND u.variation_id=i.variation_id AND u.rcv=i.rcv AND u.inheritance=i.inheritance_json WHERE u.unit_key IS NULL OR u.eligible<>1 OR u.organizations<>i.n OR u.tier<>i.tier''').fetchone()[0]
 missing=con.execute('''SELECT count(*) FROM prod.units u LEFT JOIN independent i ON u.variation_id=i.variation_id AND u.rcv=i.rcv AND u.inheritance=i.inheritance_json WHERE u.mode='primary' AND u.eligible=1 AND i.variation_id IS NULL''').fetchone()[0]
 report={'independent_eligible_units':con.execute('SELECT count(*) FROM independent').fetchone()[0],'mismatched_or_missing_in_production':mismatches,'production_units_missing_independently':missing,'tier_counts':dict(con.execute('SELECT tier,count(*) FROM independent GROUP BY tier')),'method':'Separate SQL filters and literal label matrix over normalized sources; no production cohort or tier functions imported','passed':mismatches==0 and missing==0}
 (out/'independent_validation.json').write_text(json.dumps(report,indent=2)+'\n');con.close();assert report['passed'],report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
