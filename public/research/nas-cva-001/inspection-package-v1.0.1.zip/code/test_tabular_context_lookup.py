import csv,gzip,json,os,sqlite3,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import tabular_discrepancy_context as context
class SourceContextLookup(unittest.TestCase):
 def create(self,path,count):
  c=sqlite3.connect(path);c.row_factory=sqlite3.Row
  c.execute('CREATE TABLE assertions('+','.join(x+' '+('INTEGER' if x=='direct_simple' else 'TEXT') for x in context.ASSERTION_FIELDS)+')')
  for i in range(count):
   record={x:'' for x in context.ASSERTION_FIELDS}
   record.update(scv=f'SCV{i:09d}',version=str(i%4+1),variation_id=str(i%17),class_type='germline' if i%2 else 'somatic_or_other',status='current',org_id=str(i%8),label='Uncertain significance' if i%2 else '',review='criteria provided, single submitter',contributes='true',direct_simple=1,conditions_json='{"C1":"literal quote \\" and space  "}',inheritance_json='[]',origins_json='["germline"]',methods_json='["research"]',evaluated=None if i%3 else '2020-01-01')
   c.execute('INSERT INTO assertions VALUES('+','.join('?' for _ in record)+')',[record[x] for x in context.ASSERTION_FIELDS])
  c.execute('CREATE UNIQUE INDEX assertions_id ON assertions(scv)');c.commit();return c
 def test_indexed_batches_and_sequential_scan_preserve_every_field_and_missing_id(self):
  c=self.create(':memory:',810);wanted=[f'SCV{i:09d}' for i in range(0,810)]+['SCV999999999']
  indexed=context.lookup_assertion_records(c,wanted,scan_threshold=10000)
  streamed=context.lookup_assertion_records(c,wanted,scan_threshold=0)
  self.assertEqual(streamed,indexed);self.assertEqual(len(streamed),810)
  self.assertNotIn('SCV999999999',streamed)
  self.assertIsNone(streamed['SCV000000001']['evaluated'])
  self.assertEqual(streamed['SCV000000001']['conditions_json'],'{"C1":"literal quote \\" and space  "}')
  c.close()
 def test_entire_context_report_and_unretained_variant_scope_match_both_lookup_strategies(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   root=Path(temp);base=root/'analysis'/'fixture';base.mkdir(parents=True);norm=root/'normalized'/'fixture';norm.mkdir(parents=True)
   c=self.create(norm/'vcv.sqlite',4);c.close()
   u=sqlite3.connect(base/'units.sqlite')
   u.execute('CREATE TABLE units(unit_key TEXT,variation_id TEXT,tier INTEGER,mode TEXT,eligible INTEGER)')
   u.executemany('INSERT INTO units VALUES(?,?,?,?,?)',[('a','0',3,'primary',1),('b','1',2,'primary',1),('c','999',0,'primary',1)])
   u.execute('CREATE TABLE unit_assertions(unit_key TEXT,scv TEXT,mode TEXT)')
   u.executemany('INSERT INTO unit_assertions VALUES(?,?,?)',[('a','SCV000000002','primary'),('b','SCV000000001','primary'),('c','unrelated','primary')]);u.commit();u.close()
   (base/'tabular_validation.json').write_text(json.dumps({'checks':{'submission_label_mismatch':2,'submission_scv_missing_xml':1}}))
   for name,columns,data in [('submission_label_mismatch',['scv','tabular_value','xml_value'],[['SCV000000000','x',''],['SCV000000001','x','Uncertain significance']]),('submission_scv_missing_xml',['scv','variation_id'],[['SCV999999999','999']])]:
    with gzip.open(base/(name+'.csv.gz'),'wt',newline='') as f:
     w=csv.writer(f);w.writerow(columns);w.writerows(data)
   with patch.object(context,'INDEX_LOOKUP_THRESHOLD',10000):context.run(root,'fixture')
   indexed=json.loads((base/'tabular_discrepancy_context.json').read_text())
   with patch.object(context,'INDEX_LOOKUP_THRESHOLD',0):context.run(root,'fixture')
   streamed=json.loads((base/'tabular_discrepancy_context.json').read_text())
   self.assertEqual(streamed,indexed)
   scope=streamed['summary']['submission_label_mismatch']
   self.assertEqual(scope['retained_qualifying_scvs'],1)
   self.assertEqual(scope['eligible_primary_units_with_retained_affected_scvs'],1)
   self.assertEqual(scope['eligible_primary_units_at_implicated_variants'],2)
   self.assertEqual(streamed['summary']['submission_scv_missing_xml']['eligible_primary_units_at_implicated_variants'],1)
if __name__=='__main__':unittest.main()
