"""Construct exact condition/inheritance units from matched, validated snapshots."""
import argparse,datetime,itertools,json,os,sqlite3,time
from collections import Counter,defaultdict
from pathlib import Path
from normalize_vcv import js
from cohort import exclusion_reasons,summarize,age_days,EXPERT
from conflicts import canonical,unit
MODES=['primary','all_review','explicit_germline','clinical_testing','no_expert','allow_internal','condition_inheritance_pooled','rcv_inheritance_pooled','variant_wide','no_compound_subtype','recent_5y','recent_2y']
SCHEMA='''
CREATE TABLE units(mode TEXT,unit_key TEXT,variation_id TEXT,rcv TEXT,inheritance TEXT,conditions_json TEXT,eligible INTEGER,organizations INTEGER,tier INTEGER,pair_tiers TEXT,assertions INTEGER,oldest_age_days INTEGER,newest_age_days INTEGER,missing_dates INTEGER,expert INTEGER,inconsistent_orgs INTEGER,official_rcv_label TEXT,official_rcv_review TEXT,official_vcv_label TEXT,official_vcv_review TEXT,genes_json TEXT,variant_type TEXT);
CREATE TABLE unit_assertions(mode TEXT,unit_key TEXT,variation_id TEXT,scv TEXT,version TEXT,org_id TEXT,label TEXT,canonical TEXT,review TEXT,evaluated TEXT,age_days INTEGER,date_status TEXT,org_type TEXT,methods_json TEXT,origins_json TEXT);
CREATE TABLE exclusions(scv TEXT,variation_id TEXT,unit_key TEXT,reasons_json TEXT);
CREATE TABLE crossfile_errors(scv TEXT,field TEXT,vcv_value TEXT,rcv_value TEXT);
CREATE TABLE official_replication(level TEXT,accession TEXT,variation_id TEXT,observed INTEGER,predicted INTEGER,reason TEXT);
CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);
'''
def official_flag(label):return 'conflicting classifications of pathogenicity' in label.lower() or 'conflicting interpretations of pathogenicity' in label.lower()
def official_band(label):
 s=' '.join(label.lower().split())
 if s in {'pathogenic','likely pathogenic','pathogenic/likely pathogenic','pathogenic, low penetrance','likely pathogenic, low penetrance','established risk allele','likely risk allele'}:return 'positive'
 if s in {'uncertain significance','vus-high','vus-mid','vus-low','uncertain risk allele'}:return 'uncertain'
 if s in {'benign','likely benign','benign/likely benign'}:return 'benign'
 return None
def replicate(aa):
 ranks={'practice guideline':4,'reviewed by expert panel':3,'criteria provided, single submitter':1,'no assertion criteria provided':0}
 aa=[a for a in aa if a['class_type']=='germline' and a['status']=='current']
 if not aa:return 0,'no_germline'
 if any(a['review'] not in ranks for a in aa):
  unknown=[a for a in aa if a['review'] not in ranks and official_band(a['label'])]
  if unknown:return None,'unrecognized_review'
 mx=max((ranks.get(a['review'],-1) for a in aa),default=-1)
 selected=[a for a in aa if ranks.get(a['review'],-1)==mx]
 bands={official_band(a['label']) for a in selected}-{None}
 if mx>=3 and len(bands)>1:return None,'multiple_discordant_highest_review'
 return int(len(bands)>1),'review_precedence'
def stable_condition(conditions):return '|'.join(sorted(x['DB']+':'+x['ID'] for x in conditions))
def choose_mode(mode,a,reasons,asof):
 if mode=='all_review':reasons=[x for x in reasons if x!='no_assertion_criteria']
 if mode=='variant_wide':reasons=[x for x in reasons if x not in {'ambiguous_or_missing_rcv_membership','nonspecific_or_unresolved_condition'}]
 if reasons:return False
 if mode=='explicit_germline' and 'germline' not in json.loads(a['origins_json']):return False
 if mode=='clinical_testing' and 'clinical testing' not in json.loads(a['methods_json']):return False
 if mode=='no_expert' and a['review'] in EXPERT:return False
 if mode=='no_compound_subtype' and ('/' in a['label'] or a['label'].lower().startswith('vus-')):return False
 if mode in {'recent_5y','recent_2y'}:
  age,_=age_days(a['evaluated'],asof)
  if age is None or age>(5 if mode=='recent_5y' else 2)*365.25:return False
 return True

def run(root,month):
 (root/'tmp').mkdir(exist_ok=True);os.environ['SQLITE_TMPDIR']=str(root/'tmp')
 assert json.loads((root/'analysis'/month/'snapshot_validation.json').read_text())['passed'],'Matched snapshot validation required'
 d=root/'normalized'/month
 for file in ['vcv.sqlite','rcv.sqlite']:assert (d/file).is_file(),file+' not finalized'
 vc=sqlite3.connect(f'file:{d/"vcv.sqlite"}?mode=ro',uri=True);vc.row_factory=sqlite3.Row
 rc=sqlite3.connect(f'file:{d/"rcv.sqlite"}?mode=ro',uri=True);rc.row_factory=sqlite3.Row
 for source_db in [vc,rc]:source_db.execute('PRAGMA cache_size=-262144')
 vm=json.loads(vc.execute("SELECT value FROM metadata WHERE key='release'").fetchone()[0]);rm=json.loads(rc.execute("SELECT value FROM metadata WHERE key='release'").fetchone()[0])
 assert vm['ReleaseDate']==rm['Dated'],'Mismatched internal snapshot dates'
 asof=datetime.date.fromisoformat(vm['ReleaseDate'])
 out=root/'analysis'/month;out.mkdir(parents=True,exist_ok=True);part=out/'units.sqlite.part';final=out/'units.sqlite';assert not part.exists() and not final.exists()
 db=sqlite3.connect(part);db.executescript(SCHEMA);db.execute('PRAGMA journal_mode=OFF');db.execute('PRAGMA synchronous=OFF');db.execute('PRAGMA temp_store=FILE');db.execute('PRAGMA cache_size=-524288')
 counts=Counter();n=0;t=time.monotonic()
 source_counts=vc.execute("SELECT value FROM metadata WHERE key='counts'").fetchone()
 counts['variants:source_total']=int(json.loads(source_counts[0])['variants']) if source_counts else vc.execute('SELECT COUNT(*) FROM variants').fetchone()[0]
 # Normalization inserts all assertions of one VariationArchive consecutively. Verify no repeated variant group.
 seen=set()
 for vid,group in itertools.groupby(vc.execute('SELECT * FROM assertions ORDER BY rowid'),key=lambda x:x['variation_id']):
  assert vid not in seen,'Noncontiguous variant group';seen.add(vid)
  aa=[dict(x) for x in group];v=dict(vc.execute('SELECT * FROM variants WHERE variation_id=?',(vid,)).fetchone())
  c_by={x['rcv']:dict(x) for x in vc.execute('SELECT * FROM rcvs WHERE variation_id=?',(vid,))}
  # Requires index created after extraction; source order is not a numeric identifier assumption.
  members=defaultdict(list)
  for offset in range(0,len(aa),500):
   chunk=aa[offset:offset+500]
   for x in rc.execute('SELECT * FROM membership WHERE scv IN ('+','.join('?'*len(chunk))+')',[a['scv'] for a in chunk]):members[x['scv']].append(dict(x))
  groups={mode:defaultdict(list) for mode in MODES};gmeta={}
  for a in aa:
   mm=members[a['scv']]
   for m in mm:
    for field in ['version','variation_id','label','review','evaluated','org_id']:
     # Somatic labels are not extracted into a germline comparison field.
     if field=='label' and a['class_type']!='germline':continue
     if a[field]!=m[field]:db.execute('INSERT INTO crossfile_errors VALUES(?,?,?,?)',(a['scv'],field,a[field],m[field]));counts['crossfile_errors']+=1
   matched=mm[0]['rcv'] if len(mm)==1 else ''
   condition_record=c_by.get(matched)
   conditions=json.loads(condition_record['conditions_json']) if condition_record else []
   reasons=exclusion_reasons(a,v,conditions,len(mm))
   counts['assertions_seen']+=1
   for reason in reasons:counts['reason:'+reason]+=1
   counts['flow:'+ (reasons[0] if reasons else 'eligible_assertion')]+=1
   if reasons:db.execute('INSERT INTO exclusions VALUES(?,?,?,?)',(a['scv'],vid,vid+'|'+(matched or 'NO_RCV:'+a['scv'])+'|'+js(sorted(json.loads(a['inheritance_json']))),js(reasons)))
   inheritance=js(sorted(json.loads(a['inheritance_json'])))
   for mode in MODES:
    if not choose_mode(mode,a,reasons,asof):continue
    if mode=='variant_wide':key=vid+'|ALL';meta=('',[], 'ALL',None)
    elif mode=='condition_inheritance_pooled':key=vid+'|'+stable_condition(conditions);meta=(matched,conditions,'POOLED',condition_record)
    elif mode=='rcv_inheritance_pooled':key=vid+'|'+matched;meta=(matched,conditions,'POOLED',condition_record)
    else:key=vid+'|'+matched+'|'+inheritance;meta=(matched,conditions,inheritance,condition_record)
    groups[mode][key].append(a);gmeta[(mode,key)]=meta
  for mode,gg in groups.items():
   for key,assertions in gg.items():
    result,retained=summarize(assertions,asof,mode=='allow_internal')
    counts['units:'+mode+(':eligible' if result['eligible'] else ':ineligible')]+=1
    if mode!='primary' and not result['eligible']:continue
    rcv,conditions,inheritance,cr=gmeta[(mode,key)]
    values=(mode,key,vid,rcv,inheritance,js(conditions),int(result['eligible']),result['organizations'],result['tier'],js(result['pair_tiers']),result['assertions'],result['oldest_age_days'],result['newest_age_days'],result['missing_or_invalid_dates'],int(result['expert_present']),result['excluded_inconsistent_organizations'],'' if cr is None else cr['official_label'],'' if cr is None else cr['official_review'],v['official_label'],v['official_review'],v['genes_json'],v['variant_type'])
    db.execute('INSERT INTO units VALUES('+','.join('?'*len(values))+')',values)
    for a in (retained if mode=='primary' else []):
     age,status=age_days(a['evaluated'],asof)
     values=(mode,key,vid,a['scv'],a['version'],a['org_id'],a['label'],canonical(a['label']),a['review'],a['evaluated'],age,status,a['org_type'],a['methods_json'],a['origins_json'])
     db.execute('INSERT INTO unit_assertions VALUES('+','.join('?'*len(values))+')',values)
  pred,reason=replicate(aa)
  db.execute('INSERT INTO official_replication VALUES(?,?,?,?,?,?)',('VCV',v['vcv'],vid,int(official_flag(v['official_label'])),pred,reason))
  for rcv,cr in c_by.items():
   relevant=[a for a in aa if any(m['rcv']==rcv for m in members[a['scv']])]
   pred,reason=replicate(relevant)
   db.execute('INSERT INTO official_replication VALUES(?,?,?,?,?,?)',('RCV',rcv,vid,int(official_flag(cr['official_label'])),pred,reason))
  n+=1
  if n%10000==0:db.commit();print(js({'variant_groups_processed':n,'elapsed_seconds':round(time.monotonic()-t),'crossfile_errors':counts['crossfile_errors']}),flush=True)
 counts['variants:with_extracted_assertions']=n
 counts['variants:without_extracted_assertions']=counts['variants:source_total']-n
 for name,table,columns in [('units_key','units','mode,unit_key'),('unit_assertions_key','unit_assertions','mode,unit_key,scv'),('exclusions_key','exclusions','scv'),('official_replication_key','official_replication','level,accession')]:
  print(js({'phase':'building_unique_index','index':name}),flush=True)
  db.execute('CREATE UNIQUE INDEX '+name+' ON '+table+'('+columns+')')
 db.executemany('INSERT INTO metadata VALUES(?,?)',[(k,js(val)) for k,val in {'month':month,'snapshot_date':str(asof),'counts':dict(counts),'modes':MODES}.items()]);db.execute('CREATE INDEX units_variant ON units(mode,variation_id)');db.commit();db.close();vc.close();rc.close()
 from reconcile_sources import verify_gate
 adjudication=verify_gate(root,month,part)
 (out/'source_adjudication_result.json').write_text(json.dumps(adjudication,indent=2)+'\n')
 part.rename(final)
 (out/'unit_construction.json').write_text(json.dumps(dict(counts),indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
