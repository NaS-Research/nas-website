"""Reconcile matched tabular exports with XML; discrepancies require review."""
import argparse,csv,datetime,gzip,json,os,sqlite3,sys,time
from pathlib import Path
from summarize import export

def rows(path,first_column):
 # NCBI TSV has literal quotes, not CSV-escaped fields. Never join physical rows.
 with gzip.open(path,'rt',newline='') as f:
  for line_number,line in enumerate(f,1):
   if line.startswith(first_column+'\t'):
    header=line.rstrip('\r\n').split('\t');break
  else:raise ValueError(f'Missing expected header in {path.name}')
  if len(set(header))!=len(header):raise ValueError('Duplicate source columns')
  for line in f:
   line_number+=1
   fields=line.rstrip('\r\n').split('\t')
   if len(fields)!=len(header):
    raise ValueError(f'{path.name}:{line_number}: expected {len(header)} columns, got {len(fields)}; source row requires investigation')
   yield dict(zip(header,fields))

def boolean(value):
 text=' '.join((value or '').lower().split())
 return {'yes':'true','true':'true','1':'true','no':'false','false':'false','0':'false'}.get(text,text)
def missing(value):
 text=' '.join((value or '').lower().split())
 return '' if text=='-' else text
def date(value):
 if value.strip().lower() in {'','-','na','not provided','not evaluated'}:return ''
 try:return datetime.datetime.strptime(value.strip(),'%b %d, %Y').date().isoformat()
 except ValueError:
  try:return datetime.date.fromisoformat(value.strip()).isoformat()
  except ValueError:return 'UNPARSED:'+value

def run(root,month):
 os.environ['SQLITE_TMPDIR']=str(root/'tmp');out=root/'analysis'/month;raw=root/'raw'/month
 assert json.loads((out/'snapshot_validation.json').read_text())['passed']
 part=out/'tabular_validation.sqlite.part';final=out/'tabular_validation.sqlite';assert not part.exists() and not final.exists()
 c=sqlite3.connect(part);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=OFF');c.execute('PRAGMA synchronous=OFF');c.execute('PRAGMA temp_store=FILE');c.execute('PRAGMA cache_size=-524288')
 c.create_function('norm',1,lambda x:' '.join((x or '').lower().split()))
 c.create_function('boolean',1,boolean);c.create_function('missing',1,missing)
 c.executescript('''CREATE TABLE submission(scv TEXT,version TEXT,variation_id TEXT,label TEXT,review TEXT,evaluated TEXT,contributes TEXT);
 CREATE TABLE variant(variation_id TEXT,allele_id TEXT,assembly TEXT,label TEXT,review TEXT);
 CREATE TABLE pair(variation_id TEXT,scv1 TEXT,scv2 TEXT,label1 TEXT,label2 TEXT,reported TEXT);''')
 start=time.monotonic();counts={}
 for kind,stem,header,convert in [
  ('submission','submission_summary','#VariationID',lambda r:(r['SCV'].split('.')[0],r['SCV'].partition('.')[2],r['#VariationID'],r['ClinicalSignificance'],r['ReviewStatus'],date(r['DateLastEvaluated']),r['ContributesToAggregateClassification'])),
  ('variant','variant_summary','#AlleleID',lambda r:(r['VariationID'],r['#AlleleID'],r['Assembly'],r['ClinicalSignificance'],r['ReviewStatus'])),
  ('pair','summary_of_conflicting_interpretations','#Gene_Symbol',lambda r:(r['NCBI_Variation_ID'],r['Submitter1_SCV'].split('.')[0],r['Submitter2_SCV'].split('.')[0],r['Submitter1_ClinSig'],r['Submitter2_ClinSig'],r['Conflict_Reported']))]:
  source=raw/f'{stem}_{month}.txt.gz';provenance=json.loads(source.with_name(source.name+'.provenance.json').read_text());assert provenance['status']=='verified download' and source.stat().st_size==provenance['bytes']
  batch=[];n=0
  for row in rows(source,header):
   batch.append(convert(row));n+=1
   if len(batch)==10000:
    c.executemany('INSERT INTO '+kind+' VALUES('+','.join('?'*len(batch[0]))+')',batch);batch=[]
   if n%200000==0:c.commit();print(json.dumps({'table':kind,'rows':n,'elapsed_seconds':round(time.monotonic()-start)}),flush=True)
  if batch:c.executemany('INSERT INTO '+kind+' VALUES('+','.join('?'*len(batch[0]))+')',batch)
  c.commit();counts[kind]=n
 c.execute('CREATE INDEX submission_scv ON submission(scv)');c.execute('CREATE INDEX variant_vid ON variant(variation_id)');c.commit()
 c.execute('ATTACH DATABASE ? AS src',(str(root/'normalized'/month/'vcv.sqlite'),));c.execute('ATTACH DATABASE ? AS cohort',(str(out/'units.sqlite'),))
 c.execute('PRAGMA src.cache_size=-262144');c.execute('PRAGMA cohort.cache_size=-131072')
 # Copy the exact comparison columns once to reduce random external HDD reads.
 c.execute('CREATE TABLE validation_assertions AS SELECT scv,version,variation_id,class_type,label,review,evaluated,contributes FROM src.assertions')
 c.execute('CREATE UNIQUE INDEX validation_assertions_scv ON validation_assertions(scv)');c.commit()
 c.execute('CREATE TABLE validation_variants AS SELECT variation_id,direct_simple,allele_id,official_label,official_review FROM src.variants NOT INDEXED')
 c.execute('CREATE UNIQUE INDEX validation_variants_id ON validation_variants(variation_id)');c.commit()
 report={'source_parser':'Literal tab-separated physical rows with exact column-count validation; quotation marks remain literal source values','representation_normalization':'yes/no versus true/false/1/0 only for the contribution flag; dash versus absent only for missing aggregate label/review; raw values retained in discrepancy exports','rows':counts,'checks':{},'interpretation':'Matched dated tabular exports provide additional independent representation checks. All nonzero mismatch counts require review. Pair-report scope is not the primary condition-specific cohort.'}
 checks=report['checks']
 queries={
 'submission_scv_missing_xml':'SELECT t.scv,t.variation_id FROM submission t LEFT JOIN validation_assertions a USING(scv) WHERE a.scv IS NULL',
 'xml_scv_missing_submission':'SELECT a.scv,a.variation_id FROM validation_assertions a LEFT JOIN submission t USING(scv) WHERE t.scv IS NULL',
 'submission_duplicate_scv':'SELECT scv,count(*) rows FROM submission GROUP BY scv HAVING count(*)>1',
 'submission_id_mismatch':"SELECT t.scv,t.variation_id tabular_vid,a.variation_id xml_vid,t.version tabular_version,a.version xml_version FROM submission t JOIN validation_assertions a USING(scv) WHERE t.variation_id<>a.variation_id OR (t.version<>'' AND t.version<>a.version)",
 'submission_label_mismatch':"SELECT t.scv,t.label tabular_value,a.label xml_value FROM submission t JOIN validation_assertions a USING(scv) WHERE a.class_type='germline' AND norm(t.label)<>norm(a.label)",
 'submission_review_mismatch':'SELECT t.scv,t.review tabular_value,a.review xml_value FROM submission t JOIN validation_assertions a USING(scv) WHERE norm(t.review)<>norm(a.review)',
 'submission_date_mismatch':'SELECT t.scv,t.evaluated tabular_value,a.evaluated xml_value FROM submission t JOIN validation_assertions a USING(scv) WHERE t.evaluated<>a.evaluated',
 'submission_contributes_mismatch':'SELECT t.scv,t.contributes tabular_value,a.contributes xml_value FROM submission t JOIN validation_assertions a USING(scv) WHERE boolean(t.contributes)<>boolean(a.contributes)',
 'variant_missing_xml':'SELECT DISTINCT t.variation_id FROM variant t LEFT JOIN validation_variants v USING(variation_id) WHERE v.variation_id IS NULL',
 'variant_direct_allele_mismatch':'SELECT DISTINCT t.variation_id,t.allele_id tabular_value,v.allele_id xml_value FROM variant t JOIN validation_variants v USING(variation_id) WHERE v.direct_simple=1 AND t.allele_id<>v.allele_id',
 'variant_direct_label_mismatch':'SELECT DISTINCT t.variation_id,t.label tabular_value,v.official_label xml_value FROM variant t JOIN validation_variants v USING(variation_id) WHERE v.direct_simple=1 AND missing(t.label)<>missing(v.official_label)',
 'variant_direct_review_mismatch':'SELECT DISTINCT t.variation_id,t.review tabular_value,v.official_review xml_value FROM variant t JOIN validation_variants v USING(variation_id) WHERE v.direct_simple=1 AND missing(t.review)<>missing(v.official_review)',
 'pair_scv_missing_or_wrong_variant':'''SELECT p.variation_id,p.scv1,p.scv2,a.variation_id xml_vid1,b.variation_id xml_vid2 FROM pair p LEFT JOIN validation_assertions a ON a.scv=p.scv1 LEFT JOIN validation_assertions b ON b.scv=p.scv2 WHERE a.scv IS NULL OR b.scv IS NULL OR a.variation_id<>p.variation_id OR b.variation_id<>p.variation_id''',
 'pair_label_mismatch':'''SELECT p.variation_id,p.scv1,p.scv2,p.label1 tabular_label1,a.label xml_label1,p.label2 tabular_label2,b.label xml_label2 FROM pair p JOIN validation_assertions a ON a.scv=p.scv1 JOIN validation_assertions b ON b.scv=p.scv2 WHERE (a.class_type='germline' AND norm(p.label1)<>norm(a.label)) OR (b.class_type='germline' AND norm(p.label2)<>norm(b.label))'''}
 for name,query in queries.items():
  cur=c.execute(query);columns=[x[0] for x in cur.description];n=[0]
  def counted():
   for row in cur:n[0]+=1;yield tuple(row)
  export(out/(name+'.csv.gz'),columns,counted());checks[name]=n[0]
  print(json.dumps({'check':name,'discrepancies':n[0]}),flush=True)
 checks['submission_version_unspecified']=c.execute("SELECT count(*) FROM submission WHERE version='' ").fetchone()[0]
 checks['unparsed_evaluation_dates']=c.execute("SELECT count(*) FROM submission WHERE evaluated LIKE 'UNPARSED:%'").fetchone()[0]
 # Materialize retained SCV -> eligible unit membership with an SCV-first index.
 c.execute("CREATE TABLE qualifying_scv AS SELECT a.scv,a.unit_key FROM cohort.unit_assertions a JOIN cohort.units u ON u.mode=a.mode AND u.unit_key=a.unit_key WHERE a.mode='primary' AND u.eligible=1")
 c.execute('CREATE INDEX qualifying_scv_id ON qualifying_scv(scv,unit_key)')
 q='''SELECT p.reported,EXISTS(SELECT 1 FROM qualifying_scv a JOIN qualifying_scv b USING(unit_key) WHERE a.scv=p.scv1 AND b.scv=p.scv2) same_eligible_primary_unit,COUNT(*) pairs FROM pair p GROUP BY p.reported,same_eligible_primary_unit'''
 export(out/'official_pair_report_scope.csv',['official_conflict_reported','same_eligible_primary_unit','pair_rows'],(tuple(r) for r in c.execute(q)))
 report['automated_exact_checks_passed']=not any(checks.values());report['review_status']='requires discrepancy interpretation' if any(checks.values()) else 'exact checks passed; scope and denominator interpretation still required'
 (out/'tabular_validation.json').write_text(json.dumps(report,indent=2)+'\n');c.commit();c.close();part.rename(final)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
