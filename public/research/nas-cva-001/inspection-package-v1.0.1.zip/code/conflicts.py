"""Prespecified label comparisons. These are not variant classifications."""
from itertools import combinations
from collections import defaultdict
STANDARD={'pathogenic':'P','likely pathogenic':'LP','uncertain significance':'U','likely benign':'LB','benign':'B','vus-high':'U','vus-mid':'U','vus-low':'U','pathogenic/likely pathogenic':'PLP','benign/likely benign':'BLB'}
SPECIAL={'pathogenic, low penetrance','likely pathogenic, low penetrance','established risk allele','likely risk allele','uncertain risk allele','risk factor','association','drug response','protective','affects','other','not provided','conflicting data from submitters'}
POS={'P','LP','PLP'}; NEG={'B','LB','BLB'}
def canonical(label):return STANDARD.get(' '.join(label.lower().split()),'SPECIAL' if ' '.join(label.lower().split()) in SPECIAL else 'UNKNOWN')
def tier(a,b):
    if a in POS and b in NEG or b in POS and a in NEG:return 1
    if a in POS and b=='U' or b in POS and a=='U':return 2
    if a in NEG and b=='U' or b in NEG and a=='U':return 3
    if {a,b} in ({'P','LP'},{'B','LB'}):return 4
    return 0

def unit(labels_by_org,allow_internal=False):
    clean={o:set(ls) for o,ls in labels_by_org.items() if o and (allow_internal or len(set(ls))==1)}
    clean={o:{x for x in ls if x not in {'UNKNOWN','SPECIAL'}} for o,ls in clean.items()}
    clean={o:ls for o,ls in clean.items() if ls}
    flags=set()
    for a,b in combinations(clean,2):
        for x in clean[a]:
            for y in clean[b]:
                t=tier(x,y)
                if t:flags.add(t)
    return dict(eligible=len(clean)>=2,organizations=len(clean),tier=min(flags) if flags else 0,pair_tiers=sorted(flags))
