"""Replay frozen research calculations in an explicitly selected external root.
The release manifest is assembled only after all source files are verified.
Human/AI case review and publication visual inspection are separate recorded steps.
"""
import argparse,datetime,hashlib,importlib.metadata,json,os,platform,subprocess,sys,time
from pathlib import Path

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def verify_protocol(folder):
 freezes=sorted(folder.glob('*/FREEZE.json'))
 assert freezes,'Frozen protocol and addenda are required'
 checked=[]
 for freeze in freezes:
  data=json.loads(freeze.read_text())
  files=data['files'] if 'files' in data else {'addendum.md':data['sha256']}
  assert files,'Empty protocol freeze'
  for relative,expected in files.items():
   rel=Path(relative);assert not rel.is_absolute() and '..' not in rel.parts
   path=(freeze.parent/rel).resolve();assert path.is_relative_to(freeze.parent.resolve())
   assert digest(path)==expected,'Frozen protocol changed: '+relative
  checked.append({'freeze':str(freeze.relative_to(folder)),'passed':True})
 return checked

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--download',action='store_true');p.add_argument('--verify-only',action='store_true');p.add_argument('--protocol-root',type=Path,default=Path(__file__).resolve().parent.parent/'protocol');a=p.parse_args()
 protocol_checks=verify_protocol(a.protocol_root.resolve())
 root=a.root.resolve();root.mkdir(parents=True,exist_ok=True)
 (root/'protocol_verification.json').write_text(json.dumps({'checks':protocol_checks,'passed':True},indent=2)+'\n')
 for name in ['tmp','logs','environment']: (root/name).mkdir(exist_ok=True)
 env=os.environ.copy();env.update(TMPDIR=str(root/'tmp'),SQLITE_TMPDIR=str(root/'tmp'),MPLCONFIGDIR=str(root/'tmp/matplotlib'),PYTHONDONTWRITEBYTECODE='1')
 # Libraries must already be installed from requirements.txt in this interpreter.
 code=Path(__file__).resolve().parent
 dependencies={}
 for line in (code/'requirements-statistics.lock').read_text().splitlines():
  if not line.strip() or line.startswith('#'):continue
  name,expected=line.split('==',1);installed=importlib.metadata.version(name);assert installed==expected,f'Locked dependency differs: {name}: {installed} != {expected}';dependencies[name]=installed
 runtime={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'python_implementation':platform.python_implementation(),'platform':platform.platform(),'architecture':platform.machine(),'dependencies':dependencies,'dependency_lock_sha256':digest(code/'requirements-statistics.lock'),'replay_script_sha256':digest(Path(__file__).resolve())}
 (root/'runtime_record.json').write_text(json.dumps(runtime,indent=2)+'\n')
 manifest=json.loads(a.manifest.read_text());assert manifest['status']=='frozen_verified_sources'
 local_manifest=root/'source_manifest.json'
 if local_manifest.exists():assert digest(local_manifest)==digest(a.manifest),'Replay source manifest differs from existing local freeze'
 else:local_manifest.write_bytes(a.manifest.read_bytes());local_manifest.chmod(0o444)
 for item in manifest['sources']:
  rel=Path(item['relative_path']);assert not rel.is_absolute() and '..' not in rel.parts
  dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  retrieved=None;headers=dest.with_name(dest.name+'.headers')
  if not dest.exists():
   assert a.download,f'Missing frozen input: {rel}; use --download to retrieve it.'
   part=dest.with_name(dest.name+'.part');assert not part.exists(),'Existing partial input requires explicit investigation'
   retrieved=datetime.datetime.now(datetime.timezone.utc).isoformat()
   subprocess.run(['curl','--fail','--location','--retry','3','--dump-header',str(headers),item['url'],'--output',str(part)],env=env,check=True)
   assert part.stat().st_size==item['bytes'] and digest(part)==item['sha256'],f'Source no longer matches freeze: {rel}'
   part.rename(dest);dest.chmod(0o444)
  else:assert dest.stat().st_size==item['bytes'] and digest(dest)==item['sha256'],f'Frozen input changed: {rel}'
  provenance_file=dest.with_name(dest.name+'.provenance.json')
  if provenance_file.exists():
   assert json.loads(provenance_file.read_text())['sha256']==item['sha256'],'Existing provenance contradicts frozen source'
  else:
   provenance={'status':'verified download','url':item['url'],'relative_path':str(rel),'bytes':item['bytes'],'sha256':item['sha256'],'verification_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retrieval_started_utc':retrieved,'retrieval_finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat() if retrieved else None,'verification_context':'fresh replay download' if retrieved else 'preexisting local frozen source verified; retrieval date not asserted','http_headers':headers.name if retrieved else None,'original_freeze_provenance':item.get('provenance')}
   provenance_file.write_text(json.dumps(provenance,indent=2)+'\n')
 if a.verify_only:return
 assert not (root/'normalized').exists() and not (root/'analysis').exists(),'Use a fresh replay root; existing study outputs are never replaced.'
 commands=[]
 for month in ['2025-09','2026-03','2026-09']:
  for script in ['normalize_vcv.py','normalize_rcv.py','verify_snapshots.py','reconcile_sources.py','audit_reconciliation.py','build_units.py','independent_counts.py','summarize.py','exploratory.py','validate_analysis.py','source_dimension_participation.py','source_inventory.py','source_assertion_counts.py','validate_tabular.py','tabular_discrepancy_context.py']:commands.append([script,str(root),month])
 commands += [['source_audit.py',str(root),'2026-09','--select','--scan'],['source_audit_rcv.py',str(root),'2026-09'],['validate_coordinates.py',str(root),'2026-09','clinvar_20260829.vcf.gz'],['history.py',str(root)],['history_associations.py',str(root)],['resolution_changes.py',str(root)],['figures.py',str(root),'2026-09'],['export_catalog.py',str(root)]]
 journal=[]
 for i,args in enumerate(commands,1):
  log=root/'logs'/f'{i:02d}-{Path(args[0]).stem}-{args[2] if len(args)>2 else "history"}.log'
  print(f'[{i}/{len(commands)}] {args[0]}',flush=True)
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();timer=time.monotonic()
  with log.open('w') as f:result=subprocess.run([sys.executable,str(code/args[0]),*args[1:]],env=env,stdout=f,stderr=subprocess.STDOUT)
  journal.append({'step':i,'script':args[0],'arguments':args[2:],'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-timer,'command':[sys.executable,str(code/args[0]),*args[1:]],'exit_code':result.returncode,'code_sha256':digest(code/args[0]),'log':str(log.relative_to(root))})
  (root/'replay_journal.json').write_text(json.dumps(journal,indent=2)+'\n')
  assert result.returncode==0,f'Replay stopped at {args[0]}; inspect {log}'
 print('Computational replay finished. Case review, figure/page inspection and publication-readiness audit remain separate requirements.')
if __name__=='__main__':main()
