"""Prespecified method and reported organization-type unit participation."""
import argparse,itertools,json,sqlite3
from collections import Counter,defaultdict
from pathlib import Path
from summarize import export

def run(root,month):
 out=root/'analysis'/month
 assert json.loads((out/'independent_validation.json').read_text())['passed']
 db=sqlite3.connect((out/'units.sqlite').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 query="""SELECT u.unit_key,u.tier,a.org_type,a.methods_json FROM unit_assertions a JOIN units u ON u.mode=a.mode AND u.unit_key=a.unit_key WHERE a.mode='primary' AND u.eligible=1 ORDER BY u.unit_key"""
 counts=defaultdict(Counter);seen=0
 for unit_key,iterator in itertools.groupby(db.execute(query),key=lambda row:row['unit_key']):
  rows=list(iterator);tiers={row['tier'] for row in rows};assert len(tiers)==1
  tier=next(iter(tiers));seen+=1
  types={row['org_type'].strip() if row['org_type'].strip() else '[unreported]' for row in rows}
  methods=set()
  for row in rows:
   values=json.loads(row['methods_json'])
   assert isinstance(values,list)
   methods.update(value if value else '[unreported]' for value in values)
   if not values:methods.add('[unreported]')
  for dimension,categories in [('collection_method',methods),('reported_organization_type',types)]:
   for category in categories:counts[(dimension,category)][tier]+=1
 expected=db.execute("SELECT count(*) FROM units WHERE mode='primary' AND eligible=1").fetchone()[0]
 assert seen==expected,'Every eligible primary unit must have retained qualifying assertions'
 rows=[]
 for (dimension,category),tiers in sorted(counts.items()):
  n=sum(tiers.values());k12=sum(tiers[t] for t in (1,2));k123=sum(tiers[t] for t in (1,2,3))
  assert 0<=k12<=k123<=n<=expected
  rows.append([dimension,category,n,k12,k123,*[tiers[t] for t in range(5)]])
 columns=['source_dimension','reported_category','eligible_unit_participation','T1_T2_unit_participation','T1_T3_unit_participation','T0','T1','T2','T3','T4']
 export(out/'tables/source_dimension_participation.csv',columns,rows)
 report={'month':month,'eligible_primary_units':expected,'units_checked':seen,'category_rows':len(rows),'passed':True,
 'estimand':'An eligible primary condition/inheritance unit with at least one retained qualifying assertion reporting the category; count once per category',
 'overlap':'A unit can occur in multiple categories. Category denominators must not be added into a study denominator. Unreported assertion metadata remains a separate overlapping category.',
 'interpretation':'Descriptive participation; collection method and source-reported organization category are not causal exposures or judgments of quality.'}
 (out/'source_dimension_validation.json').write_text(json.dumps(report,indent=2)+'\n');db.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
