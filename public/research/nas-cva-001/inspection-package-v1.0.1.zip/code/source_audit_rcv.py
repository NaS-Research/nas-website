"""Independent raw RCV membership/aggregate audit for the prespecified sample."""
import argparse, gzip, json, sqlite3, time
from pathlib import Path
from lxml import etree

def extract(element):
 ref=element.xpath('./ReferenceClinVarAssertion')[0]
 access=ref.xpath('./ClinVarAccession')[0]
 measures=ref.xpath('./MeasureSet | ./GenotypeSet')
 def text(node,path):
  found=node.xpath(path)
  return str(found[0]).strip() if found else ''
 ids=sorted(set(ref.xpath('./TraitSet/Trait/XRef[@DB="MedGen"]/@ID')))
 record={'rcv':access.get('Acc',''),'version':access.get('Version',''),
 'variation_id':measures[0].get('ID','') if measures else '',
 'status':text(ref,'./RecordStatus/text()'),
 'official_label':text(ref,'./Classifications/GermlineClassification/Description/text()'),
 'official_review':text(ref,'./Classifications/GermlineClassification/ReviewStatus/text()'),
 'condition_ids':ids}
 members=[]
 for assertion in element.xpath('./ClinVarAssertion'):
  accession=assertion.xpath('./ClinVarAccession')[0]
  members.append({'scv':accession.get('Acc',''),'version':accession.get('Version',''),
  'rcv':record['rcv'],'variation_id':record['variation_id'],'org_id':accession.get('OrgID',''),
  'label':text(assertion,'./Classification/GermlineClassification/text()'),
  'review':text(assertion,'./Classification/ReviewStatus/text()'),
  'evaluated':text(assertion,'./Classification/@DateLastEvaluated')})
 return record,members

def run(root,month):
 out=root/'analysis'/month
 sample=json.loads((out/'validation_sample.json').read_text())
 wanted_scvs={scv for case in sample['cases'] for scv in case['scvs']}
 c=sqlite3.connect((root/'normalized'/month/'rcv.sqlite').as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 expected_members={}
 for scv in sorted(wanted_scvs):
  for row in c.execute('SELECT * FROM membership WHERE scv=?',(scv,)):expected_members[(row['scv'],row['rcv'])]=dict(row)
 wanted_rcvs={rcv for scv,rcv in expected_members};expected_records={}
 for rcv in sorted(wanted_rcvs):
  row=dict(c.execute('SELECT * FROM rcvs WHERE rcv=?',(rcv,)).fetchone())
  traits=json.loads(row.pop('conditions_json'))
  row['condition_ids']=sorted({x['ID'] for trait in traits for x in trait['ids'] if x.get('DB')=='MedGen' and x.get('ID')})
  expected_records[rcv]=row
 c.close();seen_records=set();seen_members=set();records=[];members=[];errors=[];n=0;start=time.monotonic()
 with gzip.open(root/'raw'/month/f'ClinVarRCVRelease_{month}.xml.gz','rb') as source:
  for _,element in etree.iterparse(source,events=('end',),tag='ClinVarSet',huge_tree=True):
   access=element.xpath('./ReferenceClinVarAssertion/ClinVarAccession/@Acc')
   if access and access[0] in wanted_rcvs:
    record,assertions=extract(element);seen_records.add(record['rcv']);records.append(record)
    differences={k:{'raw':value,'normalized':expected_records[record['rcv']].get(k)} for k,value in record.items() if value!=expected_records[record['rcv']].get(k)}
    if differences:errors.append({'type':'aggregate','rcv':record['rcv'],'differences':differences})
    for member in assertions:
     if member['scv'] not in wanted_scvs:continue
     key=(member['scv'],member['rcv']);seen_members.add(key);members.append(member);expected=expected_members.get(key,{})
     differences={k:{'raw':value,'normalized':expected.get(k)} for k,value in member.items() if value!=expected.get(k)}
     if differences:errors.append({'type':'membership','scv':member['scv'],'rcv':member['rcv'],'differences':differences})
   n+=1;element.clear()
   while element.getprevious() is not None:del element.getparent()[0]
   if n%200000==0:print(json.dumps({'rcvs_scanned':n,'seconds':round(time.monotonic()-start)}),flush=True)
 report={'records_scanned':n,'expected_rcvs':len(wanted_rcvs),'found_rcvs':len(seen_records),
 'missing_rcvs':sorted(wanted_rcvs-seen_records),'expected_memberships':len(expected_members),'found_memberships':len(seen_members),
 'missing_memberships':[list(x) for x in sorted(set(expected_members)-seen_members)],'unexpected_memberships':[list(x) for x in sorted(seen_members-set(expected_members))],
 'differences':errors,'records':sorted(records,key=lambda x:x['rcv']),'memberships':sorted(members,key=lambda x:(x['scv'],x['rcv'])),
 'method':'Separate XPath extraction from raw dated RCV XML; does not import production normalization or cohort functions',
 'human_review':False,'review_state':'Automated raw membership/aggregate check; explicit sampled-case inspection remains separate'}
 report['passed']=not any(report[k] for k in ('missing_rcvs','missing_memberships','unexpected_memberships','differences'))
 (out/'raw_rcv_sample_audit.json').write_text(json.dumps(report,indent=2)+'\n')
 assert report['passed'],'Raw RCV sample discrepancies require investigation'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
