"""Complete label and metadata inventories; retain uncommon source vocabulary."""
import argparse,json,re,sqlite3
from datetime import datetime,timezone
def progress(message):
 print(datetime.now(timezone.utc).isoformat(),message,flush=True)
from pathlib import Path
from collections import Counter
from summarize import export
from conflicts import canonical

def label_family(label):
 value=' '.join(label.lower().split());code=canonical(label)
 low='low penetrance' in value;risk=bool(re.search(r'\brisk\b',value))
 family='standard_pathogenicity' if code not in {'SPECIAL','UNKNOWN'} else 'low_penetrance_containing' if low else 'risk_containing' if risk else 'missing' if not value else 'other_recognized_nonstandard' if code=='SPECIAL' else 'unrecognized_or_mixed'
 return code,family,low,risk

def run(root,month):
 out=root/'analysis'/month;out.mkdir(parents=True,exist_ok=True)
 c=sqlite3.connect(f'file:{root/"normalized"/month/"vcv.sqlite"}?mode=ro',uri=True)
 c.execute('PRAGMA cache_size=-524288')
 c.execute('PRAGMA temp_store=FILE')
 # One sequential scan preserves the same group counts without repeated
 # external-drive scans and SQLite temporary sorts.
 fields=['label','review','status','class_type','org_type','contributes']
 json_fields=['inheritance_json','origins_json','methods_json']
 counts={field:Counter() for field in fields}
 memberships={field:Counter() for field in json_fields}
 analytic=Counter();label_review=Counter()
 progress('starting single-pass source vocabulary inventory')
 for index,row in enumerate(c.execute('SELECT '+','.join(fields+json_fields)+' FROM assertions'),1):
  label,review,status,branch,org_type,contributes,*arrays=row
  analytic[(branch,label)]+=1
  label_review[(branch,label,review)]+=1
  for field,value in zip(fields,row[:len(fields)]):counts[field][value]+=1
  for field,raw in zip(json_fields,arrays):
   values=json.loads(raw)
   for value in set(values) if values else ['[missing]']:memberships[field][value]+=1
  if index%1000000==0:progress(f'inventoried {index} assertions')
 # SQLite sorts NULL before text; retain that order in exported inventories.
 def sql_key(value):return (value is not None,value or '')
 export(out/'source_analytic_label_inventory.csv',['class_type','source_label','canonical_label','label_family','contains_low_penetrance','contains_risk_term','assertions'],([branch,label,*label_family(label),n] for (branch,label),n in sorted(analytic.items(),key=lambda x:tuple(sql_key(v) for v in x[0]))))
 for field in fields:
  export(out/f'source_{field}_inventory.csv',[field,'assertions'],sorted(counts[field].items(),key=lambda x:(-x[1],sql_key(x[0]))))
 for field in json_fields:
  export(out/f'source_{field}_inventory.csv',['value','assertions_containing_value'],sorted(memberships[field].items(),key=lambda x:(-x[1],x[0])))
 export(out/'source_label_review_inventory.csv',['class_type','label','review','assertions'],([*key,n] for key,n in sorted(label_review.items(),key=lambda x:(-x[1],*(sql_key(v) for v in x[0])))))
 c.close()
 progress('source inventory complete')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
