import gzip,json,os,sqlite3,tempfile,unittest
from pathlib import Path
from validate_coordinates import run
class Coordinates(unittest.TestCase):
 def test_vcf_fields_not_hgvs_position(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   root=Path(temp);n=root/'normalized/2026-09';n.mkdir(parents=True);r=root/'raw/2026-09';r.mkdir(parents=True)
   c=sqlite3.connect(n/'vcv.sqlite');c.executescript('CREATE TABLE variants(variation_id TEXT PRIMARY KEY,direct_simple INTEGER,allele_id TEXT,coordinates_json TEXT);CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);')
   c.execute('INSERT INTO metadata VALUES(?,?)',('release',json.dumps({'ReleaseDate':'2026-08-29'})))
   coords={'Assembly':'GRCh38','Chr':'1','start':'108','positionVCF':'105','referenceAlleleVCF':'AAA','alternateAlleleVCF':'A'}
   c.execute('INSERT INTO variants VALUES(?,?,?,?)',('1',1,'10',json.dumps([coords])));c.execute('INSERT INTO variants VALUES(?,?,?,?)',('2',1,'20',json.dumps([coords])));c.commit();c.close()
   source=r/'test.vcf.gz'
   with gzip.open(source,'wt') as f:f.write('##fileDate=2026-08-29\n##reference=GRCh38\n#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n1\t105\t1\tAAA\tA\t.\t.\tALLELEID=10\n1\t105\t2\tAAA\tA\t.\t.\tALLELEID=999\n')
   source.with_name(source.name+'.provenance.json').write_text(json.dumps({'status':'verified download'}))
   run(root,'2026-09','test.vcf.gz');report=json.loads((root/'analysis/2026-09/coordinate_validation.json').read_text())
   self.assertEqual(report['rows_by_status'],{'allele_id_mismatch':1,'exact_source_vcf_representation':1})
if __name__=='__main__':unittest.main()
