import unittest
from reconcile_sources import allowed_errors,incomplete_ids
class ReconciliationTests(unittest.TestCase):
 def test_exact_versions_only(self):
  expected=[['SCV1','version','2','1']]
  self.assertTrue(allowed_errors([('SCV1','version','2','1')],expected))
  for observed in [[],expected*2,[['SCV1','version','3','1']],[['SCV1','label','Pathogenic','Benign']]]:
   self.assertFalse(allowed_errors(observed,expected))
 def test_incomplete_both_directions(self):
  self.assertEqual(incomplete_ids({'rcv_only_records':[{'variation_id':'1'}],'vcv_only_records':[{'variation_id':'2'}]}),{'1','2'})
if __name__=='__main__':unittest.main()
