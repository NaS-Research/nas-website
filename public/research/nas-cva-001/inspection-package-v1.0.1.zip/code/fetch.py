"""Fetch exact public snapshots into a caller-specified existing data root."""
import argparse,datetime,hashlib,json,os,subprocess
from pathlib import Path

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes(p):
    sha=hashlib.sha256(); md5=hashlib.md5()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): sha.update(b);md5.update(b)
    return sha.hexdigest(),md5.hexdigest()
def fetch(root,url,relative,expected_size=None,publisher_md5=False):
    dest=root/relative; dest.parent.mkdir(parents=True,exist_ok=True)
    manifest=dest.with_name(dest.name+'.provenance.json')
    if dest.exists() and manifest.exists():
        old=json.loads(manifest.read_text()); sha,md5=hashes(dest)
        assert sha==old['sha256'],f'Changed frozen file: {relative}'
        return old
    assert not dest.exists(),f'Unmanifested finalized file: {relative}'
    part=dest.with_name(dest.name+'.part'); headers=dest.with_name(dest.name+'.headers')
    started=now();resumed_from=part.stat().st_size if part.exists() else 0
    initial_started=datetime.datetime.fromtimestamp(part.stat().st_birthtime,datetime.timezone.utc).isoformat() if part.exists() and hasattr(part.stat(),'st_birthtime') else started
    attempts=dest.with_name(dest.name+'.attempts.jsonl')
    if headers.exists() and resumed_from:
        saved=dest.with_name(dest.name+'.headers.before-resume-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S'))
        saved.write_bytes(headers.read_bytes())
    with attempts.open('a') as f:f.write(json.dumps({'started_utc':started,'resumed_from_bytes':resumed_from})+'\n')
    assert expected_size is None or resumed_from<=expected_size,'Partial download exceeds the frozen source size'
    if expected_size is None or resumed_from!=expected_size:
        subprocess.run(['curl','-sS','-L','--fail','--retry','3','--connect-timeout','30','-C','-','-D',str(headers),url,'-o',str(part)],check=True)
    sha,md5=hashes(part)
    if expected_size is not None: assert part.stat().st_size==expected_size
    source_md5=None
    if publisher_md5:
        checksum=dest.with_name(dest.name+'.md5')
        subprocess.run(['curl','-sS','-L','--fail',url+'.md5','-o',str(checksum)],check=True)
        source_md5=checksum.read_text().split()[0]
        assert md5==source_md5,f'Publisher MD5 mismatch {relative}'
    record=dict(url=url,relative_path=str(relative),retrieval_started_utc=initial_started,last_attempt_started_utc=started,resumed_from_bytes=resumed_from,retrieval_start_basis='partial-file creation time' if resumed_from else 'transfer invocation time',retrieval_finished_utc=now(),bytes=part.stat().st_size,sha256=sha,md5=md5,publisher_md5=source_md5,http_headers=headers.name,status='verified download',source_release_date='see dated filename, source listing and XML metadata')
    part.rename(dest);dest.chmod(0o444)
    manifest.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'downloaded':str(relative),'bytes':record['bytes'],'sha256':sha}),flush=True)
    return record
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('--history',action='store_true');ap.add_argument('--support',action='store_true');ap.add_argument('--rcv',action='store_true');a=ap.parse_args();assert a.root.is_dir()
    if a.history:
        for month,size in [('2025-09',5032951953),('2026-03',5747209323)]:
            name=f'ClinVarVCVRelease_{month}.xml.gz'
            fetch(a.root,'https://ftp.ncbi.nlm.nih.gov/pub/clinvar/xml/'+name,Path('raw')/month/name,size,True)
    if a.rcv:
        for month,size in [('2026-09',6018665816),('2025-09',5076674765),('2026-03',5854969455)]:
            name=f'ClinVarRCVRelease_{month}.xml.gz'
            fetch(a.root,'https://ftp.ncbi.nlm.nih.gov/pub/clinvar/xml/RCV_release/'+name,Path('raw')/month/name,size,True)
    if a.support:
        for month in ['2025-09','2026-03','2026-09']:
            for stem in ['variant_summary','submission_summary','summary_of_conflicting_interpretations']:
                name=f'{stem}_{month}.txt.gz'
                fetch(a.root,'https://ftp.ncbi.nlm.nih.gov/pub/clinvar/tab_delimited/archive/'+name,Path('raw')/month/name)
