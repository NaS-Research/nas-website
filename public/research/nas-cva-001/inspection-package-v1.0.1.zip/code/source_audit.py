"""Deterministic case selection and independent field audit against raw XML."""
import argparse,gzip,hashlib,json,sqlite3,time
from collections import defaultdict
from pathlib import Path
from lxml import etree

def rank(key):return hashlib.sha256(('20260926|'+key).encode()).hexdigest()
def select(root,month):
 out=root/'analysis'/month;con=sqlite3.connect(f'file:{out/"units.sqlite"}?mode=ro',uri=True);con.row_factory=sqlite3.Row
 con.execute('ATTACH DATABASE ? AS src',(str(root/'normalized'/month/'vcv.sqlite'),));con.execute('ATTACH DATABASE ? AS rcv',(str(root/'normalized'/month/'rcv.sqlite'),))
 strata=defaultdict(list)
 def consider(category,uk,vid):
  candidate={'unit_key':uk,'variation_id':vid,'stratum':category,'rank':rank(uk)}
  pool=strata[category]
  if any(x['unit_key']==uk for x in pool):return
  pool.append(candidate);pool.sort(key=lambda z:z['rank']);del pool[20:]
 for x in con.execute("SELECT unit_key,variation_id,tier,eligible FROM units WHERE mode='primary'"):
  category='T'+str(x['tier']) if x['eligible'] and x['tier'] else 'concordant' if x['eligible'] else 'excluded'
  consider(category,x['unit_key'],x['variation_id'])
 # Include units absent from the primary table because all assertions failed eligibility.
 for x in con.execute("SELECT e.unit_key,e.variation_id FROM exclusions e LEFT JOIN units u ON u.mode='primary' AND u.unit_key=e.unit_key WHERE coalesce(u.eligible,0)=0"):
  consider('excluded',x['unit_key'],x['variation_id'])
 selected=[x for s in ['T1','T2','T3','T4','concordant','excluded'] for x in strata[s]]
 for case in selected:
  vid,rcv,inheritance=case['unit_key'].split('|',2)
  if rcv.startswith('NO_RCV:'):
   case['scvs']=[rcv.split(':',1)[1]];case['audit_unit_type']='ungroupable excluded assertion'
  else:
   case['scvs']=[x[0] for x in con.execute('SELECT a.scv FROM src.assertions a JOIN rcv.membership m USING(scv) WHERE a.variation_id=? AND m.rcv=? AND a.inheritance_json=? ORDER BY a.scv',(vid,rcv,inheritance))]
   case['audit_unit_type']='exact condition-inheritance unit, including excluded assertion context'
 (out/'validation_sample.json').write_text(json.dumps({'seed':20260926,'selection':'lowest SHA-256 within six prespecified strata, at most 20 each; excluded pool includes wholly ineligible source units','cases':selected,'counts':{s:len(strata[s]) for s in ['T1','T2','T3','T4','concordant','excluded']}},indent=2)+'\n');con.close()

def raw_assertion(a):
 # Independent XPath extraction deliberately avoids the production rows()/txt()/attr() functions.
 accession=a.xpath('./ClinVarAccession')[0]
 inheritance=sorted(set(a.xpath('./AttributeSet/Attribute[@Type="ModeOfInheritance"]/text()')+a.xpath('./TraitSet/Trait/AttributeSet/Attribute[@Type="ModeOfInheritance"]/text()')+a.xpath('.//ModeOfInheritance/text()')))
 def text(path):
  result=a.xpath(path);return str(result[0]).strip() if result else ''
 return {'scv':accession.get('Accession',''),'version':accession.get('Version',''),'org_id':accession.get('OrgID',''),'label':text('./Classification/GermlineClassification/text()'),'review':text('./Classification/ReviewStatus/text()'),'evaluated':text('./Classification/@DateLastEvaluated'),'status':text('./RecordStatus/text()'),'inheritance_json':json.dumps(inheritance,separators=(',',':'))}

def scan(root,month):
 source=root/'raw'/month/f'ClinVarVCVRelease_{month}.xml.gz';out=root/'analysis'/month;out.mkdir(exist_ok=True,parents=True)
 sample_path=out/'validation_sample.json';sample=json.loads(sample_path.read_text()) if sample_path.exists() else {'cases':[]}
 wanted={x for c in sample['cases'] for x in c['scvs']};seen=set();cases=[];issues=[];n=0;t=time.monotonic()
 con=sqlite3.connect(f'file:{root/"normalized"/month/"vcv.sqlite"}?mode=ro',uri=True);con.row_factory=sqlite3.Row
 path=root/'normalized'/month/'lineage.sqlite';assert not path.exists();db=sqlite3.connect(path.with_suffix('.sqlite.part'));db.execute('CREATE TABLE lineage(variation_id TEXT PRIMARY KEY,replaced_by TEXT,replaced_records TEXT)')
 with gzip.open(source,'rb') as f:
  for _,v in etree.iterparse(f,events=('end',),tag='VariationArchive',huge_tree=True):
   vid=v.get('VariationID');aa=v.xpath('./ClassifiedRecord/ClinicalAssertionList/ClinicalAssertion')
   if v.get('RecordType')=='classified':
    actual=len(aa);declared=int(v.get('NumberOfSubmissions','0'))
    if actual!=declared:issues.append({'variation_id':vid,'field':'NumberOfSubmissions','declared':declared,'actual':actual})
   replaced=v.xpath('./ReplacedBy');replaces=v.xpath('./ReplacedList/Replaced')
   if replaced or replaces:
    db.execute('INSERT INTO lineage VALUES(?,?,?)',(vid,json.dumps([dict(x.attrib) for x in replaced],sort_keys=True),json.dumps([dict(x.attrib) for x in replaces],sort_keys=True)))
   for a in aa:
    acc=a.xpath('./ClinVarAccession/@Accession')
    if not acc or acc[0] not in wanted:continue
    fields=raw_assertion(a);seen.add(fields['scv']);stored=con.execute('SELECT * FROM assertions WHERE scv=?',(fields['scv'],)).fetchone()
    differences={k:{'raw':value,'normalized':stored[k] if stored else None} for k,value in fields.items() if stored is None or stored[k]!=value}
    # Preserve mapped-condition evidence without importing the production mapping implementation.
    assertion_id=a.get('ID');mapped=v.xpath('./ClassifiedRecord/TraitMappingList/TraitMapping[@ClinicalAssertionID=$aid]/MedGen/@CUI',aid=assertion_id)
    submitted=a.xpath('./TraitSet/Trait/XRef[@DB="MedGen"]/@ID');raw_conditions=sorted(set(mapped+submitted));normalized_conditions=sorted(json.loads(stored['conditions_json'])) if stored else []
    if raw_conditions!=normalized_conditions:differences['conditions']={'raw':raw_conditions,'normalized':normalized_conditions}
    cases.append({'variation_id':vid,'fields':fields,'condition_ids':raw_conditions,'differences':differences})
   n+=1;v.clear()
   while v.getprevious() is not None:del v.getparent()[0]
   if n%100000==0:db.commit();print(json.dumps({'records_scanned':n,'seconds':round(time.monotonic()-t)}),flush=True)
 db.commit();db.close();path.with_suffix('.sqlite.part').rename(path);con.close()
 report={'records_scanned':n,'wanted_scvs':len(wanted),'found_scvs':len(seen),'missing_scvs':sorted(wanted-seen),'source_count_discrepancies':issues,'case_field_mismatches':sum(bool(x['differences']) for x in cases),'cases':cases,'human_review':False,'review_state':'Automated independent field audit; manual case-table inspection remains pending'}
 (out/'raw_source_audit.json').write_text(json.dumps(report,indent=2)+'\n')
 assert not report['missing_scvs'] and not report['case_field_mismatches'],'Source audit discrepancies require investigation'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');p.add_argument('--select',action='store_true');p.add_argument('--scan',action='store_true');a=p.parse_args()
 if a.select:select(a.root,a.month)
 if a.scan:scan(a.root,a.month)
