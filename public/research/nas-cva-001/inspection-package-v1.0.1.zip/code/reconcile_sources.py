"""Exact source-bound adjudication; unknown differences always fail closed."""
import argparse,hashlib,json,sqlite3
from collections import Counter
from pathlib import Path

def allowed_errors(observed,expected):
 return Counter(tuple(x) for x in observed)==Counter(tuple(x) for x in expected)

def incomplete_ids(report):
 return {x['variation_id'] for x in report.get('rcv_only_records',[])}|{x['variation_id'] for x in report.get('vcv_only_records',[])}

def coverage_issues(reconciliation,count_report):
 """Distinguish proven paired-source absence from unresolved declared-count metadata."""
 assert count_report['raw_normalized_counts_agree'],'Raw assertion-count extraction disagrees with normalization'
 issues={x['variation_id']:'unresolved_source_assertion_count' for x in count_report['count_discrepancies']}
 issues.update({vid:'incomplete_source_assertion_coverage' for vid in incomplete_ids(reconciliation)})
 return issues

def identifier_inventory(root,month):
 con=[]
 for kind in ['vcv','rcv']:
  c=sqlite3.connect(f'file:{root}/normalized/{month}/{kind}.sqlite?mode=ro',uri=True);c.row_factory=sqlite3.Row;con.append(c)
 v,r=con;vi=iter(v.execute('select scv from assertions order by scv'));ri=iter(r.execute('select distinct scv from membership order by scv'));a=next(vi,None);b=next(ri,None);vo=[];ro=[];n=0
 while a is not None or b is not None:
  if a is not None and (b is None or a[0]<b[0]):vo.append(a[0]);a=next(vi,None)
  elif b is not None and (a is None or b[0]<a[0]):ro.append(b[0]);b=next(ri,None)
  else:n+=1;a=next(vi,None);b=next(ri,None)
 report={'month':month,'matched_scvs':n,'vcv_only':vo,'rcv_only':ro,'vcv_only_records':[dict(x) for s in vo for x in v.execute('select scv,variation_id,version from assertions where scv=?',(s,))],'rcv_only_records':[dict(x) for s in ro for x in r.execute('select * from membership where scv=?',(s,))]}
 for c in con:c.close()
 out=root/'analysis'/month;out.mkdir(parents=True,exist_ok=True);(out/'source_identifier_reconciliation.json').write_text(json.dumps(report,indent=2)+'\n');return report

def verify_gate(root,month,dbpath):
 c=sqlite3.connect(f'file:{dbpath}?mode=ro',uri=True);observed=c.execute('select * from crossfile_errors').fetchall();c.close()
 config=json.loads(Path(__file__).with_name('source_adjudications.json').read_text());record=config['snapshots'].get(month)
 if (root/'source_manifest.json').exists():
  inventory=json.loads((root/'analysis'/month/'source_identifier_reconciliation.json').read_text())
  audit=json.loads((root/'analysis'/month/'raw_reconciliation_validation.json').read_text())
  assert audit['passed'] and audit['source_manifest_sha256']==hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),'Raw reconciliation evidence required'
  assert sorted(inventory['rcv_only'])==sorted((record or {}).get('rcv_only_scvs',[])) and sorted(inventory['vcv_only'])==sorted((record or {}).get('vcv_only_scvs',[])),'Unadjudicated assertion-presence discrepancy'
 if not observed:
  assert not (record or {}).get('version_discrepancies'),'Expected frozen source discrepancies disappeared'
  return {'status':'no_compared_field_mismatches','adjudicated':0}
 assert record,'Unadjudicated snapshot discrepancies'
 assert hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest()==config['source_manifest_sha256'],'Adjudication belongs to another source freeze'
 expected=[[x['scv'],'version',x['vcv_version'],x['rcv_version']] for x in record['version_discrepancies']]
 assert allowed_errors(observed,expected),'Additional, missing, duplicated or changed source discrepancy'
 v=sqlite3.connect(f'file:{root}/normalized/{month}/vcv.sqlite?mode=ro',uri=True);v.row_factory=sqlite3.Row
 r=sqlite3.connect(f'file:{root}/normalized/{month}/rcv.sqlite?mode=ro',uri=True);r.row_factory=sqlite3.Row
 for x in record['version_discrepancies']:
  a=v.execute('select * from assertions where scv=?',(x['scv'],)).fetchone();mm=r.execute('select * from membership where scv=?',(x['scv'],)).fetchall();assert a and len(mm)==1
  b=mm[0];assert a['version']==x['vcv_version'] and b['version']==x['rcv_version'] and a['variation_id']==b['variation_id']==x['variation_id'] and b['rcv']==x['rcv']
  assert all(a[f]==b[f] for f in ['label','review','evaluated','org_id']),'Analytic fields changed'
 v.close();r.close()
 return {'status':'exact_source_discrepancies_adjudicated','adjudicated':len(observed),'source_manifest_sha256':config['source_manifest_sha256'],'assertion_source':'VCV original values retained','raw_evidence':'source_discrepancy_evidence.json'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();report=identifier_inventory(a.root,a.month);print(json.dumps({'matched_scvs':report['matched_scvs'],'vcv_only':len(report['vcv_only']),'rcv_only':len(report['rcv_only'])}))
