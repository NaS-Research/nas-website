import unittest
from lxml import etree as E
from normalize_vcv import rows
class Extraction(unittest.TestCase):
 def record(self,body):
  return E.fromstring(('<VariationArchive VariationID="1" Accession="VCVTEST" Version="1"><RecordStatus>current</RecordStatus><Species>Homo sapiens</Species><ClassifiedRecord><SimpleAllele AlleleID="2"/><RCVList/><Classifications/><ClinicalAssertionList>'+body+'</ClinicalAssertionList><TraitMappingList><TraitMapping ClinicalAssertionID="3"><MedGen CUI="CTEST" Name="Synthetic condition"/></TraitMapping></TraitMappingList></ClassifiedRecord></VariationArchive>').encode())
 def assertion(self,label='Pathogenic',branch='GermlineClassification'):
  return f'<ClinicalAssertion ID="3"><ClinVarAccession Accession="SCVTEST" Version="1" OrgID="4"/><RecordStatus>current</RecordStatus><Classification DateLastEvaluated="2025-01-01"><ReviewStatus>criteria provided, single submitter</ReviewStatus><{branch}>{label}</{branch}></Classification><SimpleAllele/><TraitSet><Trait><AttributeSet><Attribute Type="ModeOfInheritance">Autosomal dominant inheritance</Attribute></AttributeSet></Trait></TraitSet></ClinicalAssertion>'
 def test_dates_not_interchanged(self):
  a=rows(self.record(self.assertion()))[1][0];self.assertEqual(a[11],'2025-01-01');self.assertEqual(a[12],'');self.assertEqual(a[13],'')
 def test_explicit_mapping(self):self.assertIn('CTEST',rows(self.record(self.assertion()))[1][0][15])
 def test_inheritance_retained(self):self.assertIn('Autosomal dominant inheritance',rows(self.record(self.assertion()))[1][0][17])
 def test_assertion_level_inheritance(self):
  s=self.assertion().replace('<SimpleAllele/>','<AttributeSet><Attribute Type="ModeOfInheritance">Autosomal recessive inheritance</Attribute></AttributeSet><SimpleAllele/>')
  self.assertIn('Autosomal recessive inheritance',rows(self.record(s))[1][0][17])
 def test_somatic_branch_not_germline(self):
  a=rows(self.record(self.assertion('Benign','OncogenicityClassification')))[1][0];self.assertEqual(a[7],'somatic_or_other');self.assertEqual(a[8],'')
 def test_component_not_direct(self):
  e=E.fromstring(b'<VariationArchive VariationID="1"><IncludedRecord><SimpleAllele AlleleID="2"/></IncludedRecord></VariationArchive>');self.assertEqual(rows(e)[0][6],0)
 def test_no_observation_text_export(self):
  s=self.assertion().replace('<SimpleAllele/>','<ObservedInList><ObservedIn><ObservedData><Attribute>synthetic sensitive observation</Attribute></ObservedData></ObservedIn></ObservedInList><SimpleAllele/>')
  self.assertNotIn('sensitive',str(rows(self.record(s))))
if __name__=='__main__':unittest.main()
