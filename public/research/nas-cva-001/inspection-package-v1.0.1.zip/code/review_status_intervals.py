"""Variant-cluster intervals for unit rates stratified by official RCV review."""
import argparse,csv,gzip
from collections import defaultdict
from pathlib import Path
from study_stats import clustered_fraction_interval
from summarize import export

def calculate(rows):
 clusters=defaultdict(lambda:defaultdict(lambda:[0,0]))
 for row in rows:
  vector=clusters[row['official_rcv_review']][row['variation_id']]
  vector[0]+=int(int(row['tier']) in (1,2));vector[1]+=1
 result=[]
 for category,variants in sorted(clusters.items()):
  k=sum(x[0] for x in variants.values());n=sum(x[1] for x in variants.values())
  lower,upper=clustered_fraction_interval(variants.values())
  result.append([category,n,k,k/n,lower,upper,'variant-cluster bootstrap 2000; seed 20260926'])
 return result

def run(root,month):
 folder=root/'analysis'/month/'tables'
 with gzip.open(folder/'primary_units.csv.gz','rt',newline='') as f:records=calculate(csv.DictReader(f))
 with (folder/'by_review_status.csv').open(newline='') as f:expected={r['category']:(int(r['eligible_units']),int(r['T1_T2'])) for r in csv.DictReader(f)}
 assert {r[0]:(r[1],r[2]) for r in records}==expected,'Cluster-interval denominators must match stratified unit counts'
 export(folder/'review_status_cluster_intervals.csv',['category','eligible_units','T1_T2','fraction','ci_lower','ci_upper','interval_model'],records)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
