import unittest
from lxml import etree
from source_audit_rcv import extract
class RawRCV(unittest.TestCase):
 def test_exact_membership_and_aggregate_fields(self):
  xml=b'<ClinVarSet><ReferenceClinVarAssertion><ClinVarAccession Acc="RCV-SYN" Version="2"/><MeasureSet ID="SYN-1"/><RecordStatus>current</RecordStatus><TraitSet><Trait><XRef DB="MedGen" ID="SYN-C"/><XRef DB="OMIM" ID="SYN-O"/></Trait></TraitSet><Classifications><GermlineClassification><Description>Pathogenic</Description><ReviewStatus>reviewed by expert panel</ReviewStatus></GermlineClassification></Classifications></ReferenceClinVarAssertion><ClinVarAssertion><ClinVarAccession Acc="SCV-SYN" Version="3" OrgID="SYN-ORG"/><Classification DateLastEvaluated="2025-01-01"><GermlineClassification>Likely pathogenic</GermlineClassification><ReviewStatus>criteria provided, single submitter</ReviewStatus></Classification></ClinVarAssertion></ClinVarSet>'
  record,members=extract(etree.fromstring(xml))
  self.assertEqual(record['condition_ids'],['SYN-C']);self.assertEqual(record['variation_id'],'SYN-1');self.assertEqual(record['official_label'],'Pathogenic')
  self.assertEqual(members,[{'scv':'SCV-SYN','version':'3','rcv':'RCV-SYN','variation_id':'SYN-1','org_id':'SYN-ORG','label':'Likely pathogenic','review':'criteria provided, single submitter','evaluated':'2025-01-01'}])
 def test_no_germline_values_are_not_fabricated(self):
  record,members=extract(etree.fromstring(b'<ClinVarSet><ReferenceClinVarAssertion><ClinVarAccession Acc="SYN"/><GenotypeSet ID="SET"/></ReferenceClinVarAssertion></ClinVarSet>'))
  self.assertEqual(record['official_label'],'');self.assertEqual(record['condition_ids'],[]);self.assertEqual(members,[])
if __name__=='__main__':unittest.main()
