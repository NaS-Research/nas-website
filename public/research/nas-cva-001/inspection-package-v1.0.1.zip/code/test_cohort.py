import datetime,unittest
from cohort import age_days,condition_ok,exclusion_reasons
class Cohort(unittest.TestCase):
 def setUp(self):
  self.v={'direct_simple':1,'species':'Homo sapiens','status':'current'}
  self.a={'direct_simple':1,'status':'current','class_type':'germline','origins_json':'["germline"]','org_id':'1','label':'Pathogenic','review':'criteria provided, single submitter'}
  self.c=[{'DB':'MedGen','ID':'SYNTHETIC','name':'Synthetic disease'}]
 def test_qualifies(self):self.assertEqual(exclusion_reasons(self.a,self.v,self.c),[])
 def test_no_false_condition(self):self.assertFalse(condition_ok([{'DB':'MedGen','ID':'C','name':'not provided'}]))
 def test_missing_condition(self):self.assertFalse(condition_ok([]))
 def test_no_inferred_membership(self):self.assertIn('ambiguous_or_missing_rcv_membership',exclusion_reasons(self.a,self.v,self.c,2))
 def test_somatic_excluded(self):
  self.a['origins_json']='["somatic"]';self.assertIn('exclusively_somatic_origin',exclusion_reasons(self.a,self.v,self.c))
 def test_mixed_retained(self):
  self.a['origins_json']='["somatic","germline"]';self.assertEqual(exclusion_reasons(self.a,self.v,self.c),[])
 def test_missing_age(self):self.assertEqual(age_days('',datetime.date(2026,1,1)),(None,'missing'))
 def test_future_age(self):self.assertEqual(age_days('2027-01-01',datetime.date(2026,1,1)),(None,'future'))
 def test_invalid_age(self):self.assertEqual(age_days('2025-02-30',datetime.date(2026,1,1)),(None,'invalid'))
 def test_valid_age(self):self.assertEqual(age_days('2025-01-01',datetime.date(2026,1,1)),(365,'valid'))
if __name__=='__main__':unittest.main()
