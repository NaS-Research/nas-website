import csv,gzip,os,tempfile,unittest
from pathlib import Path
from validate_tabular import rows,date,boolean,missing
class Tabular(unittest.TestCase):
 def test_metadata_comments_do_not_become_header(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   p=Path(temp)/'example.gz'
   with gzip.open(p,'wt') as f:f.write('##description\n#VariationID: explanation\n#VariationID\tSCV\n12\tSCV000001.2\n')
   self.assertEqual(list(rows(p,'#VariationID')),[{'#VariationID':'12','SCV':'SCV000001.2'}])
 def test_large_source_field_preserves_record_and_following_row(self):
  previous=csv.field_size_limit()
  try:
   csv.field_size_limit(131072)
   with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
    p=Path(temp)/'large-field.gz'
    value='"synthetic value '*20000+' literal quote'
    with gzip.open(p,'wt',newline='') as f:
     f.write('#Gene_Symbol\tDescription\tNCBI_Variation_ID\n')
     f.write('SYNTHETIC\t'+value+'\t1\n')
     f.write('FOLLOWING\tshort\t2\n')
    parsed=list(rows(p,'#Gene_Symbol'))
    self.assertEqual(len(parsed),2)
    self.assertEqual(parsed[0]['Description'],value)
    self.assertEqual(parsed[0]['NCBI_Variation_ID'],'1')
    self.assertEqual(parsed[1]['NCBI_Variation_ID'],'2')
  finally:csv.field_size_limit(previous)
 def test_literal_unclosed_quote_never_consumes_next_row(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   p=Path(temp)/'literal.gz'
   with gzip.open(p,'wt') as f:f.write('#VariationID\tDescription\tSCV\n1\t"literal opening quote\tSCV1.1\n2\tfollowing\tSCV2.1\n')
   parsed=list(rows(p,'#VariationID'))
   self.assertEqual([r['SCV'] for r in parsed],['SCV1.1','SCV2.1'])
   self.assertEqual(parsed[0]['Description'],'"literal opening quote')
 def test_malformed_physical_row_fails_without_silent_exclusion(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   p=Path(temp)/'malformed.gz'
   with gzip.open(p,'wt') as f:f.write('#VariationID\tSCV\n1\n')
   with self.assertRaisesRegex(ValueError,'expected 2 columns, got 1'):list(rows(p,'#VariationID'))
 def test_exact_representation_equivalences_keep_unknowns_distinct(self):
  self.assertEqual(boolean('yes'),boolean('true'));self.assertEqual(boolean('no'),boolean('false'))
  self.assertNotEqual(boolean('unknown'),boolean('no'));self.assertNotEqual(boolean(''),boolean('no'))
  self.assertEqual(missing('-'),missing(''));self.assertNotEqual(missing('not provided'),missing(''))
 def test_date_formats_and_missing(self):
  self.assertEqual(date('May 15, 2017'),'2017-05-15');self.assertEqual(date('-'),'');self.assertEqual(date('2017-05-15'),'2017-05-15');self.assertTrue(date('unknown date').startswith('UNPARSED:'))
if __name__=='__main__':unittest.main()
