import unittest
from study_stats import wilson,clustered_fraction_interval,odds_ratio
class Statistics(unittest.TestCase):
 def test_empty(self):self.assertEqual(wilson(0,0),(None,None))
 def test_boundaries(self):
  self.assertEqual(wilson(0,20)[0],0);self.assertAlmostEqual(wilson(20,20)[1],1)
 def test_balanced(self):self.assertAlmostEqual(sum(wilson(50,100)),1)
 def test_cluster_identical(self):self.assertEqual(clustered_fraction_interval([(1,2)]*10,reps=20),(.5,.5))
 def test_deterministic(self):
  x=[(1,1),(0,1),(1,3),(0,4)];self.assertEqual(clustered_fraction_interval(x,reps=50),clustered_fraction_interval(x,reps=50))
 def test_input_order_does_not_change_bootstrap(self):
  x=[(1,1),(0,1),(1,3),(0,4),(2,3),(1,1)];self.assertEqual(clustered_fraction_interval(x,reps=200),clustered_fraction_interval(list(reversed(x)),reps=200))
 def test_odds(self):self.assertEqual(odds_ratio(20,10,10,20)['odds_ratio'],4)
if __name__=='__main__':unittest.main()
