import csv,json,os,sqlite3,tempfile,unittest
from pathlib import Path
from source_dimension_participation import run
class SourceDimension(unittest.TestCase):
 def test_overlapping_categories_count_unit_once_and_preserve_unknown(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
   root=Path(temp);out=root/'analysis/fixture';(out/'tables').mkdir(parents=True)
   (out/'independent_validation.json').write_text(json.dumps({'passed':True}))
   c=sqlite3.connect(out/'units.sqlite');c.executescript('CREATE TABLE units(mode TEXT,unit_key TEXT,eligible INTEGER,tier INTEGER);CREATE TABLE unit_assertions(mode TEXT,unit_key TEXT,org_type TEXT,methods_json TEXT);')
   c.executemany('INSERT INTO units VALUES(?,?,?,?)',[('primary','SYN1',1,2),('primary','SYN2',1,0),('primary','EXCLUDED',0,1)])
   c.executemany('INSERT INTO unit_assertions VALUES(?,?,?,?)',[('primary','SYN1','laboratory','["clinical testing","research"]'),('primary','SYN1','laboratory','["clinical testing"]'),('primary','SYN2','','[]'),('primary','EXCLUDED','research','["research"]')]);c.commit();c.close()
   run(root,'fixture')
   with (out/'tables/source_dimension_participation.csv').open() as f:data={(x['source_dimension'],x['reported_category']):x for x in csv.DictReader(f)}
   self.assertEqual(data[('collection_method','clinical testing')]['eligible_unit_participation'],'1')
   self.assertEqual(data[('collection_method','research')]['T1_T2_unit_participation'],'1')
   self.assertEqual(data[('reported_organization_type','laboratory')]['eligible_unit_participation'],'1')
   self.assertEqual(data[('reported_organization_type','[unreported]')]['T1_T2_unit_participation'],'0')
   self.assertEqual(json.loads((out/'source_dimension_validation.json').read_text())['units_checked'],2)
if __name__=='__main__':unittest.main()
