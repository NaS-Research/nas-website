import unittest
from history import interval_fit
class IntervalEstimator(unittest.TestCase):
 def test_identifiable_event_fraction_with_right_censoring(self):
  curve,diagnostics=interval_fit([(1e-6,10.)]*50+[(10.000001,float('inf'))]*50)
  self.assertTrue(diagnostics['bounded_monotone_finite']);self.assertEqual(diagnostics['weighted_observations'],100);self.assertEqual(diagnostics['unique_interval_types'],2)
  for value in curve.loc[10.]:self.assertAlmostEqual(value,.5,places=5)
 def test_event_free_observed_horizon(self):
  curve,diagnostics=interval_fit([(10.000001,float('inf'))]*100)
  self.assertTrue(diagnostics['bounded_monotone_finite'])
  for value in curve.iloc[0]:self.assertAlmostEqual(value,1.,places=5)
if __name__=='__main__':unittest.main()
