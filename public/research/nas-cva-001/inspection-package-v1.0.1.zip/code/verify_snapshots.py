"""Integrity, identifier and aggregate cross-checks before cohort construction."""
import argparse,json,sqlite3
from datetime import datetime,timezone
def progress(message):
 print(datetime.now(timezone.utc).isoformat(),message,flush=True)
from pathlib import Path

def condition_ids_vcv(raw):
 return sorted({(x.get('DB'),x.get('ID')) for x in json.loads(raw) if x.get('DB')=='MedGen' and x.get('ID')})
def condition_ids_rcv(raw):
 return sorted({(x.get('DB'),x.get('ID')) for tr in json.loads(raw) for x in tr.get('ids',[]) if x.get('DB')=='MedGen' and x.get('ID')})
def run(root,month):
 d=root/'normalized'/month;out=root/'analysis'/month;out.mkdir(parents=True,exist_ok=True)
 v=sqlite3.connect(f'file:{d/"vcv.sqlite"}?mode=ro',uri=True);v.row_factory=sqlite3.Row
 r=sqlite3.connect(f'file:{d/"rcv.sqlite"}?mode=ro',uri=True);r.row_factory=sqlite3.Row
 for connection in (v,r):
  connection.execute('PRAGMA cache_size=-524288')
  connection.execute('PRAGMA temp_store=FILE')
 progress('starting integrity checks')
 checks={'vcv_quick_check':[x[0] for x in v.execute('PRAGMA quick_check')],'rcv_quick_check':[x[0] for x in r.execute('PRAGMA quick_check')]}
 progress('integrity checks complete')
 vmeta={x['key']:x['value'] for x in v.execute('SELECT * FROM metadata')};rmeta={x['key']:x['value'] for x in r.execute('SELECT * FROM metadata')}
 checks['matching_snapshot_dates']=json.loads(vmeta['release'])['ReleaseDate']==json.loads(rmeta['release'])['Dated']
 checks['schema_invalid_vcv']=int(vmeta['schema_invalid']);checks['schema_invalid_rcv']=int(rmeta['schema_invalid'])
 progress('starting orphan assertion check')
 checks['orphan_assertions']=v.execute('SELECT count(*) FROM assertions a LEFT JOIN variants b USING(variation_id) WHERE b.variation_id IS NULL').fetchone()[0]
 progress('starting orphan RCV check')
 checks['orphan_rcvs']=v.execute('SELECT count(*) FROM rcvs a LEFT JOIN variants b USING(variation_id) WHERE b.variation_id IS NULL').fetchone()[0]
 v.execute('ATTACH DATABASE ? AS other',(str(d/'rcv.sqlite'),))
 v.execute('PRAGMA other.cache_size=-524288')
 progress('starting paired aggregate comparisons')
 fields=['variation_id','version','official_label','official_review']
 counts={field:0 for field in fields};samples={field:[] for field in fields}
 condition_examples=[];compared=0;missing=0;different=0
 columns=['a.rcv']+[f'{alias}.{field} {alias}_{field}' for field in fields for alias in ['a','b']]+['a.conditions_json va','b.conditions_json ra']
 # One joined scan retains all original comparisons, including SQL NULL
 # inequality semantics, while avoiding five repeated random-read joins.
 for index,row in enumerate(v.execute('SELECT '+','.join(columns)+' FROM rcvs a JOIN other.rcvs b USING(rcv)'),1):
  for field in fields:
   left=row['a_'+field];right=row['b_'+field]
   if left is not None and right is not None and left!=right:
    counts[field]+=1
    if len(samples[field])<100:samples[field].append({'field':field,'rcv':row['rcv'],'vcv_value':left,'rcv_value':right})
  a=condition_ids_vcv(row['va']);b=condition_ids_rcv(row['ra'])
  if not a or not b:missing+=1
  else:
   compared+=1
   if a!=b:
    different+=1
    if len(condition_examples)<100:condition_examples.append({'rcv':row['rcv'],'field':'condition_ids','vcv_value':a,'rcv_value':b})
  if index%1000000==0:progress(f'compared {index} paired aggregates and condition sets')
 examples=[example for field in fields for example in samples[field]][:100]
 examples.extend(condition_examples[:100-len(examples)])
 for field in fields:progress(f'aggregate field {field}: {counts[field]} mismatches')
 progress('starting bilateral missing-RCV checks')
 counts['missing_in_rcv']=v.execute('SELECT count(*) FROM rcvs a LEFT JOIN other.rcvs b USING(rcv) WHERE b.rcv IS NULL').fetchone()[0]
 counts['missing_in_vcv']=v.execute('SELECT count(*) FROM other.rcvs a LEFT JOIN rcvs b USING(rcv) WHERE b.rcv IS NULL').fetchone()[0]
 counts['condition_identifier_disagreements']=different
 checks['aggregate_mismatches']=counts;checks['condition_sets_compared']=compared;checks['condition_sets_without_bilateral_medgen_ids']=missing;checks['examples']=examples
 checks['passed']=checks['vcv_quick_check']==['ok'] and checks['rcv_quick_check']==['ok'] and checks['matching_snapshot_dates'] and checks['schema_invalid_vcv']==0 and checks['schema_invalid_rcv']==0 and checks['orphan_assertions']==0 and checks['orphan_rcvs']==0 and not any(counts.values())
 (out/'snapshot_validation.json').write_text(json.dumps(checks,indent=2)+'\n');v.close();r.close()
 progress(f"validation complete: passed={checks['passed']}")
 assert checks['passed'],'Snapshot cross-check failed; inspect snapshot_validation.json before analysis'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
