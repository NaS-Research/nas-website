"""Observed release transitions and interval-censored first cross-band resolution."""
import argparse,csv,datetime,hashlib,json,sqlite3,warnings
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from reconcile_sources import coverage_issues
from summarize import export
MONTHS=['2025-09','2026-03','2026-09']
def state(row):
 if row is None:return 'not_observed_as_eligible'
 return 'cross_band' if row['tier'] in (1,2,3) else 'adjacent_only' if row['tier']==4 else 'no_derived_disagreement'
def unavailable_state(identity,variant_present,rows):
 if not variant_present:return 'variant_absent'
 matches=[r for r in rows if key(r)==identity]
 if not matches:return 'condition_or_inheritance_not_observed'
 if len(matches)>1:return 'duplicate_condition_identity'
 return 'ineligible' if not matches[0]['eligible'] else 'eligible_identity_not_selected'
def transition(a,b):
 if a is None:return 'newly_eligible' if b is not None else 'not_eligible_either'
 if b is None:return 'lost_eligibility_or_absent'
 if a['tier'] in (1,2,3):
  if b['tier'] in (0,4):return 'cross_band_resolved'
  return 'persistent_same_tier' if a['tier']==b['tier'] else 'persistent_changed_tier'
 if b['tier'] in (1,2,3):return 'appeared'
 return 'no_cross_band_either'
def key(row):
 conditions=json.loads(row['conditions_json'])
 return (row['variation_id'],'|'.join(sorted(x['DB']+':'+x['ID'] for x in conditions)),row['inheritance'])
def compatible_metadata(v0,v1):
 if v0 is None or v1 is None:return False,'variant_absent'
 if v0['status']!='current' or v1['status']!='current':return False,'record_not_current'
 if v0['allele_id']!=v1['allele_id']:return False,'allele_identifier_changed'
 if v0['spdi'] and v1['spdi'] and v0['spdi']!=v1['spdi']:return False,'sequence_identity_changed'
 return True,'stable_identifiers'
def resolution_interval(observations):
 last=0;lost=False
 for days,value in observations:
  if value=='non_comparable':return last,float('inf'),False,'non_comparable'
  if value is None:lost=True;continue
  if value in (0,4):return last,days,True,'observed_cross_band_resolution'
  last=days;lost=False
 return last,float('inf'),False,'lost_eligibility' if lost else 'unresolved_at_last_observation'

def interval_fit(intervals):
 from lifelines.fitters.npmle import npmle
 from pandas import DataFrame
 freq=Counter(intervals);bounds=list(freq)
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always')
  probabilities,support=npmle(np.array([x[0] for x in bounds]),np.array([x[1] for x in bounds]),weights=np.array([freq[x] for x in bounds]),tol=1e-8)
 # Explicit right-continuous S(t)=P(T>t), conditional on fitted support masses.
 # Mass is certainly after t iff left>t, and can be after t iff right>t.
 # This avoids the library plotting envelope's pre-step boundary convention.
 timeline=sorted({0.,*(float(x) for interval in bounds for x in interval if np.isfinite(x))})
 rows=[]
 for t in timeline:
  rows.append([sum(p for p,(left,right) in zip(probabilities,support) if left>t),sum(p for p,(left,right) in zip(probabilities,support) if right>t)])
 curve=DataFrame(rows,index=timeline,columns=['survival_lower','survival_upper']);curve.index.name='days_since_baseline';values=curve.to_numpy()
 numerical_ok=bool(np.all(np.isfinite(values)) and np.all(values>=-1e-9) and np.all(values<=1+1e-9) and np.all(np.diff(values,axis=0)<=1e-9) and np.all(values[:,0]<=values[:,1]+1e-9) and np.all(probabilities>=-1e-9) and abs(sum(probabilities)-1)<1e-8)
 diagnostics={'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught],'bounded_monotone_finite':numerical_ok,'unique_interval_types':len(freq),'weighted_observations':sum(freq.values()),'tolerance':1e-8,'definition':'Right-continuous P(T>t); bounds conditional on fitted Turnbull support masses, not confidence intervals or bounds across every possible nonunique MLE.','implementation':'Pinned lifelines.fitters.npmle.npmle; experimental internal interface.','support_masses':[{'left':float(left),'right':float(right) if np.isfinite(right) else None,'right_unbounded':bool(np.isinf(right)),'probability':float(p)} for p,(left,right) in zip(probabilities,support)]}
 return curve,diagnostics

def run(root):
 out=root/'analysis/history';out.mkdir(parents=True,exist_ok=True)
 data=[];dates=[];connections=[];vcv=[];ambiguous=[];lineages=[];incomplete=[]
 for m in MONTHS:
  count_report=json.loads((root/'analysis'/m/'source_assertion_count_validation.json').read_text())
  assert count_report['month']==m and count_report['source_manifest_sha256']==hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),'Count audit belongs to another source freeze'
  incomplete.append(coverage_issues(json.loads((root/'analysis'/m/'source_identifier_reconciliation.json').read_text()),count_report))
  check=json.loads((root/'analysis'/m/'independent_validation.json').read_text());assert check['passed']
  c=sqlite3.connect(f'file:{root/"analysis"/m/"units.sqlite"}?mode=ro',uri=True);c.row_factory=sqlite3.Row;connections.append(c)
  date=json.loads(c.execute("SELECT value FROM metadata WHERE key='snapshot_date'").fetchone()[0]);dates.append(datetime.date.fromisoformat(date))
  entries={};duplicates=set()
  for row in c.execute("SELECT variation_id,conditions_json,inheritance,tier,expert FROM units WHERE mode='primary' AND eligible=1"):
   k=key(row)
   if k in entries:duplicates.add(k)
   entries[k]=dict(row)
  data.append(entries);ambiguous.append(duplicates)
  v=sqlite3.connect(f'file:{root/"normalized"/m/"vcv.sqlite"}?mode=ro',uri=True);v.row_factory=sqlite3.Row;vcv.append(v)
  if v.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='lineage'").fetchone():lineages.append(v)
  else:
   lp=root/'normalized'/m/'lineage.sqlite';assert lp.exists(),'Raw-source lineage audit required before history'
   lc=sqlite3.connect(f'file:{lp}?mode=ro',uri=True);lc.row_factory=sqlite3.Row;lineages.append(lc)
 assert dates==sorted(dates) and len(set(dates))==3
 # Cache only the identity fields for the union of eligible historical variants.
 # Sequential scans avoid repeatedly fetching large raw rows from the HDD.
 wanted_ids={k[0] for entries in data for k in entries}
 metadata_cache=[];lineage_cache=[]
 for index in range(3):
  selected={}
  for row in vcv[index].execute('SELECT variation_id,status,allele_id,spdi FROM variants NOT INDEXED'):
   if row['variation_id'] in wanted_ids:selected[row['variation_id']]=dict(row)
  metadata_cache.append(selected)
  lineage_cache.append({row['variation_id']:dict(row) for row in lineages[index].execute('SELECT * FROM lineage') if row['variation_id'] in wanted_ids})
  print('Cached historical identity fields',MONTHS[index],len(selected),flush=True)
 def comparable(k,i,j):
  if k[0] in incomplete[i]:return False,incomplete[i][k[0]]
  if k[0] in incomplete[j]:return False,incomplete[j][k[0]]
  if k in ambiguous[i] or k in ambiguous[j]:return False,'duplicate_condition_identity'
  a=metadata_cache[i].get(k[0]);b=metadata_cache[j].get(k[0])
  ok,why=compatible_metadata(a,b)
  if not ok:return ok,why
  signatures=[]
  for index in (i,j):
   row=lineage_cache[index].get(k[0])
   signatures.append(tuple(tuple(sorted(x.get('VariationID') or x.get('Accession','') for x in json.loads(row[col]))) if row else () for col in ('replaced_by','replaced_records')))
  if signatures[0]!=signatures[1]:return False,'replacement_history_changed'
  return True,'stable_identifiers_and_lineage'
 def observed_state(k,index):
  if k[0] in incomplete[index]:return incomplete[index][k[0]]
  if k in ambiguous[index]:return 'duplicate_condition_identity'
  if k in data[index]:return state(data[index][k])
  present=k[0] in metadata_cache[index]
  records=connections[index].execute("SELECT variation_id,conditions_json,inheritance,eligible FROM units WHERE mode='primary' AND variation_id=?",(k[0],))
  return unavailable_state(k,present,records)
 paths=[];path_counts=Counter()
 for k in sorted(set().union(*(set(d) for d in data))):
  states=tuple(observed_state(k,j) for j in range(3));checks=tuple(comparable(k,i,j)[1] for i,j in [(0,1),(1,2)])
  paths.append([*k,*states,*checks]);path_counts[(*states,*checks)]+=1
 export(out/'three_snapshot_paths.csv.gz',['variation_id','condition_key','inheritance',*MONTHS,'comparability_0_1','comparability_1_2'],paths)
 export(out/'three_snapshot_path_counts.csv',[*MONTHS,'comparability_0_1','comparability_1_2','units'],[list(k)+[n] for k,n in sorted(path_counts.items())])
 rows=[];totals=Counter()
 for i,j in [(0,1),(1,2),(0,2)]:
  for k in sorted(set(data[i])|set(data[j])):
   a=data[i].get(k);b=data[j].get(k);ok,why=comparable(k,i,j)
   tr=transition(a,b) if ok else 'new_variant' if a is None and b is not None and why=='variant_absent' else 'variant_absent_at_end' if a is not None and b is None and why=='variant_absent' else 'non_comparable'
   rows.append([MONTHS[i],MONTHS[j],*k,observed_state(k,i),observed_state(k,j),None if a is None else a['tier'],None if b is None else b['tier'],tr,why])
   totals[(MONTHS[i],MONTHS[j],tr)]+=1
 export(out/'transitions.csv.gz',['start_month','end_month','variation_id','condition_key','inheritance','start_state','end_state','start_tier','end_tier','transition','comparability'],rows)
 export(out/'transition_counts.csv',['start_month','end_month','transition','units'],[list(k)+[v] for k,v in sorted(totals.items())])
 # Baseline prevalent cross-band conflicts: follow until first observed cross-band resolution.
 intervals=[];baseline=[];eps=1e-6
 for k,a in data[0].items():
  if a['tier'] not in (1,2,3) or k in ambiguous[0]:continue
  observations=[]
  for j in (1,2):
   b=data[j].get(k);ok,why=comparable(k,0,j)
   value=None if b is None else b['tier']
   if not ok and why!='variant_absent':value='non_comparable'
   observations.append(((dates[j]-dates[0]).days,value))
  last,upper,resolved,censor_reason=resolution_interval(observations)
  intervals.append((last+eps,upper));baseline.append([*k,last,None if np.isinf(upper) else upper,resolved,censor_reason])
 export(out/'first_resolution_intervals.csv.gz',['variation_id','condition_key','inheritance','last_cross_band_days','first_resolved_days','observed_resolution','status'],baseline)
 observed=sum(x[5] for x in baseline);lost=sum(x[6] not in {'observed_cross_band_resolution','unresolved_at_last_observation'} for x in baseline);n=len(baseline)
 report={'snapshot_dates':[str(x) for x in dates],'baseline_cross_band_units':n,'observed_first_resolutions':observed,'lost_or_noncomparable':lost,'resolution_fraction_lower_bound':observed/n if n else None,'resolution_fraction_upper_bound':(observed+lost)/n if n else None,'observation_limit':'Only snapshot-observed resolution is identified. Transient resolution and recurrence between snapshots cannot be excluded. Follow-up loss bounds do not bound all unobserved transient events.','time_origin':'baseline observation of a prevalent conflict, not true onset','event_interval':'(last observed cross-band disagreement, first observed cross-band resolution]','open_lower_boundary_offset_days':eps,'causal_interpretation':False,'turnbull_status':'not run: fewer than 50 observed resolutions'}
 if observed>=50:
  # Weight unique interval types instead of expanding identical observations.
  curve,diagnostics=interval_fit(intervals)
  report['turnbull_diagnostics']=diagnostics
  curve.to_csv(out/'turnbull_survival_bounds.csv')
  report['turnbull_status']='estimated; experimental library implementation; envelopes bound survival conditional on fitted support masses, not confidence intervals'
  if diagnostics['warnings'] or not diagnostics['bounded_monotone_finite']:report['turnbull_status']='requires diagnostic review before interpretation'
  report['censoring_assumption']='Independent censoring is an assumption; loss-to-follow-up bounds are reported separately.'
 (out/'history_summary.json').write_text(json.dumps(report,indent=2)+'\n')
 for c in set(connections+vcv+lineages):c.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();run(a.root)
