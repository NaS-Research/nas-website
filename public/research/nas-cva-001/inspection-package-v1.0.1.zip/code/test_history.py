import math,unittest
from history import transition,resolution_interval,compatible_metadata,unavailable_state
class History(unittest.TestCase):
 def test_reduced_severity_not_resolved(self):self.assertEqual(transition({'tier':1},{'tier':2}),'persistent_changed_tier')
 def test_adjacent_resolution_separate(self):self.assertEqual(transition({'tier':1},{'tier':4}),'cross_band_resolved')
 def test_missing_not_resolved(self):self.assertEqual(transition({'tier':1},None),'lost_eligibility_or_absent')
 def test_first_observed_interval(self):self.assertEqual(resolution_interval([(180,1),(365,0)]),(180,365,True,'observed_cross_band_resolution'))
 def test_gap_widens_interval(self):self.assertEqual(resolution_interval([(180,None),(365,0)]),(0,365,True,'observed_cross_band_resolution'))
 def test_unresolved_is_censored(self):
  lo,hi,event,status=resolution_interval([(180,2),(365,1)]);self.assertEqual(lo,365);self.assertTrue(math.isinf(hi));self.assertFalse(event)
 def test_loss_is_censored(self):self.assertEqual(resolution_interval([(180,1),(365,None)])[3],'lost_eligibility')
 def test_identity_change_not_resolution(self):self.assertEqual(resolution_interval([(180,'non_comparable'),(365,0)])[3],'non_comparable')
 def test_changed_allele(self):
  a={'status':'current','allele_id':'1','spdi':'A'};b=dict(a,allele_id='2');self.assertFalse(compatible_metadata(a,b)[0])
class Unavailable(unittest.TestCase):
 def test_ineligible_distinct_from_missing_identity(self):
  row={'variation_id':'1','conditions_json':'[{"DB":"MedGen","ID":"C1"}]','inheritance':'','eligible':0}
  self.assertEqual(unavailable_state(('1','MedGen:C1',''),True,[row]),'ineligible')
  self.assertEqual(unavailable_state(('1','MedGen:C2',''),True,[row]),'condition_or_inheritance_not_observed')
 def test_absence_distinct_from_ineligibility(self):
  self.assertEqual(unavailable_state(('1','MedGen:C1',''),False,[]),'variant_absent')
if __name__=='__main__':unittest.main()
