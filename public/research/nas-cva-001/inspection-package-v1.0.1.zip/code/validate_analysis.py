"""Reconcile exported analytical denominators and tier counts with independent SQL.
This validates reporting consistency, not clinical validity or source completeness.
"""
import argparse,csv,gzip,json,math
from collections import Counter
from pathlib import Path

def rows(path):
 with (gzip.open(path,'rt',newline='') if path.suffix=='.gz' else path.open(newline='')) as f:
  yield from csv.DictReader(f)

def run(root,month):
 out=root/'analysis'/month;t=out/'tables'
 summary=json.loads((out/'summary.json').read_text())
 independent=json.loads((out/'independent_validation.json').read_text())
 checks=[]
 def check(name,observed,expected):
  ok=math.isclose(observed,expected,rel_tol=1e-10,abs_tol=1e-7) if isinstance(observed,float) or isinstance(expected,float) else observed==expected
  checks.append({'check':name,'observed':observed,'expected':expected,'passed':ok})
 check('independent_validation_passed',independent['passed'],True)
 primary=summary['modes']['primary']
 uc={int(k):v for k,v in primary['unit_tier_counts'].items()}
 vc={int(k):v for k,v in primary['variant_tier_counts'].items()}
 check('primary_units_independent',primary['eligible_units'],independent['independent_eligible_units'])
 for tier in range(5):check(f'primary_tier_{tier}_independent',uc.get(tier,0),independent['tier_counts'].get(str(tier),0))
 for mode,s in summary['modes'].items():
  check(mode+'_unit_partition',sum(s['unit_tier_counts'].values()),s['eligible_units'])
  check(mode+'_variant_partition',sum(s['variant_tier_counts'].values()),s['eligible_variants'])
  observed=Counter();seen=set()
  for row in rows(t/f'variant_outcomes_{mode}.csv.gz'):
   if row['variation_id'] in seen:raise AssertionError(f'Duplicate exported variant in {mode}')
   seen.add(row['variation_id']);observed[int(row['tier'])]+=1
  check(mode+'_exported_variant_count',len(seen),s['eligible_variants'])
  for tier in range(5):check(f'{mode}_exported_variant_tier_{tier}',observed[tier],s['variant_tier_counts'].get(str(tier),0))
 definitions={'T1':(1,),'T1_T2':(1,2),'T1_T3':(1,2,3),'T4':(4,)}
 estimates=list(rows(t/'principal_estimates.csv'))
 check('principal_estimate_row_count',len(estimates),8)
 check('principal_estimate_keys',sorted((r['unit'],r['definition']) for r in estimates),sorted((u,d) for u in ['units','variants'] for d in definitions))
 for row in estimates:
  counts=uc if row['unit']=='units' else vc
  n=primary['eligible_units' if row['unit']=='units' else 'eligible_variants']
  k=sum(counts.get(x,0) for x in definitions[row['definition']]);name=row['unit']+'_'+row['definition']
  check(name+'_numerator',int(row['numerator']),k);check(name+'_denominator',int(row['denominator']),n)
  if n:
   check(name+'_fraction',float(row['fraction']),k/n)
   check(name+'_interval_in_range',0<=float(row['ci_lower'])<=float(row['ci_upper'])<=1,True)
 for dimension in ['review_status','expert_presence','variant_type','organization_count']:
  rr=list(rows(t/f'by_{dimension}.csv'))
  check(dimension+'_denominator',sum(int(x['eligible_units']) for x in rr),primary['eligible_units'])
  for label in ['T1','T1_T2','T1_T3']:
   check(dimension+'_'+label,sum(int(x[label]) for x in rr),sum(uc.get(i,0) for i in definitions[label]))
 retention=Counter()
 for row in rows(t/'age_filter_retention.csv'):retention[(row['mode'],int(row['baseline_tier']))]+=int(row['baseline_units'])
 for mode in ['recent_2y','recent_5y']:
  for tier in range(5):check(f'{mode}_fixed_baseline_tier_{tier}',retention[(mode,tier)],uc.get(tier,0))
 observed=Counter();gene_eligible=gene_disputed=0
 for row in rows(t/'variant_features.csv.gz'):
  tier=int(row['highest_tier']);observed[tier]+=1
  if int(row['gene_count']):gene_eligible+=1;gene_disputed+=int(tier in (1,2))
 for tier in range(5):check(f'feature_variant_tier_{tier}',observed[tier],vc.get(tier,0))
 for filename,column,expected in [
  ('condition_distribution.csv','eligible_fractional_weight',primary['eligible_variants']),
  ('condition_distribution.csv','disputed_fractional_weight',sum(vc.get(i,0) for i in (1,2))),
  ('organization_participation.csv','eligible_fractional_weight',primary['eligible_units']),
  ('organization_participation.csv','disputed_fractional_weight',sum(uc.get(i,0) for i in (1,2))),
  ('gene_fractional_participation.csv','eligible_variant_weight',gene_eligible),
  ('gene_fractional_participation.csv','T1_T2_variant_weight',gene_disputed)]:
  check(filename+'_'+column,math.fsum(float(x[column]) for x in rows(t/filename)),expected)
 report={'month':month,'passed':all(c['passed'] for c in checks),'checks':checks,'scope':'Exported denominator, tier, fixed-baseline attrition and fractional-weight conservation; independent primary counts. Does not establish clinical validity.'}
 (out/'analysis_validation.json').write_text(json.dumps(report,indent=2)+'\n')
 assert report['passed'],[c for c in checks if not c['passed']]
 print(json.dumps({'month':month,'passed':True,'checks':len(checks)}),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
