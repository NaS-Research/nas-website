"""Focused RCV supplementation sensitivity; never modifies normalized sources."""
import argparse,datetime,json,sqlite3
from collections import defaultdict
from pathlib import Path
from lxml import etree as E
from build_units import MODES,choose_mode,stable_condition
from cohort import exclusion_reasons,summarize
from normalize_vcv import js

def supplemental_assertion(path,scv,vid):
 tree=E.parse(str(path));matches=tree.xpath('./ClinVarAssertion[ClinVarAccession/@Acc=$s]',s=scv);assert len(matches)==1
 a=matches[0];ac=a.find('ClinVarAccession');cl=a.find('Classification');ms=a.find('MeasureSet')
 def txt(p):return (a.findtext(p) or '').strip()
 return {'scv':scv,'version':ac.get('Version',''),'variation_id':vid,'org_id':ac.get('OrgID',''),'class_type':'germline' if cl.find('GermlineClassification') is not None else 'other','label':txt('Classification/GermlineClassification'),'review':txt('Classification/ReviewStatus'),'status':txt('RecordStatus'),'evaluated':cl.get('DateLastEvaluated',''),'inheritance_json':js(sorted(set(a.xpath('./AttributeSet/Attribute[@Type="ModeOfInheritance"]/text()')+a.xpath('./TraitSet/Trait/AttributeSet/Attribute[@Type="ModeOfInheritance"]/text()')))),'origins_json':js(sorted(set(a.xpath('./ObservedIn/Sample/Origin/text()')))),'methods_json':js(sorted(set(a.xpath('./ObservedIn/Method/MethodType/text()')))),'direct_simple':int(ms is not None and ms.get('Type')=='Variant' and len(ms.findall('Measure'))==1),'org_type':ac.get('OrganizationCategory','')}

def groups(aa,v,c_by,members,asof):
 out={}
 for mode in MODES:
  gg=defaultdict(list)
  for a in aa:
   mm=members[a['scv']];rcv=mm[0]['rcv'] if len(mm)==1 else '';cr=c_by.get(rcv);conditions=json.loads(cr['conditions_json']) if cr else []
   reasons=exclusion_reasons(a,v,conditions,len(mm))
   if not choose_mode(mode,a,reasons,asof):continue
   if mode=='variant_wide':key=v['variation_id']+'|ALL'
   elif mode=='condition_inheritance_pooled':key=v['variation_id']+'|'+stable_condition(conditions)
   elif mode=='rcv_inheritance_pooled':key=v['variation_id']+'|'+rcv
   else:key=v['variation_id']+'|'+rcv+'|'+js(sorted(json.loads(a['inheritance_json'])))
   gg[key].append(a)
  out[mode]={}
  for key,assertions in gg.items():
   result,_=summarize(assertions,asof,mode=='allow_internal');out[mode][key]={k:result[k] for k in ['eligible','organizations','tier','pair_tiers','assertions']}
 return out

def run(root,month,evidence_dir):
 v=sqlite3.connect(f'file:{root}/normalized/{month}/vcv.sqlite?mode=ro',uri=True);v.row_factory=sqlite3.Row
 r=sqlite3.connect(f'file:{root}/normalized/{month}/rcv.sqlite?mode=ro',uri=True);r.row_factory=sqlite3.Row
 date=datetime.date.fromisoformat(json.loads(v.execute("select value from metadata where key='release'").fetchone()[0])['ReleaseDate'])
 inventory=json.loads((root/'analysis'/month/'source_identifier_reconciliation.json').read_text());extras=inventory['rcv_only_records'];rows=[]
 for vid in sorted({x['variation_id'] for x in extras}):
  variant=dict(v.execute('select * from variants where variation_id=?',(vid,)).fetchone());aa=[dict(x) for x in v.execute('select * from assertions where variation_id=?',(vid,))];cb={x['rcv']:dict(x) for x in v.execute('select * from rcvs where variation_id=?',(vid,))};members={a['scv']:[dict(x) for x in r.execute('select * from membership where scv=?',(a['scv'],))] for a in aa}
  added=[]
  for x in extras:
   if x['variation_id']!=vid:continue
   a=supplemental_assertion(evidence_dir/('rcv_'+x['rcv']+'.xml'),x['scv'],vid)
   assert all(a[f]==x[f] for f in ['scv','version','variation_id','label','review','evaluated','org_id'])
   members[a['scv']]=[dict(z) for z in r.execute('select * from membership where scv=?',(a['scv'],))];added.append(a)
  before=groups(aa,variant,cb,members,date);after=groups(aa+added,variant,cb,members,date)
  for mode in MODES:
   b={k:z for k,z in before[mode].items() if z['eligible']};a={k:z for k,z in after[mode].items() if z['eligible']}
   rows.append({'variation_id':vid,'mode':mode,'before_eligible_units':b,'after_eligible_units':a,'eligible_unit_delta':len(a)-len(b),'eligible_variant_delta':int(bool(a))-int(bool(b)),'changed':b!=a})
 out={'month':month,'source':'VCV primary; additional raw RCV assertions only in focused sensitivity','incomplete_variation_ids':sorted({x['variation_id'] for x in extras}),'comparisons':rows,'primary_eligible_units_excluded_by_complete_source_filter':sum(len(x['before_eligible_units']) for x in rows if x['mode']=='primary'),'primary_eligible_variants_excluded_by_complete_source_filter':sum(bool(x['before_eligible_units']) for x in rows if x['mode']=='primary')}
 (root/'analysis'/month/'source_completeness_sensitivity.json').write_text(json.dumps(out,indent=2)+'\n');v.close();r.close()
 print(json.dumps({'comparisons':len(rows),'changed_comparisons':sum(x['changed'] for x in rows),'primary_changed':any(x['changed'] for x in rows if x['mode']=='primary')}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');p.add_argument('evidence_dir',type=Path);a=p.parse_args();run(a.root,a.month,a.evidence_dir)
