"""Independent raw assertion-count representation check; differences are retained."""
import argparse,datetime,gzip,hashlib,json,sqlite3
from pathlib import Path
from lxml import etree

def digest(path):
 h=hashlib.sha256()
 with path.open("rb") as f:
  for block in iter(lambda:f.read(8*1024*1024),b""):h.update(block)
 return h.hexdigest()

def run(root,month):
 source=root/"raw"/month/("ClinVarVCVRelease_"+month+".xml.gz")
 manifest=json.loads((root/"source_manifest.json").read_text())
 item=next(x for x in manifest["sources"] if x["relative_path"]==str(source.relative_to(root)))
 assert source.stat().st_size==item["bytes"]
 # Manifest file hashes are verified by verify_snapshots / fresh replay before this stage.
 issues=[];scanned=classified=actual_total=declared_total=0
 with gzip.open(source,"rb") as f:
  for _,record in etree.iterparse(f,events=("end",),tag="VariationArchive",huge_tree=True):
   scanned+=1
   if record.get("RecordType")=="classified":
    classified+=1;actual=len(record.xpath("./ClassifiedRecord/ClinicalAssertionList/ClinicalAssertion"));declared=int(record.get("NumberOfSubmissions"))
    actual_total+=actual;declared_total+=declared
    if actual!=declared:issues.append({"variation_id":record.get("VariationID"),"declared":declared,"actual":actual})
   record.clear()
   while record.getprevious() is not None:del record.getparent()[0]
   if scanned%250000==0:print(month,scanned,len(issues),flush=True)
 db=sqlite3.connect("file:"+str(root/"normalized"/month/"vcv.sqlite")+"?mode=ro",uri=True)
 differences=[]
 for issue in issues:
  normalized=db.execute("SELECT count(*) FROM assertions WHERE variation_id=?",(issue["variation_id"],)).fetchone()[0]
  if normalized!=issue["actual"]:differences.append({"variation_id":issue["variation_id"],"raw":issue["actual"],"normalized":normalized})
 normalized_total=db.execute("SELECT count(*) FROM assertions").fetchone()[0];db.close()
 assert actual_total==normalized_total,"Raw/normalized assertion totals differ"
 report={"month":month,"records_scanned":scanned,"classified_records":classified,"present_assertion_elements":actual_total,"declared_submissions_total":declared_total,"count_discrepancies":sorted(issues,key=lambda x:int(x["variation_id"])),"discrepancy_count":len(issues),"raw_normalized_count_differences":differences,"raw_normalized_counts_agree":not differences,"all_declared_counts_equal_present_elements":not issues,"frozen_source_sha256":item["sha256"],"source_manifest_sha256":digest(root/"source_manifest.json"),"interpretation":"The declared NumberOfSubmissions attribute differs from present ClinicalAssertion elements in these records. This proves a representation inconsistency, not its cause or the identity of an unseen assertion. No assertion is invented. Historical comparisons conservatively mark these records non-comparable while primary cross-sectional calculations retain observed qualifying records."}
 out=root/"analysis"/month/"source_assertion_count_validation.json"
 out.write_text(json.dumps(report,indent=2)+"\n")
 assert not differences,"Raw/normalized assertion counts disagree"
 print(month,"assertion-count representation audit",len(issues),"retained differences",flush=True)

if __name__=="__main__":
 p=argparse.ArgumentParser();p.add_argument("root",type=Path);p.add_argument("month");a=p.parse_args();run(a.root,a.month)
