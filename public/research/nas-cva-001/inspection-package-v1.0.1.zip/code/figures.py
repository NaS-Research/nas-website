"""Render study tables in the NaS publication palette; no embedded findings."""
import argparse,csv,gzip,json,textwrap
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from review_status_intervals import run as review_intervals
PALETTE=json.loads((Path(__file__).resolve().parent/'publication_palette.json').read_text())['palette']
GOLD=PALETTE['gold'];BLACK=PALETTE['black'];CHARCOAL=PALETTE['charcoal'];GRAY=PALETTE['gray'];LINE=PALETTE['line']

def read(path):
 with gzip.open(path,'rt',newline='') if str(path).endswith('.gz') else path.open(newline='') as f:return list(csv.DictReader(f))
def number(x):return float(x) if x not in ('',None) else np.nan
def style():
 plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':13,'axes.titlesize':16,'axes.titleweight':'bold','axes.titlecolor':BLACK,'text.color':CHARCOAL,'axes.labelcolor':CHARCOAL,'xtick.color':GRAY,'ytick.color':GRAY,'axes.edgecolor':LINE,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','svg.fonttype':'none','pdf.fonttype':42})
def wrap(s,n=45):return '\n'.join(textwrap.wrap(s,n))
def save(fig,out,name,caption,manifest):
 fig.savefig(out/(name+'.pdf'),bbox_inches='tight',metadata={'Creator':'NaS ClinVar Conflict Atlas'})
 fig.savefig(out/(name+'.svg'),bbox_inches='tight')
 fig.savefig(out/(name+'.png'),dpi=300,bbox_inches='tight')
 plt.close(fig);manifest.append({'id':name,'caption':caption,'formats':['pdf','svg','png'],'data_source':'frozen analysis tables','interpretation':'Public-record disagreement, not a new clinical classification'})
def ecdf(ax,values,label,color,ls='-'):
 a=np.sort(np.array(values,dtype=float));a=a[np.isfinite(a)]
 if len(a):ax.step(a/365.25,np.arange(1,len(a)+1)/len(a),where='post',label=f'{label} (n={len(a):,})',color=color,ls=ls)
def run(root,month):
 base=root/'analysis'/month;tables=base/'tables';summary=json.loads((base/'summary.json').read_text())
 assert json.loads((base/'independent_validation.json').read_text())['passed']
 out=root/'figures'/month;out.mkdir(parents=True,exist_ok=True);manifest=[];style()
 # All tiers use mutually exclusive highest-severity assignment.
 counts={int(k):v for k,v in summary['modes']['primary']['unit_tier_counts'].items()};n=sum(counts.values())
 labels=['T1  P/LP versus B/LB','T2  P/LP versus U','T3  U versus B/LB','T4  Adjacent categories','T0  No derived disagreement'];order=[1,2,3,4,0]
 fig,ax=plt.subplots(figsize=(8,4.4),layout='constrained');values=[counts.get(t,0)/n if n else 0 for t in order]
 ax.barh(labels,values,color=[GOLD,CHARCOAL,GRAY,'#A8A8A8',LINE]);ax.invert_yaxis();ax.xaxis.set_major_formatter(PercentFormatter(1));ax.set(xlabel='Share of eligible condition-specific units',title='The severity of disagreement')
 for i,t in enumerate(order):ax.text(values[i]+.005,i,f'{counts.get(t,0):,}',va='center',fontsize=11)
 ax.set_xlim(0,max(values,default=0)*1.18+.01)
 save(fig,out,'01-severity',f'Highest-severity category per eligible variant–RCV–inheritance unit; denominator {n:,}. T0 is no derived disagreement, not necessarily identical source labels. P/LP = pathogenic/likely pathogenic; U = uncertain significance; B/LB = benign/likely benign.',manifest)
 rows=[r for r in read(tables/'gene_observed_expected.csv') if r['volume_threshold_met']=='True' and r['expected']!='']
 fig,ax=plt.subplots(figsize=(7,6),layout='constrained')
 x=np.array([number(r['expected']) for r in rows]);y=np.array([number(r['T1_T2_variants']) for r in rows])
 ax.scatter(x,y,s=18,alpha=.55,color=GOLD,edgecolors='none');limit=max([1,*x,*y]);ax.plot([0,limit],[0,limit],color=GRAY,lw=1,ls='--');ax.set_xscale('symlog',linthresh=1);ax.set_yscale('symlog',linthresh=1)
 ax.set(xlabel='Expected T1/T2 variants',ylabel='Observed T1/T2 variants',title='Gene-level observed and expected disagreement')
 save(fig,out,'02-gene-observed-expected','Each point is a gene with at least 30 eligible single-gene variants and complete reference-stratum coverage. Expected counts use leave-one-gene-out backgrounds stratified by organization count, variant type, expert involvement and evaluation age, with prespecified pooling. Dashed line: observed equals expected. Descriptive screen; no significance or clinical-risk claim.',manifest)
 ages=read(tables/'unit_assertion_ages.csv.gz');fig,axes=plt.subplots(1,2,figsize=(10,4.5),layout='constrained')
 for ax,field,title in zip(axes,['oldest_age_days','newest_age_days'],['Oldest relevant evaluation','Most recent relevant evaluation']):
  for event,color,label in [(True,GOLD,'T1/T2'),(False,GRAY,'Other tiers')]:ecdf(ax,[number(r[field]) for r in ages if (int(r['tier']) in (1,2))==event],label,color)
  ax.set(title=title,xlabel='Years before snapshot',ylabel='Cumulative share');ax.yaxis.set_major_formatter(PercentFormatter(1));ax.legend(frameon=False,fontsize=11)
 save(fig,out,'03-evaluation-age','Empirical distributions of the oldest and newest nonmissing relevant evaluation dates per eligible unit. These are evaluation ages, not durations of conflict. Units with missing dates are retained in the study and their counts are reported separately; curves omit missing values.',manifest)
 review_intervals(root,month)
 intervals={r['category']:r for r in read(tables/'review_status_cluster_intervals.csv')}
 review=read(tables/'by_review_status.csv');fig,ax=plt.subplots(figsize=(9,max(4,len(review)*.6)),layout='constrained')
 rates=[];lower=[];upper=[];labels=[]
 for r in review:
  k=int(r['T1_T2']);d=int(r['eligible_units']);v=k/d;lo,hi=number(intervals[r['category']]['ci_lower']),number(intervals[r['category']]['ci_upper']);rates.append(v);lower.append(v-lo);upper.append(hi-v);labels.append(wrap(r['category'] or '[missing]',36)+f'\n{k:,}/{d:,}')
 positions=np.arange(len(rates));lo=np.array(rates)-np.array(lower);hi=np.array(rates)+np.array(upper)
 ax.hlines(positions,lo,hi,color=GRAY);ax.vlines(lo,positions-.06,positions+.06,color=GRAY);ax.vlines(hi,positions-.06,positions+.06,color=GRAY);ax.scatter(rates,positions,color=GOLD,s=22);ax.set_yticks(np.arange(len(labels)),labels);ax.invert_yaxis();ax.xaxis.set_major_formatter(PercentFormatter(1));ax.set(xlabel='Units with T1/T2 disagreement',title='Disagreement by official RCV review status')
 save(fig,out,'05-review-status','T1/T2 units divided by all eligible units in each official RCV review-status category; numerators and denominators are shown. Bars are 95% percentile intervals from 2,000 resamples clustered by VariationID, with seed 20260926; they account for repeated units within the same variant. Finite-record counts are exact; uncertainty is model-based. Review-status association is not causal.',manifest)
 fig,ax=plt.subplots(figsize=(8,5),layout='constrained')
 for filename,field,label,color,ls in [('gene_fractional_participation.csv','T1_T2_variant_weight','Genes',GOLD,'-'),('condition_distribution.csv','disputed_fractional_weight','Condition sets',CHARCOAL,'--'),('organization_participation.csv','disputed_fractional_weight','Organizations',GRAY,':')]:
  weights=np.sort([number(r[field]) for r in read(tables/filename)])[::-1];weights=weights[weights>0]
  if len(weights):ax.plot(np.arange(1,len(weights)+1)/len(weights),np.cumsum(weights)/weights.sum(),label=f'{label} (n={len(weights):,})',color=color,ls=ls)
 ax.set(xlabel='Share of entities, ranked by disputed participation',ylabel='Cumulative share of T1/T2 fractional participation',title='Where disputed records are concentrated');ax.xaxis.set_major_formatter(PercentFormatter(1));ax.yaxis.set_major_formatter(PercentFormatter(1));ax.legend(frameon=False)
 save(fig,out,'06-concentration','Entities are ranked by disputed fractional participation. A variant is divided across its genes or disputed condition sets; each disputed unit is divided across qualifying organizations. Domains use different units and ascertainment, so curves are descriptive and do not establish responsibility for disagreement.',manifest)
 conditions=sorted(read(tables/'condition_distribution.csv'),key=lambda r:(-int(r['eligible_variants']),r['condition_key']))[:15]
 fig,ax=plt.subplots(figsize=(10,max(5,len(conditions)*.7)),layout='constrained');labels=[];rates=[]
 for r in conditions:
  k=int(r['T1_T2_variants']);d=int(r['eligible_variants']);rates.append(k/d);labels.append(wrap(r['names'] or r['condition_key'],40)+f'\n{k:,} / {d:,}')
 ax.barh(labels,rates,color=GOLD);ax.invert_yaxis();ax.xaxis.set_major_formatter(PercentFormatter(1));ax.set(xlabel='Eligible variants with T1/T2 disagreement in the condition set',title='Condition sets with the largest eligible cohorts')
 save(fig,out,'07-condition-distribution','Fifteen complete condition sets with the most eligible variants, selected by denominator rather than conflict count. Each variant is counted once within a condition set, with T1/T2 in any eligible inheritance-specific unit. Variants may contribute to multiple condition sets. Names are source labels, not clinical reinterpretations.',manifest)
 flow=read(tables/'cohort_flow.csv');counts={r['stage_or_flag']:int(r['assertions_or_units']) for r in flow};stages=[(k.removeprefix('flow:'),v) for k,v in counts.items() if k.startswith('flow:')];stages.sort(key=lambda x:-x[1])
 fig,ax=plt.subplots(figsize=(9,max(4,len(stages)*.45)),layout='constrained');ax.barh([wrap(k.replace('_',' '),42) for k,v in stages],[v for k,v in stages],color=[GOLD if k=='eligible_assertion' else GRAY for k,v in stages]);ax.invert_yaxis();ax.set(xlabel='Assertions (first applicable disposition)',title='Cohort construction: assertion disposition')
 for i,(stage,count) in enumerate(stages):ax.text(count+max(v for _,v in stages)*.012,i,f'{count:,}',va='center',fontsize=11)
 ax.set_xlim(0,max(v for _,v in stages)*1.16)
 save(fig,out,'08-cohort-disposition','Mutually exclusive first-applicable assertion dispositions, before organization deduplication and the requirement for at least two qualifying organizations per unit. Additional exclusion flags may overlap and are reported separately. This panel does not equate assertion eligibility with final unit eligibility.',manifest)
 hp=root/'analysis/history/three_snapshot_path_counts.csv'
 if hp.exists():
  paths=read(hp);months=['2025-09','2026-03','2026-09'];states=['cross_band','adjacent_only','no_derived_disagreement','ineligible','condition_or_inheritance_not_observed','variant_absent','duplicate_condition_identity','eligible_identity_not_selected','incomplete_source_assertion_coverage','unresolved_source_assertion_count'];colors=[GOLD,CHARCOAL,GRAY,'#999999','#BBBBBB','#DDDDDD','#EEEEEE','#FFFFFF','#D3C4AE','#A69B8B']
  # Baseline cross-band cohort only; later non-comparability overrides observed labels.
  totals={state:[0,0,0] for state in states+['non_comparable']}
  for r in paths:
   if r[months[0]]!='cross_band':continue
   for i,m in enumerate(months):
    st=r[m]
    if i and any(r[f'comparability_{j}_{j+1}'] not in ('stable_identifiers_and_lineage','variant_absent') for j in range(i)):st='non_comparable'
    totals[st][i]+=int(r['units'])
  fig,ax=plt.subplots(figsize=(9,5.5),layout='constrained');bottom=np.zeros(3)
  for (st,values),color in zip(totals.items(),colors+['#F5F5F5']):
   if sum(values):ax.bar(months,values,bottom=bottom,label=st.replace('_',' '),color=color,edgecolor=LINE);bottom+=values
  ax.set(ylabel='Baseline cross-band units',title='Observed states across three snapshots');ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(1,1),fontsize=11)
  save(fig,out,'04-persistence','Baseline cross-band units followed across three snapshots. Missing variants, ineligibility and non-comparable identities remain separate from observed resolution. Changes between snapshots are interval-observed; this plot cannot reveal transient resolution or recurrence between releases.',manifest)
 (out/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
