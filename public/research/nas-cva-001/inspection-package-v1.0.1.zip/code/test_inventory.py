import unittest
from source_inventory import label_family
class Vocabulary(unittest.TestCase):
 def test_standard_labels_stay_distinct(self):
  self.assertEqual(label_family('Pathogenic')[0],'P');self.assertEqual(label_family('Likely pathogenic')[0],'LP')
 def test_special_content_not_standardized_as_pathogenic(self):
  code,family,low,risk=label_family('Pathogenic/Likely pathogenic, low penetrance');self.assertEqual(code,'UNKNOWN');self.assertEqual(family,'low_penetrance_containing');self.assertTrue(low)
 def test_risk_and_unrecognized_preserved(self):
  self.assertEqual(label_family('Established risk allele')[1],'risk_containing');self.assertEqual(label_family('novel unrecognized label')[1],'unrecognized_or_mixed')
if __name__=='__main__':unittest.main()
