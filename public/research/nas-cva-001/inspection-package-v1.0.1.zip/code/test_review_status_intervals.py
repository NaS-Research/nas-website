import unittest
from review_status_intervals import calculate
class ClusteredReview(unittest.TestCase):
 def test_repeated_variant_units_resample_as_one_cluster(self):
  rows=[{'official_rcv_review':'synthetic','variation_id':'SYN1','tier':'2'}]*9+[{'official_rcv_review':'synthetic','variation_id':'SYN2','tier':'0'}]
  result=calculate(rows)[0]
  self.assertEqual(result[1:4],[10,9,.9]);self.assertEqual(result[4:6],[0.,1.])
  self.assertEqual(calculate(reversed(rows)),[result])
 def test_strata_do_not_share_denominators(self):
  rows=[{'official_rcv_review':'A','variation_id':'SYN1','tier':'2'},{'official_rcv_review':'B','variation_id':'SYN1','tier':'0'}]
  result=calculate(rows);self.assertEqual([r[1:4] for r in result],[[1,1,1.],[1,0,0.]])
if __name__=='__main__':unittest.main()
