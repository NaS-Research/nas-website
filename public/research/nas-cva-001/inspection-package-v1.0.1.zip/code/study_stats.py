"""Finite-record estimates and explicitly model-based uncertainty summaries."""
import math
from collections import Counter
import numpy as np

def wilson(k,n,z=1.959963984540054):
 if k<0 or n<0 or k>n:raise ValueError('Invalid numerator/denominator')
 if n==0:return None,None
 p=k/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
 return max(0,c-h),min(1,c+h)

def clustered_fraction_interval(cluster_event_denominator,reps=2000,seed=20260926):
 """Exact cluster bootstrap via multinomial compression of identical cluster vectors."""
 patterns=Counter(tuple(map(int,p)) for p in cluster_event_denominator)
 if not patterns:return None,None
 keys=sorted(patterns);vectors=np.array(keys,dtype=np.int64);counts=np.array([patterns[k] for k in keys],dtype=np.int64)
 n=int(counts.sum());rng=np.random.default_rng(seed);values=[]
 for _ in range(reps):
  weights=rng.multinomial(n,counts/n);events,denominator=weights@vectors
  if denominator:values.append(events/denominator)
 if not values:return None,None
 return tuple(map(float,np.quantile(values,[.025,.975])))

def odds_ratio(a,b,c,d):
 """a/b events/non-events among exposed; c/d among unexposed. Descriptive only."""
 if a+b==0 or c+d==0:return {'odds_ratio':None,'lower':None,'upper':None,'continuity_correction':None}
 correction=.5 if min(a,b,c,d)==0 else 0
 aa,bb,cc,dd=[x+correction for x in (a,b,c,d)]
 estimate=aa*dd/(bb*cc);se=math.sqrt(1/aa+1/bb+1/cc+1/dd)
 return {'odds_ratio':estimate,'lower':math.exp(math.log(estimate)-1.959963984540054*se),'upper':math.exp(math.log(estimate)+1.959963984540054*se),'continuity_correction':correction}
