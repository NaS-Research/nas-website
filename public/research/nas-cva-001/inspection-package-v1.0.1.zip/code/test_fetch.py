import hashlib,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from fetch import fetch
class FetchIntegrity(unittest.TestCase):
 def test_complete_partial_is_verified_without_network(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
   root=Path(tmp);(root/'sample.part').write_bytes(b'complete');(root/'sample.headers').write_text('original headers')
   with patch('fetch.subprocess.run') as call:record=fetch(root,'https://example.invalid/sample',Path('sample'),8)
   call.assert_not_called();self.assertEqual(record['sha256'],hashlib.sha256(b'complete').hexdigest());self.assertEqual(record['resumed_from_bytes'],8);self.assertEqual((root/'sample').read_bytes(),b'complete')
 def test_oversize_partial_is_preserved_and_rejected(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
   root=Path(tmp);(root/'sample.part').write_bytes(b'oversize')
   with patch('fetch.subprocess.run') as call:
    with self.assertRaisesRegex(AssertionError,'exceeds'):fetch(root,'https://example.invalid/sample',Path('sample'),2)
   call.assert_not_called();self.assertFalse((root/'sample').exists());self.assertEqual((root/'sample.part').read_bytes(),b'oversize')
 def test_bad_publisher_checksum_never_finalizes(self):
  with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
   root=Path(tmp);(root/'sample.part').write_bytes(b'complete')
   def checksum(command,**kwargs):Path(command[-1]).write_text('00000000000000000000000000000000 sample\n')
   with patch('fetch.subprocess.run',side_effect=checksum):
    with self.assertRaisesRegex(AssertionError,'MD5 mismatch'):fetch(root,'https://example.invalid/sample',Path('sample'),8,True)
   self.assertFalse((root/'sample').exists());self.assertTrue((root/'sample.part').exists())
if __name__=='__main__':unittest.main()
