import csv,gzip,json,tempfile,unittest
from pathlib import Path
from validate_analysis import run

class AnalysisValidation(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.root=Path(self.temp.name);self.out=self.root/'analysis'/'fixture';self.tables=self.out/'tables';self.tables.mkdir(parents=True)
  counts={'0':1,'1':1};primary={'eligible_units':2,'eligible_variants':2,'unit_tier_counts':counts,'variant_tier_counts':counts}
  (self.out/'summary.json').write_text(json.dumps({'modes':{'primary':primary}}))
  (self.out/'independent_validation.json').write_text(json.dumps({'passed':True,'independent_eligible_units':2,'tier_counts':counts}))
  self.write('variant_outcomes_primary.csv.gz',['variation_id','tier'],[['1',1],['2',0]])
  estimates=[]
  for unit in ['units','variants']:
   for label in ['T1','T1_T2','T1_T3','T4']:
    k=int(label!='T4');estimates.append([label,unit,k,2,k/2,0,1])
  self.write('principal_estimates.csv',['definition','unit','numerator','denominator','fraction','ci_lower','ci_upper'],estimates)
  for dim in ['review_status','expert_presence','variant_type','organization_count']:
   self.write('by_'+dim+'.csv',['category','eligible_units','T1','T1_T2','T1_T3'],[['all',2,1,1,1]])
  self.write('age_filter_retention.csv',['mode','baseline_tier','filtered_state','baseline_units'],[[m,t,'retained',1] for m in ['recent_2y','recent_5y'] for t in [0,1]])
  self.write('variant_features.csv.gz',['variation_id','highest_tier','gene_count'],[['1',1,1],['2',0,1]])
  for filename in ['condition_distribution.csv','organization_participation.csv']:
   self.write(filename,['eligible_fractional_weight','disputed_fractional_weight'],[[1.5,0.5],[0.5,0.5]])
  self.write('gene_fractional_participation.csv',['eligible_variant_weight','T1_T2_variant_weight'],[[2,1]])
 def write(self,name,columns,data):
  path=self.tables/name
  with (gzip.open(path,'wt',newline='') if path.suffix=='.gz' else path.open('w',newline='')) as f:
   w=csv.writer(f);w.writerow(columns);w.writerows(data)
 def test_consistent_exports(self):
  run(self.root,'fixture');self.assertTrue(json.loads((self.out/'analysis_validation.json').read_text())['passed'])
 def test_corrupt_denominator(self):
  self.write('by_review_status.csv',['category','eligible_units','T1','T1_T2','T1_T3'],[['all',3,1,1,1]])
  with self.assertRaises(AssertionError):run(self.root,'fixture')
 def test_missing_estimates(self):
  self.write('principal_estimates.csv',['definition','unit','numerator','denominator','fraction','ci_lower','ci_upper'],[])
  with self.assertRaises(AssertionError):run(self.root,'fixture')
 def test_fractional_weight_inflation(self):
  self.write('gene_fractional_participation.csv',['eligible_variant_weight','T1_T2_variant_weight'],[[3,1]])
  with self.assertRaises(AssertionError):run(self.root,'fixture')
if __name__=='__main__':unittest.main()
