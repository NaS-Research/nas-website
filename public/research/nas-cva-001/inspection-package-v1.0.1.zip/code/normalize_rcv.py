"""Extract exact SCV-to-RCV membership and source cross-check fields."""
import argparse,datetime,gzip,json,sqlite3,time,os
from pathlib import Path
from lxml import etree as E
from normalize_vcv import txt,js

def normalize(root,month):
 (root/'tmp').mkdir(exist_ok=True);os.environ['SQLITE_TMPDIR']=str(root/'tmp')
 source=root/'raw'/month/f'ClinVarRCVRelease_{month}.xml.gz'
 prov=json.loads(source.with_name(source.name+'.provenance.json').read_text());assert prov['status']=='verified download' and source.stat().st_size==prov['bytes']
 out=root/'normalized'/month;out.mkdir(parents=True,exist_ok=True);part=out/'rcv.sqlite.part';final=out/'rcv.sqlite';assert not part.exists() and not final.exists()
 with gzip.open(source,'rb') as f:
  _,r=next(iter(E.iterparse(f,events=('start',))));meta=dict(r.attrib)
 schemafile=root/'raw/documentation'/meta['{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation'].rsplit('/',1)[-1]
 schema=E.XMLSchema(E.parse(str(schemafile)))
 con=sqlite3.connect(part);con.execute('PRAGMA journal_mode=OFF');con.execute('PRAGMA synchronous=OFF');con.execute('PRAGMA temp_store=FILE');con.execute('PRAGMA cache_size=-524288')
 con.executescript('''CREATE TABLE rcvs(rcv TEXT,version TEXT,variation_id TEXT,status TEXT,conditions_json TEXT,official_label TEXT,official_review TEXT);CREATE TABLE membership(scv TEXT,version TEXT,rcv TEXT,variation_id TEXT,label TEXT,review TEXT,evaluated TEXT,org_id TEXT);CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);''')
 n=0;m=0;invalid=0;t=time.monotonic();err=(out/'rcv_schema_errors.jsonl').open('w')
 with gzip.open(source,'rb') as f:
  for _,e in E.iterparse(f,events=('end',),tag='ClinVarSet',huge_tree=True):
   if not schema.validate(e):
    invalid+=1;err.write(js({'id':e.get('ID'),'errors':[str(x) for x in schema.error_log]})+'\n')
   ref=e.find('ReferenceClinVarAssertion');ac=ref.find('ClinVarAccession');rcv=ac.get('Acc');ms=ref.find('MeasureSet')
   if ms is None:ms=ref.find('GenotypeSet')
   vid='' if ms is None else ms.get('ID','')
   conditions=[]
   for tr in ref.findall('TraitSet/Trait'):
    conditions.append({'ids':[dict(x.attrib) for x in tr.findall('XRef')],'names':[x.text or '' for x in tr.findall('Name/ElementValue') if x.get('Type')=='Preferred']})
   con.execute('INSERT INTO rcvs VALUES(?,?,?,?,?,?,?)',(rcv,ac.get('Version',''),vid,txt(ref,'RecordStatus'),js(conditions),txt(ref,'Classifications/GermlineClassification/Description'),txt(ref,'Classifications/GermlineClassification/ReviewStatus')))
   for a in e.findall('ClinVarAssertion'):
    sa=a.find('ClinVarAccession');cl=a.find('Classification')
    con.execute('INSERT INTO membership VALUES(?,?,?,?,?,?,?,?)',(sa.get('Acc'),sa.get('Version',''),rcv,vid,txt(a,'Classification/GermlineClassification'),txt(a,'Classification/ReviewStatus'),'' if cl is None else cl.get('DateLastEvaluated',''),sa.get('OrgID','')));m+=1
   n+=1;e.clear()
   while e.getprevious() is not None:del e.getparent()[0]
   if n%10000==0:con.commit();print(js({'rcvs':n,'memberships':m,'schema_invalid':invalid,'elapsed_seconds':round(time.monotonic()-t)}),flush=True)
 err.close();con.executemany('INSERT INTO metadata VALUES(?,?)',[('release',js(meta)),('source_sha256',prov['sha256']),('schema_invalid',str(invalid))]);con.execute('CREATE UNIQUE INDEX rcvs_id ON rcvs(rcv)');con.execute('CREATE UNIQUE INDEX membership_id ON membership(scv,rcv)');con.commit();con.close()
 assert invalid==0,f'{invalid} schema-invalid RCV records; inspect before finalization'
 part.rename(final);(out/'rcv_normalization.json').write_text(json.dumps({'rcvs':n,'memberships':m,'schema_invalid':invalid,'release':meta,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('month');a=ap.parse_args();normalize(a.root,a.month)
