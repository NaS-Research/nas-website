"""Retain all tabular mismatches and measure their XML-primary cohort overlap.
This creates evidence for review, without changing mappings or adjudicating causes.
"""
import argparse,csv,gzip,json,sqlite3
from collections import Counter,defaultdict
from pathlib import Path

ASSERTION_FIELDS=['scv','version','variation_id','class_type','status','org_id','org_type','label','review','evaluated','contributes','direct_simple','conditions_json','inheritance_json','origins_json','methods_json']
INDEX_LOOKUP_THRESHOLD=10000
def lookup_assertion_records(connection,wanted,scan_threshold=None):
 records={}
 if not wanted:return records
 threshold=INDEX_LOOKUP_THRESHOLD if scan_threshold is None else scan_threshold
 if len(wanted)>threshold:
  selected=set(wanted)
  # A sequential scan avoids hundreds of thousands of random HDD page reads.
  for number,row in enumerate(connection.execute('SELECT '+','.join(ASSERTION_FIELDS)+' FROM assertions NOT INDEXED'),1):
   if row['scv'] in selected:records[row['scv']]=dict(row)
   if number%500000==0:print(json.dumps({'context_assertions_scanned':number,'wanted_found':len(records),'wanted_total':len(selected)}),flush=True)
   if len(records)==len(selected):break
 else:
  for start in range(0,len(wanted),400):
   chunk=wanted[start:start+400]
   for row in connection.execute('SELECT '+','.join(ASSERTION_FIELDS)+' FROM assertions WHERE scv IN ('+','.join('?' for _ in chunk)+')',chunk):records[row['scv']]=dict(row)
 return records

def run(root,month):
 out=root/'analysis'/month
 validation=json.loads((out/'tabular_validation.json').read_text())
 discrepancy_rows={};scv_checks=defaultdict(set);variant_checks=defaultdict(set)
 for check,count in validation['checks'].items():
  path=out/(check+'.csv.gz')
  if not path.exists():continue
  with gzip.open(path,'rt',newline='') as f:rows=list(csv.DictReader(f))
  assert len(rows)==count,(check,len(rows),count)
  discrepancy_rows[check]=rows
  for row in rows:
   for key in ['scv','scv1','scv2']:
    if row.get(key):scv_checks[row[key]].add(check)
   for key in ['variation_id','tabular_vid','xml_vid','xml_vid1','xml_vid2']:
    if row.get(key):variant_checks[row[key]].add(check)
 c=sqlite3.connect(f'file:{root/"normalized"/month/"vcv.sqlite"}?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('PRAGMA cache_size=-262144')
 wanted=sorted(scv_checks)
 records=lookup_assertion_records(c,wanted)
 c.close()
 u=sqlite3.connect(f'file:{out/"units.sqlite"}?mode=ro',uri=True);u.row_factory=sqlite3.Row
 units={row['unit_key']:dict(row) for row in u.execute("SELECT unit_key,variation_id,tier FROM units WHERE mode='primary' AND eligible=1")}
 unit_members=defaultdict(list)
 # Sequential source-preserving read, avoiding a millions-of-row correlated join.
 for row in u.execute("SELECT unit_key,scv FROM unit_assertions NOT INDEXED WHERE mode='primary'"):
  if row['unit_key'] in units and row['scv'] in scv_checks:unit_members[row['scv']].append(row['unit_key'])
 u.close()
 for scv in wanted:
  if scv not in records:records[scv]={'scv':scv,'xml_assertion_absent':True}
  records[scv]['discrepancy_checks']=sorted(scv_checks[scv]);records[scv]['retained_primary_units']=sorted(unit_members[scv])
 summaries={}
 for check,rows in discrepancy_rows.items():
  scvs={row[key] for row in rows for key in ['scv','scv1','scv2'] if row.get(key)}
  direct_vids={row[key] for row in rows for key in ['variation_id','tabular_vid','xml_vid','xml_vid1','xml_vid2'] if row.get(key)}
  direct_vids.update(records[scv]['variation_id'] for scv in scvs if records[scv].get('variation_id'))
  retained={uk for scv in scvs for uk in unit_members[scv]}
  affected={uk for uk,row in units.items() if uk in retained or row['variation_id'] in direct_vids}
  source_distribution=Counter((records[scv].get('class_type','[absent]'),records[scv].get('review','[absent]'),records[scv].get('label','[absent]')) for scv in scvs)
  summaries[check]={'discrepancy_rows':len(rows),'distinct_scvs':len(scvs),'retained_qualifying_scvs':sum(bool(unit_members[x]) for x in scvs),'eligible_primary_units_with_retained_affected_scvs':len(retained),'eligible_primary_units_at_implicated_variants':len(affected),'implicated_variant_unit_tiers':dict(Counter(str(units[uk]['tier']) for uk in affected)),'source_class_review_label_distribution':[{'class_type':k[0],'review':k[1],'label':k[2],'scvs':n} for k,n in sorted(source_distribution.items())]}
 report={'month':month,'interpretation':'XML remains the prespecified primary source. Overlap measures do not establish a defect or adjudicate discrepancy causes; source-specific review and sensitivity may still be required. Implicated-variant counts include unaffected assertions and are an upper-bound scope, not altered outcome counts.','summary':summaries,'records':[records[x] for x in wanted],'discrepancy_rows':discrepancy_rows,'review_complete':False}
 (out/'tabular_discrepancy_context.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'month':month,'summaries':{k:{a:b for a,b in v.items() if a!='source_class_review_label_distribution'} for k,v in summaries.items()}},indent=2),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('month');a=p.parse_args();run(a.root,a.month)
