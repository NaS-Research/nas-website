# Terminology addendum v1.0a2

Frozen before outcome distributions have been examined. Extraction progress counts are not study outcome distributions.

T0 denotes no derived disagreement under the prespecified normalized-label comparison rules. It does not necessarily mean identical raw submitted text: VUS subtypes are collapsed, and within-band compound labels can be compatible with a single-category assertion.

Replace the phrase “full label agreement” used for T0 in operational addendum v1.0a1 with “no derived disagreement.” The numerical classification algorithm is unchanged. Historical cross-band resolution still means an eligible T1-T3 unit is later observed as eligible T0 or T4; adjacent-only T4 and T0 remain separate states. Exact raw-text unanimity must not be inferred from either state.
