# The ClinVar Conflict Atlas

Prespecified protocol v1.0. Unreviewed; not externally registered.

## 01 / Scope and prespecification

Working title: The ClinVar Conflict Atlas: The Distribution, Severity, and Persistence of Disagreement in Clinical Variant Interpretation. Study key: clinvar_conflict_atlas. This computational observational study asks which submitted germline variant-condition classifications disagree, how disagreements are distributed, and whether disagreement remains observable at successive releases.

This is an internally timestamped, preregistered-style protocol, not a registration in an external registry and not peer reviewed. Version 1.0 is frozen before parsing study records or examining outcome distributions. Only official documentation, file listings, file sizes, storage capacity, and release metadata were inspected during design. Amendments must be dated, preserve this edition, identify the affected estimand, and disclose whether outcomes were already seen.

Primary cross-sectional outcome: proportion of eligible variant-condition-inheritance units with a high-consequence discordant pair (T1). Principal secondary outcomes: T1 or T2 prevalence; any cross-band disagreement (T1-T3); counts of unique variants with at least one such unit; and disagreement in adjacent categories (T4), reported separately. These are contrasts between submitted labels, not clinical judgments or measured patient consequences.

Historical principal outcomes: status transitions and detectable persistence across three prespecified snapshots. All gene, condition, submitter, and expert-panel association screens are exploratory. No individual pathogenicity reassessment, patient interpretation, clinical guidance, submitter contact, deployment, or public release is authorized.

## 02 / Release selection and provenance

Freeze date: 2026-09-26 America/Chicago. Primary snapshot: dated September 2026 monthly VCV XML, released 2026-09-03. Historical snapshots: September 2025 and March 2026 monthly VCV XML. Select the dated files, never a mutable latest alias. This supplies approximately annual follow-up with one intermediate observation. Use their exact XML release dates, not nominal six-month intervals.

Preserve matched RCV XML for all three months if VCV does not provide an unambiguous SCV-to-RCV membership relation; RCV membership is required for primary unit construction. Current XML documentation and all referenced XSDs must be saved. Validate each release against the applicable schema or explicitly document version incompatibilities before extraction. A schema change that alters classification, condition, or membership semantics requires a protocol amendment before outcome calculation.

For every download retain URL, retrieval start/end UTC, HTTP headers, source release date, Last-Modified, source size, local size, publisher MD5 when offered, locally computed SHA-256, XML version/release attributes, and parser version. Download into .part, verify bytes and hashes, then finalize and remove write permissions. This is an integrity-controlled local snapshot, not hardware-enforced WORM storage. Never overwrite a frozen object; changed bytes receive a new version and a recorded reason.

Earlier monthly files in the directory have later modification dates. Historical estimates therefore concern archived releases as retrieved; they cannot be represented as guaranteed byte-identical to files originally distributed that month. If retrospective changes cannot be characterized, disclose this limitation prominently and restrict claims to observed archived states.

Only matched-month support files may validate snapshot counts. The current tabular files were modified September 23-24, 2026, later than the September 3 XML: they must not be silently joined as though contemporaneous. Unmatched annotations may be used only as separately dated descriptive supplements, never to replace historical assertions.

## 03 / Exact cohort and counting units

Primary cohort: directly classified human SimpleAllele records in the germline-classification branch, with an identified organization, active SCV accession/version, a recognized standard label, assertion criteria provided (including expert panels and practice guidelines), and a specific resolvable condition. Germline branch determines interpretation type; allele-origin flags are retained. Exclude records whose available origins are exclusively somatic from the primary cohort; retain mixed, germline, and unspecified origins and report these strata. Repeat after requiring explicit germline origin.

The primary unit is VariationID plus release-specific RCV membership plus exact normalized mode of inheritance. Retain the complete condition identifier set; do not split a multiple-condition assertion into invented single-condition assertions. For a primary unit require a specific MedGen identifier set. Exclude unspecified/not-provided/not-specified conditions and ambiguous membership. Unknown inheritance is its own stratum; do not compare known dominant and recessive assertions or combine unknown with known in the primary analysis.

Require at least two distinct submitting organizations within the unit after eligibility filtering. Multiple SCVs from one organization never manufacture a between-organization conflict. Deduplicate identical SCV accession/version within a snapshot. Different classifications from the same organization in the same unit are retained as intra-organization inconsistency; exclude that organization-unit from primary pair comparisons, and retain it in a sensitivity analysis that allows its distinct assertions. Do not infer organization mergers from name similarity.

Count a unit once regardless of number of SCVs or discordant pairs. Unique-variant numerator: distinct VariationIDs having at least one eligible discordant unit. Unique-variant denominator: distinct VariationIDs having at least one eligible multi-organization unit. Report both unit and variant denominators; neither is all ClinVar variants. Provide a sequential exclusion flow and overlapping reason flags.

Haplotypes, genotypes, and alleles represented only as components are excluded from the primary cohort and described separately without projecting a set-level assertion onto components. Retain CNVs and other directly classified structural SimpleAlleles regardless of coordinate availability; stratify variant type. Missing dates do not remove otherwise qualifying assertions from cross-sectional estimates.

## 04 / Classification and severity rules

Preserve the verbatim label plus a separately mapped class. Map Pathogenic to P, Likely pathogenic to LP, Uncertain significance to U, Likely benign to LB, and Benign to B. Collapse VUS-high/mid/low to U while retaining subtype; repeat excluding these subtypes. Whitespace and case normalization are permitted; substantive lexical guessing is forbidden. Unrecognized values are quarantined and enumerated before analysis.

Within-band compound labels Pathogenic/Likely pathogenic and Benign/Likely benign map to the corresponding positive or benign band but retain a compound flag and cannot generate an adjacent P-LP or B-LB disagreement on their own. Exclude compound labels in sensitivity analysis. Cross-band compound labels, consortium conflicting-data labels, missing classifications, and free-text categories are not converted into separate submitter votes.

For every pair from distinct organizations within a primary unit: T1 = P or LP versus B or LB; T2 = P or LP versus U; T3 = U versus B or LB; T4 = P versus LP or B versus LB. T0 = identical standardized labels without a discordant pair. Unit tier is the highest present using T1 > T2 > T3 > T4 > T0. Retain all pair flags so a unit containing P, U, and B is counted once as T1 but also retains its T2 and T3 evidence.

T1 is termed high-consequence label disagreement; T2 is pathogenicity versus uncertainty; T3 is benignity versus uncertainty; T4 is adjacent-category disagreement. Tier ordering is an analytic prioritization, not an estimate of patient harm. T4 is not automatically an official ClinVar conflict.

Keep low-penetrance pathogenic/likely pathogenic, established/likely/uncertain risk allele, legacy risk factor, association, drug response, protective, affects, other, not provided, and consortium conflicts in separate non-comparable strata. Never equate them to the five standard classes in primary analysis. A prespecified official-rule replication includes the appropriate risk/low-penetrance categories solely to validate ClinVar aggregation, not to expand the primary clinical-scale cohort.

## 05 / Official labels and sensitivity sets

Extract the official germline classification and review status independently for every VCV and RCV. Official aggregate status is a separate observed outcome. Recompute the documented review-precedence procedure on the full relevant SCV set, including non-primary assertions. Distinguish guideline precedence, expert-panel precedence, criteria-provided submissions, and zero-star submissions. Do not force submission-level disagreement to equal aggregate conflict.

Produce matched VCV and RCV cross-tabulations of observed official flags, replicated official-rule flags, and derived T1-T4. Investigate every unexplained replication discrepancy. Explain expected differences due to review precedence, risk categories, exclusion criteria, inheritance stratification, and variant-wide aggregation. If replication cannot be validated, retain observed official labels but do not claim rule replication succeeded.

Prespecified sensitivity analyses: (1) all review levels; (2) explicit germline origin only; (3) clinical-testing collection method only; (4) no expert panels/guidelines; (5) distinct organization internal conflicts retained; (6) exact condition-ID set with inheritance pooled; (7) RCV-level grouping without inheritance stratification; (8) variant-wide grouping, explicitly labeled cross-condition disagreement; (9) exclude compound/VUS-subtype labels; (10) T1 alone, T1+T2, and T1-T3; (11) all assertions evaluated within 5 years and within 2 years, each with newly computed denominators.

No fuzzy disease matching in primary analysis. Condition aliases can be reconciled only through explicit stable identifiers; ontology disease-area groupings are secondary annotations with versioned mappings and unmapped rates. Gene membership is as recorded in the frozen release. Multi-gene variants are reported separately and included in a fractional-weight sensitivity analysis; a unique single-gene cohort supports the principal gene screen.

## 06 / Distribution, concentration, uncertainty

Report counts and fractions by severity, gene, exact condition, review status, expert-panel presence, submitter count (2, 3-5, 6-10, >10), collection method, reported organization type, and variant type. Missing organization type remains unknown; do not label every organization a laboratory. Expert-panel presence and official aggregate stars are separate variables. Stars partly encode consensus, so conflict comparisons by stars are descriptive and structurally dependent.

The snapshot is a census of available records, not a random sample of patients or all human variation. Report exact finite-database fractions. Optional 95% Wilson intervals on unique-variant proportions describe a superpopulation model, not uncertainty in the count itself. For unit-level comparisons use 2,000 bootstrap resamples clustered by VariationID, seed 20260926, retaining all units of a sampled variant. No clinical population prevalence is inferred.

Gene observed-versus-expected screen: single-gene unique variants, outcome any T1/T2 within an eligible unit. Expected counts are sums of leave-one-gene-out stratum rates based on organization-count bins, variant type (SNV, short indel, CNV/structural, other), expert-panel presence, and maximum qualifying assertion age (<2, 2-5, >5 years, unknown). Strata with fewer than 50 out-of-gene variants pool age first, then type, then organization count. If even pooled reference is unavailable, report not estimable.

Show observed, expected, observed/expected, eligible n, and absolute excess per 1,000. Do not rank by raw count alone. Screens with eligible n <30 appear descriptively without ranking. These adjustments do not remove ascertainment bias. Any exploratory hypothesis-test family is predefined separately for genes and conditions and uses Benjamini-Hochberg q-values; omit tests rather than substituting unplanned models when model assumptions fail.

Concentration: report share of eligible variants and share of T1/T2 variants attributable to each gene/condition. For submitters, report participation in disputed units with that submitter present divided by eligible units with that submitter present, plus fractional participation shares (1/k for k participating organizations). HHI uses shares summing to one. Participation is not responsibility or error. Report top shares alongside coverage and submission volume.

## 07 / Assertion dates and conflict persistence

Use date last evaluated for assertion age, distinct from submission-created and record-updated dates. For each unit report oldest and newest valid evaluation dates and time since newest evaluation, with number and fraction of missing dates. Future, malformed, or impossible dates are flagged and excluded from age calculations; never impute record-update dates as evaluation dates.

At the primary freeze, define recent as evaluated within 2 years and old as more than 5 years; intermediate is 2-5 years. A recent discordant pair has both sides recent. An old-recent pair has one old and the other recent. Report these pair indicators independently and missing-date denominators. A conflict disappearing after old-assertion exclusion is age-sensitive under that rule, not proven to be caused by outdated evidence.

Historical keys use stable VariationID plus exact condition-ID set and inheritance. Require one-to-one lineage or an explicit accession merge mapping. Splits, unresolved merges, or changed condition identity are non-comparable transitions; disappearance is not resolution. Gene names and coordinate strings never determine identity alone.

At each snapshot assign eligible-discordant tier, eligible-concordant, ineligible/insufficient, absent, or non-comparable. Persistent means discordant at successive observed snapshots; it does not prove uninterrupted conflict between them. Appeared means previously eligible-concordant then discordant. Resolved means discordant then eligible-concordant with at least two organizations, classified separately into assertion revision versus withdrawal/deletion changes where identifiable. T1 becoming T2 is severity reduction, not resolution of all disagreement.

Primary history is a three-state-table comparison, not an exact-duration survival claim. For baseline prevalent conflicts, time to first observed concordance lies between last discordant and first concordant snapshots; unresolved records are right-censored and loss of eligibility is reported separately. Provide lower/upper resolution-proportion bounds treating losses as unresolved/resolved. An interval-censored Turnbull estimate is exploratory only with >=50 observed resolutions; never use midpoint dates as exact event dates. Report time since baseline detection, not time since true conflict onset. Expert-panel/update associations use exposure at the start of an interval and avoid ever-exposed immortal-time bias; no causal effect is claimed.

## 08 / Validation and release gates

Normalization checks: unique snapshot-SCV-version keys, referential integrity, explicit organization IDs, exact SCV membership, source-text label fidelity, valid condition sets, and no assembly double counting. VariationID is the main identity. Coordinate cross-checks respect HGVS right-shifting versus VCF left-shifting; equivalence requires reference-aware normalization for sequence alleles, not equality of position strings. Exclude neither structural nor unmapped variants just because VCF omits them.

Use synthetic fixtures for every classification pair, compound labels, missing dates, same-organization duplicates, inheritance mismatch, multi-condition assertions, component alleles, expert override, and archive transitions. Independently recompute headline numerator/denominator from normalized rows with a second implementation that does not call the production tier/grouping functions; agreement must be exact. Independently re-extract the validation sample from raw XML to test shared upstream parser assumptions.

Prespecified manual-record verification: 120 units, 20 each from T1, T2, T3, T4, concordant, and non-comparable/excluded strata. Within each stratum select the lowest SHA-256 of study seed 20260926 plus stable unit key, with no replacement; if fewer than 20, inspect all and report the shortfall. Verify raw SCV labels, organization IDs, condition/inheritance, dates, review status, and official RCV/VCV representation. Case examples are the first two validated records per tier in this order, not selected for notoriety.

Verification is computational source review by the same AI-assisted workflow unless a human separately performs and signs a review. It must not be called independent expert or clinical review. Log every discrepancy and adjudication; rerun impacted results after fixes. Unresolved classification, identity, or denominator discrepancies block publication-readiness.


## 09 / Normalized data and replay contract

Required normalized tables: releases; variants; variant_gene (many-to-many); assertions (one active SCV/version/snapshot); assertion_condition and RCV_membership; organizations; units; organization_unit_labels; pair_flags; unit_outcomes; variant_outcomes; transitions; exclusions; validation_cases. Preserve source values alongside normalized fields and reason codes. Store documentation snapshots and provenance separately from analysis outputs.

Assertions retain snapshot, VariationID, VCV/SCV accession and version, organization ID, germline label, review text, classification type, collection method, origin, condition identifiers, inheritance, evaluation/creation/update dates, and source record identifier. Never export patient-level observations or submitter personal contacts. Derived data must not imply evidence access that was not actually available.

Replay must accept a configurable data root, verify protocol/data checksums before parsing, use locked software versions, deterministic sorting and seed, and regenerate machine-readable counts, tables, figures, and audit logs from preserved raw bytes. Separate fetch, normalize, validate, analyze, figures, and package stages. Record OS, Python, dependencies, executable versions, code hashes, command arguments, timestamps, and exit status. Failed or partial stages must not mark the next stage complete.

Public research package proposed allowlist: protocol, methods/results, data dictionary, normalized research-only tables, public analysis code, dependency lock, replay script, source URL/checksum manifest, figure masters/derivatives, limitations, and validation summary. Raw XML is retained privately; a fetch manifest supports replay without redistributing observation text or ancillary licensed content. Branding assets and document-production adapters remain private.

## 10 / Feasibility and interpretation

Verified: the external study drive has approximately 5.4 TiB free. Dated VCV and RCV monthly release listings are accessible. September 2026 VCV is 5,849,397,646 compressed bytes; September 2025 VCV is 5,032,951,953; March 2026 VCV is 5,747,209,323. These are inventory sizes, not scientific findings. Streaming gzip/XML extraction can avoid retaining fully expanded XML. Reserve 200 GB working space initially and measure actual memory/runtime before extrapolating.

Feasible in principle: cross-sectional submission disagreement, official-label comparisons, descriptive concentration, assertion ages, and sparse historical transitions. Not yet verified: complete raw-file transfers, XSD compatibility, exact condition membership availability, normalized outputs, parser correctness, and independent count agreement. Exact conflict onset and uninterrupted persistence are not recoverable from three snapshots.

NCBI permits broad molecular-data use but does not transfer all third-party intellectual-property rights. Acknowledge ClinVar/NCBI and cite its database paper, release identifiers, access dates, and methods documentation. Do not redistribute full OMIM text, linked evidence publications, assertion-method documents, or personal observations under an assumed universal license. Retain source notices and identify any additional ontology license before use.

Disagreement can reflect evolving evidence, disease context, penetrance, inheritance, submitter scope, or review processes; it is not synonymous with error. ClinVar ascertainment, missing dates, dependence among organizations, incomplete evidence access, and archive revisions limit inference. The study cannot determine which assertion is correct or translate disagreement into patient risk.

Readiness at protocol freeze: design complete for execution; study results and publication readiness not established. A final report must disclose all deviations, coverage losses, unresolved validation issues, exact human-review status, and the distinction between reproducible analysis and independent scientific review.

## References

- [ClinVar download and identifier guide](https://www.ncbi.nlm.nih.gov/clinvar/docs/ftp_primer/)
- [ClinVar classification representation](https://www.ncbi.nlm.nih.gov/clinvar/docs/clinsig/)
- [ClinVar review status](https://www.ncbi.nlm.nih.gov/clinvar/docs/review_status/)
- [NCBI data usage policy](https://www.ncbi.nlm.nih.gov/home/about/policies/)
- [ClinVar VCV release directory](https://ftp.ncbi.nlm.nih.gov/pub/clinvar/xml/)
- [ClinVar RCV release directory](https://ftp.ncbi.nlm.nih.gov/pub/clinvar/xml/RCV_release/)
- [ClinVar tabular directory](https://ftp.ncbi.nlm.nih.gov/pub/clinvar/tab_delimited/)
- [ClinVar 2025 database update](https://pmc.ncbi.nlm.nih.gov/articles/PMC11701624/)
