# Portable protocol editions

These five editions retain the original scientific definitions and dated addenda. Transport manifests were created after outcome inspection to verify distribution integrity; they are not new pre-outcome registrations and their files are not asserted to be byte-identical to the original freezes.

Each folder includes the original freeze metadata, a provenance record identifying original and transport hashes, and an explicit edit list. The core protocol omits one publication-production/packaging administration paragraph. No cohort, severity, estimator, source-review or clinical-interpretation definition is removed. Other addendum texts remain byte-identical. Complete original editions remain preserved in the study archive; not every original artifact listed by the original manifest is redistributed.

For a new computational run, pass --protocol-root portable/protocol to code/replay.py. This checks the transport integrity manifests. The study replay is separately evaluated using its original complete protocol freezes and preserved raw sources. Consult the final validation receipt for actual completed stage scope and comparisons; this transport copy alone does not prove computational completion.

The post-outcome conservative source-counter comparability restriction and implementation repairs are disclosed in the methods and limitations. They are not presented as original pre-outcome protocol provisions.
