# Estimator implementation clarification v1.0a3

This clarification is frozen before examining study outcome distributions. It changes neither the cohort nor the Turnbull likelihood, event definition, censoring rules, weights, or event-count threshold.

A synthetic cohort with 50 events in (0,10] days and 50 records right-censored just after day 10 exposed a plotting-boundary convention in the pinned lifelines survival envelope: at the event interval's right endpoint, its upper plotted value retains the pre-jump survival level. Treating both returned plotting columns as right-continuous P(T>t) would therefore misstate survival at that boundary.

The implementation now calls the same pinned lifelines NPMLE routine directly and retains its fitted Turnbull support intervals and probability masses. At time t, lower survival is the sum of masses whose support left endpoint is greater than t; upper survival is the sum whose support right endpoint is greater than t. These are right-continuous bounds conditional on the fitted masses. They are not sampling confidence intervals and do not purport to cover every possible nonunique maximum-likelihood mass allocation. Unbounded right support is recorded explicitly.

The existing 0.000001-day shift of open lower bounds remains unchanged. The implementation uses a pinned internal library interface and remains labeled experimental. Warnings, monotonicity, range, mass normalization, and ordering diagnostics are retained. Synthetic known-fraction and event-free horizon checks accompany the implementation. Actual-data diagnostics still require review before interpretation.

The original protocol and previous addenda remain unchanged. No clinical reinterpretation or causal claim is introduced.
