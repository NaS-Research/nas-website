# Source reconciliation addendum v1.0a4

This operational addendum is frozen after source validation and before examination of study-level outcome distributions. Targeted source assertion labels were inspected to investigate extraction and release consistency. It is an internal prespecification, not an external registration.

## Evidence

In the frozen 2025-09 pair, 18 SCVs have VCV versions one greater than their RCV versions. All compared analytic fields (variation identifier, classification, review status, evaluation date, organization identifier) agree. Independent raw XML inspection confirms the normalized values on both sides. Two further assertions, SCV001433047 and SCV001653515, occur in RCV but are absent from their VCV records (VariationIDs 978268 and 1120219). Both VCV records declare three submissions but contain two. The second missing assertion is flagged in RCV as redundant with SCV002574879. No reason is inferred for the first omission.

## Source precedence and explicit reconciliation

The prespecified VCV-based assertion cohort is retained. VCV supplies assertion attributes; RCV supplies condition-record membership. Raw files and normalized source tables are never overwritten or patched to make the releases agree. A version-only difference may pass the cohort gate only when its exact SCV, paired versions, variant and RCV identifiers match a source-manifest-bound reconciliation record and raw-source inspection confirms all compared analytic fields. The gate must reject any additional or changed discrepancy. This is an adjudicated source inconsistency, not a claim of identical paired source versions.

The two RCV-only assertions remain absent from the VCV-based primary cohort and are listed explicitly as incomplete source coverage. Before headline release, recompute every existing sensitivity definition for the two affected variants using the independently extracted RCV assertions added to the VCV assertions, preserving exact condition membership and inheritance. Report any eligibility, denominator or severity changes. This local supplementation check is a source-completeness sensitivity, not a replacement primary dataset. Also report the primary estimates after excluding any affected variants; disclose even a zero impact. No missing assertion is inferred to be benign, resolved, deleted or current in VCV.

Historical comparisons involving an affected variant at a snapshot with incomplete assertion coverage are non-comparable for that interval. They cannot supply a resolution event, including when the omitted assertion would not meet primary eligibility. Report this source-completeness reason separately from disappearance and ordinary loss of eligibility.

Apply identifier-presence reconciliation to every snapshot. New source inconsistencies require raw evidence and explicit documented adjudication; this addendum does not allow generic waiver of mismatches. Preserve extraction, adjudication and sensitivity evidence in the reproducible research package. Source count discrepancies remain visible in validation reports.
