# Normalized research data dictionary

This document describes the implemented pipeline, not study findings. Snapshot months are directory partitions. Internal XML release dates define observation time. Identifiers remain strings. CSV empty fields represent missing or undefined values, not zero. JSON arrays preserve one-to-many relationships without multiplying records. Original source strings and their standardized analytic representations are distinct fields.

## Source-normalized databases

Each snapshot has a VCV and RCV SQLite database. A `.part` database is incomplete and is never eligible for analysis.

VCV tables:

- `variants`: one VariationID per snapshot; VCV accession/version, record type/status, species, directly classified SimpleAllele flag, AlleleID, source display name/type, genes, sequence locations, SPDI, official germline aggregate label/review, creation and update dates.
- `assertions`: one current source SCV accession per snapshot with its version; VariationID, internal assertion ID, organization ID/name/reported type, classification branch, source label/review/status, evaluation/creation/update/submission dates, mapped and submitted conditions, inheritance, origins, methods, contribution flag, and direct-SimpleAllele flag. Observation-level personal data and evidence comments are not extracted.
- `rcvs`: RCV accession/version, VariationID, complete classified condition list, and official germline label/review. This VCV list alone does not establish SCV membership.
- `deleted_scvs`: deletion records explicitly reported by the source. Absence alone is not a deletion.
- `lineage`: replacement relationships actually reported in XML, retained for historical comparability.
- `metadata`: source checksum, XML release attributes, extraction totals, and schema status.

Assertion classification fields have a specific extraction scope. In VCV assertions, `class_type=germline` means the modeled `Classification/GermlineClassification` element exists; `somatic_or_other` means that element is absent. The germline label is extracted from that element, while review status comes from the enclosing `Classification`. An empty germline label is not a finding that all classification branches are empty. Reported sample origins are stored separately and supply the exclusively-somatic origin exclusion. Neither branch category alone establishes biological origin.

RCV tables:

- `rcvs`: independently extracted RCV accession/version, VariationID, status, complete condition identifiers/names, and official germline label/review.
- `membership`: exact SCV version-to-RCV relationship, with VariationID, label, review, evaluation date, and organization ID for cross-file validation. Uniqueness is `(scv, rcv)`; membership is never inferred from similar condition names.
- `metadata`: source checksum, release attributes, and schema status.

## Cohort database

`units` stores primary and sensitivity definitions. Its key is `(mode, unit_key)`. A primary `unit_key` encodes VariationID, RCV accession, and the sorted complete inheritance-label set. Unknown inheritance is an explicit empty set, not a wildcard. Sensitivity modes intentionally use their documented alternative grouping keys.

`eligible` means at least two qualifying organizations remain after the mode's filters and organization-consistency handling. `organizations` is the distinct qualifying organization count. `assertions` counts retained SCVs and is not the number of independent organizations. `inconsistent_orgs` counts excluded internally inconsistent organizations. A unit with fewer than two organizations must not enter a prevalence denominator.

`tier` is the highest-priority observed pair tier: T1 P/LP versus B/LB, T2 P/LP versus U, T3 U versus B/LB, T4 adjacent P-versus-LP or B-versus-LB disagreement, and T0 no derived disagreement. `pair_tiers` preserves all observed tier flags. T0 does not imply identical raw label text. Highest priority is T1, then T2, T3, T4; T0 is used when none applies.

`oldest_age_days` and `newest_age_days` are the maximum and minimum valid evaluation ages among retained assertions, measured before the internal snapshot date. `missing_dates` counts retained assertions whose evaluation date is missing or invalid, including future dates. Entirely unavailable ages remain null. These ages are not durations of conflict.

`expert` indicates qualifying expert-panel or practice-guideline involvement. Official RCV and VCV labels/review levels are source aggregates, not replacements for derived pair comparisons. Genes and variant type are source annotations and do not establish causality.

Other cohort tables:

- `unit_assertions`: retained primary-mode SCVs linked to their unit, including source and canonical labels, organization, review, evaluation age/date status, type, method, and origin. Join to `units.eligible=1` for the eligible primary cohort; this table can also contain retained assertions from ineligible units.
- `exclusions`: SCV, VariationID, unit key where identifiable, and overlapping reason flags. A separate first-applicable disposition supplies the disjoint assertion flow.
- `crossfile_errors`: conflicting SCV fields between matched XML representations. These block final cohort construction until investigated.
- `official_replication`: observed official conflict flag, independently reconstructed flag where comparable, and reason at VCV or RCV level. This is separate from primary severity.
- `metadata`: snapshot date, construction counts, and implemented modes.

Organization-label sets and pair flags are represented through these tables and JSON fields; there are no separate physical `organization_unit_labels` or `pair_flags` databases.

## Principal and exploratory CSV exports

`principal_estimates` identifies each numerator, denominator, fraction, interval method, and whether the observation is a unit or a unique variant. Variant outcomes use the highest-severity eligible unit per variant. Counts are exact for the frozen census; intervals are model-based. Unit-level principal intervals resample variants as clusters. Bootstrap pattern order is canonical so input row order does not change the seeded draws.

`variant_outcomes_<mode>` and `primary_units` preserve the identifiers needed to reproduce denominators. Review, expert, type, and organization-count tables state eligible-unit denominators. `cohort_flow` mixes clearly named assertion dispositions, unit counts, and diagnostic flags; its rows must not be added indiscriminately.

`gene_observed_expected` uses single-gene variants. `eligible_single_gene_variants` is the denominator, `T1_T2_variants` is the observed count, and `expected` uses the prespecified leave-one-gene-out reference strata. `reference_covered_variants` reports background coverage; incomplete coverage leaves the overall expected count undefined. `volume_threshold_met` tests the prespecified minimum of 30 eligible variants. An expected count of zero leaves the ratio undefined; it is not replaced by a pseudocount. Gene annotations do not necessarily imply a disease-causing relationship.

Gene fractional participation divides each variant across its annotated genes. Condition tables count a variant once within each complete condition set; variants may appear in multiple sets. Eligible condition weights divide across eligible sets, while disputed weights divide across disputed sets. Organization participation divides each eligible or disputed unit across its qualifying organizations. These domains use different denominators and do not attribute blame.

`unit_assertion_ages` contains unit-level oldest/newest ages and missingness. `discordant_pair_age_patterns` has overlapping indicators for both-recent, old/recent, and both-old cross-band pairs. `age_filter_retention` keeps the primary baseline fixed and separates retained cross-band disagreement, adjacent-only disagreement, no derived disagreement, and insufficient qualifying organizations after filtering. Filtering attrition is not resolution.

`source_analytic_label_inventory` preserves the original label and canonical code alongside lexical risk/low-penetrance flags and a descriptive label family. These audit fields do not turn a mixed or unrecognized label into a standard pathogenicity category or change cohort eligibility.

## Historical exports

Historical identity is VariationID plus the complete condition identifier set and exact inheritance. RCV accession changes alone do not define a new historical identity; duplicate condition identities, changed alleles/SPDI, and replacement-history changes are checked explicitly.

`transitions` retains start/end states, tiers, and comparability. `three_snapshot_paths` and its count table preserve the full observed sequence. Variant absence, ineligibility, an unobserved condition/inheritance combination, duplicate identity, and other non-comparability are separate from resolution.

`first_resolution_intervals` contains `last_cross_band_days`, `first_resolved_days`, the observed-resolution flag, and follow-up status. A null upper time denotes right censoring. First observed resolution is the first later comparable eligible T0/T4 state after baseline cross-band disagreement; T4 can retain adjacent-category disagreement. It does not establish complete concordance or permanent resolution. A unit first observed at T0/T4 can return to T1/T2/T3 in a later snapshot. The first-resolution count and the resolved final-endpoint count therefore have different definitions. The time origin is baseline observation of a prevalent conflict, not its true onset.

`turnbull_survival_bounds`, when the event threshold is met, reports right-continuous P(T>t) lower/upper bounds conditional on fitted support masses. It does not report confidence intervals or bounds across every nonunique maximum-likelihood allocation. Diagnostics retain fitted support endpoints/probabilities, warning messages, and numerical checks. A null right support endpoint accompanied by `right_unbounded=true` means infinity.

Baseline association tables distinguish resolved, persistent, and lost/non-comparable records. Recent update refers to an SCV record update in the previous 365 days, not necessarily clinical reevaluation. A unit is recent if any qualifying interval-start SCV has a valid update age within 365 days; older requires all qualifying update ages to be valid and over 365 days. With no recent update, any unavailable update age or absence of dates creates the separate unknown category. A recent unit can contain another SCV with an unavailable date; zero unknown units does not establish complete dates for every constituent SCV. Risk differences and odds ratios are observational and condition on comparable observed follow-up.

`resolution_record_changes` reports overlapping changes accompanying resolution: label revisions, absent SCVs, explicitly recorded deletions, present SCVs no longer qualifying for the same unit, newly qualifying SCVs, review/evaluation-date changes, and organization changes. These are not mutually exclusive causal explanations.

## Validation, provenance, and release metadata

Source-case, coordinate, and matched-tabular discrepancy files retain the identifying fields and both representations needed for review. A reported discrepancy is not automatically a clinical error. The deterministic case sample and reviewer record must identify actual review type and any shortfall.

The release export catalog must associate each distributed table/report with its schema version, snapshot partition, observation unit, null conventions, column names, byte size, checksum, and source-manifest reference. This catalog is generated only after actual outputs exist. SQLite schema metadata and source checksums remain embedded in their databases. Raw-source provenance, computational validation, manual case inspection, visual inspection, and publication approval are distinct records.

## Source coverage and supplemental review exports

source_assertion_count_validation counts actual ClinicalAssertion elements in classified raw VCV records and compares extraction counts at flagged records and in total. raw_normalized_counts_agree assesses extraction fidelity; all_declared_counts_equal_present_elements assesses a different source counter consistency condition. The former may be true while the latter is false. count_discrepancies preserves VariationID and both counts. No unseen SCV, label or organization is inferred.

Historical state unresolved_source_assertion_count marks a declared-versus-present counter inconsistency. incomplete_source_assertion_coverage marks separately proven paired-source assertion absence. Where both occur, the proven absence reason has priority. Comparisons touching either state are non-comparable; neither can generate a resolution event. The counter-based restriction is disclosed as post-outcome conservative quality control. Cross-sectional primary eligibility continues to use observed qualifying records.

source_assertion_count_review retains disposition and the affected observed primary units. Its exclusion-only sensitivity reports exact post-hoc point counts after removing affected observed units. It is not an imputation, a model-based interval, or a bound on all possible unseen assertion classifications.

source_dimension_participation deduplicates primary-unit participation within each reported method or organization category; categories overlap. Counts across categories are not additive. review_status_cluster_intervals reports eligible-unit T1/T2 rates by observed official RCV review stratum, with 2,000 variant-cluster resamples and the frozen seed. It does not validate the official aggregation algorithm or estimate a causal review effect.

Source-review completion, raw/extraction agreement, logical replay agreement and publication approval remain distinct flags. No review field may be interpreted as independent human or clinical review unless it identifies an actual separate human reviewer.
